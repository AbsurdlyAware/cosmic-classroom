# Cosmic Classroom

An interactive space-science learning site: live sky data, short lessons and six working simulations that check their own physics. Everything runs in the browser from a single `index.html`, with no server, accounts or tracking.

**Live site:** `https://YOUR-USERNAME.github.io/cosmic-classroom/` (after you enable GitHub Pages, below)

## What's inside

- **Explore**: ten topics with live data. They cover tonight's sky for any location, the Moon's phase, today's planet positions, eclipses through 2028, meteor showers, Jupiter's moons, the Sun, your weight on other worlds, and missions.
- **Learn**: three complete lessons (levels 0–2). Each one is built around a prediction, uses an interactive model, and includes a knowledge check and a list of sources.
- **Labs**: six self-checking simulations.
  - Gravity and orbits
  - Exoplanet transits
  - Solar System explorer
  - Cosmic scale
  - Stellar spectroscopy
  - Black holes (general relativity)
- **Progress**: tracked privately in the browser.

## Scientific accuracy

Every lab compares its simulation with an independent result and shows the comparison live. `npm test` runs 28 automated checks. Here's what they currently show.

| Check | Result |
|---|---|
| Orbit energy over 100 orbits | error below 1 part in 10 billion |
| Moon phase times vs published values | within 11 minutes |
| Planet oppositions 2025–2027 | within half a day |
| Jupiter's moons vs Meeus, *Astronomical Algorithms*, example 44.a | within 0.02 Jupiter radii |
| Kepler's third law vs NASA sidereal periods | within 0.09% |
| Blackbody peak and total output vs Wien and Stefan–Boltzmann | within 1 part in a million |
| GR orbit conserved quantity | machine precision |

**Review status:** the science has been checked by automated tests and by internal review only. It has **not yet been reviewed by an external astronomer**. Treat it as a well-sourced draft, and please open an issue if you find an error.

Known simplifications, also stated in each lab's Model tab:
- Spectral line *strengths* use a teaching model, not a stellar-atmosphere calculation.
- Light bending uses the weak-field lens equation.
- Planet positions use JPL approximate elements, which are valid only from 1800 to 2050.
- Schematic views (the Milky Way's shape, the cosmic web, the Oort cloud) are labelled as schematic.

## Run it locally

Open `index.html` in a browser. No install is needed.

To change the code, edit the files in `src/`, then:

```bash
npm test          # physics and astronomy checks
npm run build     # rebuilds index.html from src/
```

Node 18 or newer is required, with no dependencies. On every push, GitHub Actions runs the tests and checks that `index.html` matches `src/`.

## Publish with GitHub Pages

1. Push this repository to GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**, the branch to **main**, and the folder to **/ (root)**. Then click **Save**.
4. After a minute or two the site is live at `https://YOUR-USERNAME.github.io/cosmic-classroom/`.

## Project structure

```
index.html            built site (the only file GitHub Pages needs)
src/
  index.html          page template
  styles.css          design tokens and layout (light and dark)
  app.js              router, home, lessons, progress
  content.js          lessons, levels and sources as structured data
  explore.js          Explore hub and topic screens
  orbitlab.js, transitlab.js, labs2.js   the six labs
  physics.js, transit.js, astro.js, spec.js, bh.js   physics engines (no DOM; tested)
  tutor.js            AI tutor (works only in the claude.ai build)
tests/run.js          validation suite
build.js              assembles src/ into index.html
```

## The AI tutor

The tutor uses the Claude runtime that exists only on claude.ai, so it is hidden in the public build. To bring it to the public site, you would need a small server that holds an API key. A key must never be placed in public page code. `npm run build:claude` produces the claude.ai version in `dist/`.

## Sources and credits

Data and methods come from the following sources. Each lesson and lab lists the specific sources it uses.

- **NASA:** NSSDCA fact sheets, the Exoplanet Archive, and the eclipse catalogue (Espenak and Meeus).
- **JPL:** approximate planetary elements (Standish).
- **IAU:** 2012 and 2015 resolutions.
- **Other standard references:** the Astronomical Almanac; Meeus, *Astronomical Algorithms*; the International Meteor Organization calendar; the NIST Atomic Spectra Database; Misner, Thorne and Wheeler, *Gravitation*.

All illustrations are drawn in code and are not photographs.

## License

The code and content are released under the MIT License. See [LICENSE](LICENSE).
