/* ---------- Cosmic Classroom app core ---------- */
const APP = (() => {
'use strict';
const PRODUCT_NAME = 'Cosmic Classroom';   // configurable product name
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
const TAU = Math.PI * 2;
const reduceMotion = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
const LESSONS = CONTENT.LESSONS;
const byId = Object.fromEntries(LESSONS.map(l => [l.id, l]));
const FONT = '"Atkinson Hyperlegible", system-ui, sans-serif';

function sizeCanvas(cv) {
  const r = cv.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  const w = Math.max(1, Math.round(r.width * dpr)), h = Math.max(1, Math.round(r.height * dpr));
  if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
  return dpr;
}
function cssVars() {
  const cs = getComputedStyle(document.documentElement), g = n => cs.getPropertyValue(n).trim();
  return { space: g('--space'), ring: g('--space-ring'), label: g('--space-label'), text: g('--space-text'), trail: g('--trail'), pred: g('--pred'),
    grav: g('--grav'), planet: g('--planet'), accent: g('--accent'), violet: g('--violet'), ink: g('--text'), muted: g('--muted'), line: g('--line') };
}
function niceStep(x) { const p = Math.pow(10, Math.floor(Math.log10(x))), f = x / p; return (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10) * p; }
const trimNum = x => String(Number(x.toPrecision(6)));

/* ======================= Progress store ======================= */
const Progress = (() => {
  const KEY = 'cc.progress.v1';
  let state = { lessons: {}, predictions: {}, labs: {}, updated: 0 };
  let docRef = null, mode = 'local';  // local | account | readonly
  const listeners = new Set();
  const emit = () => listeners.forEach(f => { try { f(state); } catch (e) { console.error(e); } });
  try { const raw = localStorage.getItem(KEY); if (raw) { const s = JSON.parse(raw); state = Object.assign(state, s); } } catch (e) { /* storage unavailable */ }
  const saveLocal = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* ignore */ } };
  let writing = false, again = false, timer = null;
  async function saveRemote() {
    if (!docRef || mode === 'readonly') return;
    if (writing) { again = true; return; }
    writing = true;
    try { await docRef.set(JSON.parse(JSON.stringify(state))); mode = 'account'; }
    catch (e) { if (e && e.code === 'invalid_argument') mode = 'readonly'; }
    writing = false; emit();
    if (again) { again = false; saveRemote(); }
  }
  function save() { state.updated = Date.now(); saveLocal(); clearTimeout(timer); timer = setTimeout(saveRemote, 700); emit(); }
  const mergeMap = (a, b) => { const out = { ...a }; for (const [k, v] of Object.entries(b || {})) if (!out[k] || (v && (v.at || 0) < (out[k].at || 0))) out[k] = v; return out; };
  async function connect() {
    if (!window.claude || typeof window.claude.use !== 'function') return;
    try {
      const [db, user] = await Promise.all([window.claude.use('db'), window.claude.use('user')]);
      if (!db || !user) return;
      const id = await user.id(); if (!id) return;
      docRef = db.collection('data/users/' + id).doc('progress');
      const snap = await docRef.get();
      if (snap.exists) {
        const r = snap.data() || {};
        state.lessons = mergeMap(state.lessons, r.lessons); state.predictions = mergeMap(state.predictions, r.predictions); state.labs = mergeMap(state.labs, r.labs);
        saveLocal();
      }
      mode = 'account'; emit();
      if (!snap.exists && (Object.keys(state.lessons).length || Object.keys(state.predictions).length || Object.keys(state.labs).length)) saveRemote();
    } catch (e) { /* stay local */ }
  }
  return {
    get: () => state,
    mode: () => mode,
    on: f => { listeners.add(f); return () => listeners.delete(f); },
    lesson(id, rec) {
      const prev = state.lessons[id];
      if (prev) { prev.best = Math.max(prev.best || 0, rec.score); prev.last = Date.now(); }
      else state.lessons[id] = { at: Date.now(), last: Date.now(), score: rec.score, best: rec.score, total: rec.total, firstTry: rec.firstTry };
      save();
    },
    prediction(key, correct) { if (!state.predictions[key]) { state.predictions[key] = { at: Date.now(), correct: !!correct }; save(); } },
    lab(id) { if (!state.labs[id]) { state.labs[id] = { at: Date.now() }; save(); } },
    reset() { state = { lessons: {}, predictions: {}, labs: {}, updated: Date.now() }; saveLocal(); saveRemote(); emit(); },
    connect,
  };
})();

/* ======================= Router ======================= */
const VIEWS = ['home', 'labx', 'explore', 'topic', 'learn', 'lesson', 'labs', 'orbits', 'transits', 'tutor', 'progress', 'about'];
const NAV_OF = { labx: 'labs', explore: 'explore', topic: 'explore', home: 'home', learn: 'learn', lesson: 'learn', labs: 'labs', orbits: 'labs', transits: 'labs', tutor: 'tutor', progress: 'progress', about: 'about' };
const TITLES = { explore: 'Explore the sky', home: 'Space science you can test', learn: 'Learning paths', labs: 'Laboratories', orbits: 'Gravity and orbits lab', transits: 'Exoplanet transit lab', tutor: 'AI Space Tutor', progress: 'My learning', about: 'Sources and methods' };
let current = null;
function parseHash() {
  const parts = location.hash.replace(/^#\/?/, '').split(/[/?]/).filter(Boolean);
  if (parts[0] === 'explore') return parts[1] ? { name: 'topic', arg: parts[1] } : { name: 'explore' };
  if (parts[0] === 'learn') return parts[1] ? { name: 'lesson', arg: decodeURIComponent(parts[1]) } : { name: 'learn' };
  if (parts[0] === 'labs') {
    if (parts[1] === 'orbits') return { name: 'orbits', arg: parts[2] };
    if (parts[1] === 'transits') return { name: 'transits', arg: parts[2] };
    if (['solar', 'scale', 'spectra', 'blackholes'].includes(parts[1])) return { name: 'labx', arg: parts[1] };
    return { name: 'labs' };
  }
  if (VIEWS.includes(parts[0])) return { name: parts[0] };
  return { name: 'home' };
}
function route() {
  const { name, arg } = parseHash();
  if (current && current !== name && HOOKS[current] && HOOKS[current].leave) HOOKS[current].leave();
  VIEWS.forEach(v => { const el = document.getElementById('view-' + v); if (el) el.hidden = v !== name; });
  $$('[data-nav]').forEach(a => a.dataset.nav === NAV_OF[name] ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'));
  const prev = current; current = name;
  if (HOOKS[name] && HOOKS[name].enter) HOOKS[name].enter(arg, prev);
  const t = HOOKS[name] && HOOKS[name].title ? HOOKS[name].title(arg) : name === 'lesson' && byId[arg] ? byId[arg].title : TITLES[name];
  document.title = `${t} · ${PRODUCT_NAME}`;
  window.scrollTo(0, 0);
  const h1 = $('#view-' + name + ' h1');
  if (h1 && prev) { h1.setAttribute('tabindex', '-1'); h1.focus({ preventScroll: true }); }
}
const HOOKS = {};

/* ======================= Shared orbit drawing (home preview) ======================= */
function drawMiniOrbit(cv, sim, view) {
  const ctx = cv.getContext('2d'); if (!ctx) return;
  const C = cssVars(), dpr = sizeCanvas(cv), W = cv.width, H = cv.height;
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = C.space; ctx.fillRect(0, 0, W, H);
  const k = (Math.min(W, H) / 2) / view.R;
  const sx = x => W / 2 + (x - view.cx) * k, sy = y => H / 2 - (y - view.cy) * k;
  const ox = sx(0), oy = sy(0), el = sim.el;
  ctx.strokeStyle = C.ring; ctx.lineWidth = dpr;
  const far = Math.hypot(W, H) / k;
  for (let r = 0.5; r < far; r += 0.5) { ctx.beginPath(); ctx.arc(ox, oy, r * k, 0, TAU); ctx.stroke(); }
  if (el.p > 1e-10) {
    ctx.save(); ctx.setLineDash([5 * dpr, 6 * dpr]); ctx.strokeStyle = C.pred; ctx.lineWidth = 1.4 * dpr; ctx.beginPath();
    const N = 600, nuMax = el.e < 1 ? Math.PI : Math.acos(-1 / el.e) * 0.9995; let pen = false;
    for (let i = 0; i <= N; i++) {
      const nu = el.e < 1 ? (i / N) * TAU : -nuMax + 2 * nuMax * i / N, r = el.p / (1 + el.e * Math.cos(nu));
      if (!(r > 0) || r > far * 2) { pen = false; continue; }
      const X = sx(r * Math.cos(el.omega + nu)), Y = sy(r * Math.sin(el.omega + nu));
      pen ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y); pen = true;
    }
    ctx.stroke(); ctx.restore();
  }
  const tr = sim.trail;
  if (tr.length > 1) {
    ctx.strokeStyle = C.trail; ctx.lineWidth = 2 * dpr; ctx.lineJoin = 'round';
    ctx.beginPath(); ctx.moveTo(sx(tr[0][0]), sy(tr[0][1]));
    for (let i = 1; i < tr.length; i++) ctx.lineTo(sx(tr[i][0]), sy(tr[i][1]));
    ctx.lineTo(sx(sim.x), sy(sim.y)); ctx.stroke();
  }
  const glow = ctx.createRadialGradient(ox, oy, 0, ox, oy, 26 * dpr);
  glow.addColorStop(0, 'rgba(255,242,214,.55)'); glow.addColorStop(1, 'rgba(255,242,214,0)');
  ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(ox, oy, 26 * dpr, 0, TAU); ctx.fill();
  ctx.fillStyle = '#fff2d6'; ctx.beginPath(); ctx.arc(ox, oy, 7 * dpr, 0, TAU); ctx.fill();
  ctx.fillStyle = C.planet; ctx.beginPath(); ctx.arc(sx(sim.x), sy(sim.y), 4.6 * dpr, 0, TAU); ctx.fill();
}
function frameFor(sim, pad) {
  const el = sim.el, r0 = sim.cfg.r0;
  if (el.bound && el.ra < 6 * r0) { const c = el.a * el.e; return { cx: -c * Math.cos(el.omega), cy: -c * Math.sin(el.omega), R: el.a * pad }; }
  return { cx: 0, cy: 0, R: 2.6 * r0 * pad };
}

/* ======================= Home ======================= */
HOOKS.home = (() => {
  let sim = null, view = null, raf = 0, last = 0, built = false;
  const cfg = v => ({ mass: 1, r0: 1, v0: v, angle: 0, integrator: 'verlet', dtDays: 'auto' });
  function describe(s) {
    const E = s.el.E / s.Enorm;
    if (Math.abs(E) < 0.0025) return 'Escape speed: it never comes back.';
    if (s.el.E > 0) return 'Faster than escape speed: it leaves on a hyperbola.';
    if (s.el.e < 0.005) return 'Circular speed: the distance never changes.';
    return s.cfg.v0 < P.circularSpeedKms(1, 1) ? 'Slower than a circle: it falls inward on an ellipse.' : 'Faster than a circle: it swings outward on an ellipse.';
  }
  const P = PHYS;
  function restart(v) {
    sim = P.createSim(cfg(v)); view = frameFor(sim, 1.2);
    $('#hpSpeedOut').textContent = `${v.toFixed(1)} km/s`;
    $('#hpDesc').textContent = describe(sim);
    if (reduceMotion) { P.advance(sim, sim.tPlay * 0.999, 400000); }
    drawMiniOrbit($('#hpCanvas'), sim, view);
  }
  function loop(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    if (!reduceMotion && sim && !sim.impacted && !sim.escaped) {
      P.advance(sim, dt * sim.tPlay / 7);
      if (sim.trail.length > 760) sim.trail.splice(0, sim.trail.length - 760);
      if (!sim.el.bound && Math.hypot(sim.x, sim.y) > 4) restart(sim.cfg.v0);
      drawMiniOrbit($('#hpCanvas'), sim, view);
    }
    raf = requestAnimationFrame(loop);
  }
  function build() {
    const counts = l => LESSONS.filter(x => x.level === l).length;
    $('#homeLevels').innerHTML = CONTENT.LEVELS.map(L => `<li><span class="lv" aria-hidden="true">${L.n}</span>
      <div><h3>Level ${L.n}: ${esc(L.name)}</h3><p>${esc(L.who)}</p></div>
      ${counts(L.n) ? `<a class="tag ready" href="#/learn">${counts(L.n)} lesson ready</a>` : '<span class="tag">Planned</span>'}</li>`).join('');
    // TRAPPIST-1 planet radii (Agol et al. 2021) next to Earth, drawn to scale
    const TR = [['b', 1.116], ['c', 1.097], ['d', 0.788], ['e', 0.920], ['f', 1.045], ['g', 1.129], ['h', 0.755]];
    let svg = '', x = 30;
    TR.concat([['Earth', 1]]).forEach(([n, r], i) => {
      const rad = 22 * r, earth = n === 'Earth';
      if (earth) x += 12;
      svg += `<circle cx="${x}" cy="78" r="${rad}" fill="${earth ? '#3d7bd1' : '#c9a48a'}" ${earth ? '' : 'fill-opacity="0.92"'}/>`;
      svg += `<text x="${x}" y="128" text-anchor="middle" fill="var(--space-text)" font-size="13" font-weight="700">${n}</text>`;
      svg += `<text x="${x}" y="146" text-anchor="middle" fill="var(--space-label)" font-size="11">${r.toFixed(2)}</text>`;
      x += 55;
    });
    svg += `<text x="10" y="164" fill="var(--space-label)" font-size="11">Radius in Earth radii. Colours are illustrative.</text>`;
    $('#trappistSvg').innerHTML = svg;
    if (typeof EXPLORE !== 'undefined') EXPLORE.mountTiles($('#homeTiles'), ['tonight', 'moon', 'planets', 'eclipses', 'meteors', 'jupiter']);
    const sp = $('#hpSpeed');
    sp.addEventListener('input', () => restart(Number(sp.value)));
    new ResizeObserver(() => sim && drawMiniOrbit($('#hpCanvas'), sim, view)).observe($('#hpCanvas'));
    built = true;
  }
  return {
    enter() { if (!built) build(); restart(Number($('#hpSpeed').value)); last = performance.now(); cancelAnimationFrame(raf); raf = requestAnimationFrame(loop); },
    leave() { cancelAnimationFrame(raf); },
  };
})();

/* ======================= Learn ======================= */
function lessonStatus(id) { const r = Progress.get().lessons[id]; return r ? `<span class="tag done">Done, ${r.best} of ${r.total}</span>` : '<span class="tag ready">Ready</span>'; }
HOOKS.learn = {
  enter() {
    $('#learnPath').innerHTML = CONTENT.LEVELS.map(L => {
      const ls = LESSONS.filter(x => x.level === L.n);
      return `<section aria-labelledby="lvl-${L.n}">
        <div class="lvl-head"><span class="lv" aria-hidden="true">${L.n}</span><div><h2 id="lvl-${L.n}">Level ${L.n}: ${esc(L.name)}</h2><p>${esc(L.who)}</p></div></div>
        ${ls.length ? `<div class="lesson-cards">${ls.map(l => `<a class="lesson-card" href="#/learn/${l.id}">
            <div class="row" style="justify-content:space-between"><span class="meta">${esc(l.category)}</span>${lessonStatus(l.id)}</div>
            <h3>${esc(l.title)}</h3><span class="meta">About ${l.duration} minutes. ${l.prerequisites.length ? 'Builds on ' + l.prerequisites.map(p => esc(byId[p] ? byId[p].title : p)).join(', ') + '.' : 'No prerequisites.'}</span></a>`).join('')}</div>` : ''}
        <p class="planned"><b>Planned:</b> ${L.planned.map(esc).join(', ')}.</p>
      </section>`;
    }).join('');
  },
};

/* ======================= Lesson interactives ======================= */
const LY_KM = 299792.458 * 365.25 * 86400;
const SKY = [
  { id: 'moon', name: 'Moon', km: 384400, when: 'You see the Moon as it was just over a second ago.' },
  { id: 'sun', name: 'Sun', km: 149597870.7, when: 'If the Sun suddenly changed, you would not see it for more than eight minutes.' },
  { id: 'neptune', name: 'Neptune', km: 30.07 * 149597870.7, when: 'Radio commands to a spacecraft at Neptune take this long to arrive.' },
  { id: 'proxima', name: 'Proxima Centauri', short: 'Proxima', km: 4.2465 * LY_KM, when: 'The nearest star to the Sun. Its light left a little over four years ago.' },
  { id: 'sirius', name: 'Sirius', km: 8.60 * LY_KM, when: 'The brightest star in the night sky, as it was about eight and a half years ago.' },
  { id: 'gc', name: 'Centre of the Milky Way', short: 'Galaxy centre', km: 26700 * LY_KM, when: 'That light left during the last ice age.' },
  { id: 'andromeda', name: 'Andromeda galaxy', short: 'Andromeda', km: 2.5e6 * LY_KM, when: 'That light left before modern humans existed.' },
];
function fmtKm(km) {
  if (km >= 0.1 * LY_KM) { const ly = km / LY_KM; return ly >= 1e6 ? `${trimNum(Number((ly / 1e6).toPrecision(2)))} million light-years` : ly >= 1000 ? `${(Math.round(ly / 100) * 100).toLocaleString()} light-years` : `${trimNum(Number(ly.toPrecision(3)))} light-years`; }
  if (km >= 1e9) return `${trimNum(Number((km / 1e9).toPrecision(2)))} billion km`;
  if (km >= 1e6) return `${Math.round(km / 1e6)} million km`;
  return `${Math.round(km).toLocaleString()} km`;
}
function fmtLight(s) {
  if (s < 60) return `${s.toFixed(1)} seconds`;
  if (s < 3600) { const m = Math.floor(s / 60), r = Math.round(s - m * 60); return `${m} min ${r} s`; }
  if (s < 86400 * 2) return `${(s / 3600).toFixed(1)} hours`;
  const y = s / (365.25 * 86400);
  if (y < 1000) return `${trimNum(Number(y.toPrecision(3)))} years`;
  if (y < 1e6) return `${(Math.round(y / 100) * 100).toLocaleString()} years`;
  return `${trimNum(Number((y / 1e6).toPrecision(2)))} million years`;
}

const INTERACTIVES = {
  lightTravel(root) {
    let sel = null, locked = true;
    root.innerHTML = `<div class="ix">
      <div class="ix-canvas" style="aspect-ratio:16/7"><svg id="ltSvg" role="img" aria-label="Distances on a logarithmic scale"></svg></div>
      <div class="ix-ctl"><p id="ltLock">Make your prediction above to unlock the explorer.</p><div class="row" id="ltBtns">${SKY.map(o => `<button class="btn btn-small" data-id="${o.id}" disabled>${o.short || o.name}</button>`).join('')}</div></div>
      <div class="ix-read"><div><span>Distance</span><b id="ltDist">—</b></div><div><span>Light takes</span><b id="ltTime">—</b></div></div>
      <div class="ix-ctl"><p id="ltWhen">Each step right on the scale is ten times farther than the last.</p></div></div>`;
    const svg = $('#ltSvg', root);
    function draw() {
      const r = svg.getBoundingClientRect(), W = Math.max(300, r.width), H = Math.max(120, r.height);
      svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
      const L = 18, Rr = W - 18, y0 = H * 0.55, lo = 5, hi = 20;
      const X = km => L + (Rr - L) * (Math.log10(km) - lo) / (hi - lo);
      let s = `<line x1="${L}" y1="${y0}" x2="${Rr}" y2="${y0}" stroke="var(--space-ring)" stroke-width="2"/>`;
      for (let d = lo; d <= hi; d++) {
        const x = X(10 ** d), major = d % 5 === 0;
        s += `<line x1="${x}" y1="${y0 - (major ? 6 : 3)}" x2="${x}" y2="${y0 + (major ? 6 : 3)}" stroke="var(--space-label)" stroke-width="1"/>`;
        if (major) s += `<text x="${x}" y="${H - 6}" text-anchor="middle" fill="var(--space-label)" font-size="11">10${d === 5 ? '⁵' : d === 10 ? '¹⁰' : d === 15 ? '¹⁵' : '²⁰'} km</text>`;
      }
      const ly = X(LY_KM);
      s += `<line x1="${ly}" y1="${y0 - 40}" x2="${ly}" y2="${y0 + 8}" stroke="var(--violet)" stroke-dasharray="3 3"/><text x="${ly - 4}" y="${y0 - 34}" text-anchor="end" fill="var(--space-label)" font-size="11">1 light-year</text>`;
      SKY.forEach((o, i) => {
        const x = X(o.km), up = i % 2 === 0, on = sel === o.id;
        s += `<circle cx="${x}" cy="${y0}" r="${on ? 7 : 4.5}" fill="${on ? 'var(--trail)' : 'var(--space-text)'}"/>`;
        s += `<text x="${clamp(x, 30, W - 30)}" y="${up ? y0 - 16 : y0 + 22}" text-anchor="middle" fill="${on ? 'var(--trail)' : 'var(--space-label)'}" font-size="${on ? 13 : 11}" font-weight="${on ? 700 : 400}">${esc(o.short || o.name)}</text>`;
      });
      svg.innerHTML = s;
    }
    function select(id) {
      sel = id; const o = SKY.find(x => x.id === id);
      $$('#ltBtns .btn', root).forEach(b => b.classList.toggle('on', b.dataset.id === id));
      $('#ltDist', root).textContent = fmtKm(o.km);
      $('#ltTime', root).textContent = fmtLight(o.km / 299792.458);
      $('#ltWhen', root).textContent = `${o.name}: ${o.when}`;
      draw();
    }
    $('#ltBtns', root).addEventListener('click', e => { const b = e.target.closest('button'); if (b && !locked) select(b.dataset.id); });
    const ro = new ResizeObserver(draw); ro.observe(svg);
    draw();
    return {
      unlock(action) { locked = false; $$('#ltBtns .btn', root).forEach(b => b.disabled = false); $('#ltLock', root).textContent = 'Pick anything to see how far it is and how long its light takes to reach us.'; if (action) select(action); },
      destroy() { ro.disconnect(); },
    };
  },

  newtonCannon(root) {
    const MU = 398600.4418, RE = 6371, H0 = 300, r0 = RE + H0;
    const vc = Math.sqrt(MU / r0), ve = Math.sqrt(2 * MU / r0);
    let shots = [], shot = null, raf = 0, last = 0, locked = true;
    root.innerHTML = `<div class="ix">
      <div class="ix-canvas square"><canvas id="ncCanvas" role="img" aria-label="Earth with a cannon on a 300 km mountain"></canvas></div>
      <div class="ix-ctl">
        <div class="field-head"><label for="ncSpeed">Launch speed</label><output id="ncOut">5.0 km/s</output></div>
        <input type="range" id="ncSpeed" min="0" max="12" step="0.05" value="5" disabled>
        <p>Circular speed here is ${vc.toFixed(2)} km/s; escape speed is ${ve.toFixed(2)} km/s. No air resistance in this model.</p>
        <div class="row"><button class="btn btn-primary btn-small" id="ncFire" disabled>Fire</button><button class="btn btn-small" id="ncClear" disabled>Clear paths</button></div>
        <p id="ncLock">Make your prediction above to unlock the cannon.</p>
      </div>
      <div class="ix-read"><div><span>Result</span><b id="ncRes">Waiting to fire</b></div><div><span>Flight time</span><b id="ncTime">—</b></div></div></div>`;
    const cv = $('#ncCanvas', root);
    function fire(v) {
      if (shot) shots.push(shot);
      if (shots.length > 4) shots.shift();
      shot = { x: 0, y: r0, vx: v, vy: 0, t: 0, pts: [[0, r0]], theta: 0, done: false, res: 'Flying', T: null };
      const E = v * v / 2 - MU / r0;
      if (E < 0) { const a = -MU / (2 * E); shot.T = TAU * Math.sqrt(a * a * a / MU); }
      $('#ncRes', root).textContent = 'Flying'; last = performance.now();
      if (reduceMotion) { while (!shot.done) stepShot(30); draw(); } else { cancelAnimationFrame(raf); raf = requestAnimationFrame(loop); }
    }
    function stepShot(simSeconds) {
      const s = shot, dt = 2;
      for (let n = 0; n < simSeconds / dt && !s.done; n++) {
        let r = Math.hypot(s.x, s.y), r3 = r * r * r;
        const ax = -MU * s.x / r3, ay = -MU * s.y / r3;
        const hx = s.vx + 0.5 * dt * ax, hy = s.vy + 0.5 * dt * ay;
        const px = s.x, py = s.y;
        s.x += dt * hx; s.y += dt * hy;
        r = Math.hypot(s.x, s.y); r3 = r * r * r;
        s.vx = hx + 0.5 * dt * (-MU * s.x / r3); s.vy = hy + 0.5 * dt * (-MU * s.y / r3);
        s.t += dt;
        let d = Math.atan2(s.x, s.y) - Math.atan2(px, py); if (d > Math.PI) d -= TAU; if (d < -Math.PI) d += TAU; s.theta += d;
        if (n % 5 === 0) s.pts.push([s.x, s.y]);
        if (r <= RE) { s.done = true; s.pts.push([s.x, s.y]); const dkm = Math.abs(s.theta) * RE; s.res = dkm < 5 ? 'Fell straight down' : `Landed ${Math.round(dkm).toLocaleString()} km away`; }
        else if (Math.abs(s.theta) >= TAU && s.res === 'Flying') { s.res = `Orbit: back at the cannon after ${Math.round(s.t / 60)} min`; }
        if (s.T && s.t > Math.min(3 * s.T, 86400)) s.done = true;
        if (!s.T && r > 4 * RE) { s.done = true; s.res = 'Escaped: it will never come back'; }
        if (s.T && r > 4 * RE && s.res === 'Flying') s.res = 'Off the screen, but it will come back';
      }
      $('#ncRes', root).textContent = s.res;
      $('#ncTime', root).textContent = s.t < 5400 ? `${Math.round(s.t / 60)} minutes` : `${(s.t / 3600).toFixed(1)} hours`;
    }
    function draw() {
      const ctx = cv.getContext('2d'); if (!ctx) return;
      const C = cssVars(), dpr = sizeCanvas(cv), W = cv.width, Hh = cv.height;
      ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = C.space; ctx.fillRect(0, 0, W, Hh);
      const k = Math.min(W, Hh) / 2 / (RE * 2.05), cx = W / 2, cy = Hh / 2 + RE * 0.25 * k;
      const S = (x, y) => [cx + x * k, cy - y * k];
      const g = ctx.createRadialGradient(cx - RE * k * 0.3, cy - RE * k * 0.3, RE * k * 0.1, cx, cy, RE * k);
      g.addColorStop(0, '#3d7bd1'); g.addColorStop(1, '#173a6b');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, RE * k, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(160,200,255,.45)'; ctx.lineWidth = 1.5 * dpr; ctx.stroke();
      // mountain (height to scale)
      const [mx, my] = S(0, RE), [tx, ty] = S(0, r0);
      ctx.fillStyle = '#7d8aa0'; ctx.beginPath(); ctx.moveTo(mx - 26 * dpr, my + 6 * dpr); ctx.lineTo(tx, ty); ctx.lineTo(mx + 26 * dpr, my + 6 * dpr); ctx.closePath(); ctx.fill();
      ctx.fillStyle = C.grav; ctx.fillRect(tx - 3 * dpr, ty - 4 * dpr, 14 * dpr, 6 * dpr);
      const path = (pts, alpha, color) => { if (pts.length < 2) return; ctx.globalAlpha = alpha; ctx.strokeStyle = color; ctx.lineWidth = 2 * dpr; ctx.beginPath(); pts.forEach((p, i) => { const [X, Y] = S(p[0], p[1]); i ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y); }); ctx.stroke(); ctx.globalAlpha = 1; };
      shots.forEach((s, i) => path(s.pts, 0.25 + 0.1 * i, C.label));
      if (shot) {
        path(shot.pts.concat([[shot.x, shot.y]]), 1, C.trail);
        if (!(Math.hypot(shot.x, shot.y) <= RE)) { const [X, Y] = S(shot.x, shot.y); ctx.fillStyle = C.planet; ctx.beginPath(); ctx.arc(X, Y, 4 * dpr, 0, TAU); ctx.fill(); }
      }
      ctx.fillStyle = C.label; ctx.font = `${11 * dpr}px ${FONT}`; ctx.textAlign = 'left';
      ctx.fillText('Mountain height to scale: 300 km', 10 * dpr, Hh - 10 * dpr);
    }
    function loop(now) {
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      if (shot && !shot.done) { stepShot(dt * 900); draw(); raf = requestAnimationFrame(loop); } else draw();
    }
    const sp = $('#ncSpeed', root);
    sp.addEventListener('input', () => { $('#ncOut', root).textContent = `${Number(sp.value).toFixed(2)} km/s`; });
    $('#ncFire', root).addEventListener('click', () => fire(Number(sp.value)));
    $('#ncClear', root).addEventListener('click', () => { shots = []; shot = null; $('#ncRes', root).textContent = 'Waiting to fire'; $('#ncTime', root).textContent = '—'; draw(); });
    const ro = new ResizeObserver(draw); ro.observe(cv);
    draw();
    return {
      unlock(action) {
        locked = false; [sp, $('#ncFire', root), $('#ncClear', root)].forEach(e => e.disabled = false);
        $('#ncLock', root).textContent = 'Try slower and faster speeds. Earlier paths stay faint so you can compare.';
        if (action === 'circ') { sp.value = vc.toFixed(2); $('#ncOut', root).textContent = `${vc.toFixed(2)} km/s`; fire(vc); }
      },
      destroy() { cancelAnimationFrame(raf); ro.disconnect(); },
    };
  },

  transitMini(root) {
    const planets = { earth: { name: 'Earth-size', Rp: 1 }, neptune: { name: 'Neptune-size', Rp: 3.865 }, jupiter: { name: 'Jupiter-size', Rp: 10.97 } };
    let key = 'earth', sys = null, t0 = performance.now(), raf = 0, locked = true;
    root.innerHTML = `<div class="ix">
      <div class="ix-canvas" style="aspect-ratio:16/8"><canvas id="tmStar" role="img" aria-label="A planet crossing a Sun-like star"></canvas></div>
      <div class="ix-canvas" style="aspect-ratio:16/6;border-top:1px solid var(--space-chip-line)"><canvas id="tmCurve" role="img" aria-label="Light curve"></canvas></div>
      <div class="ix-ctl"><p id="tmLock">Make your prediction above to unlock the planets.</p><div class="row" id="tmBtns">${Object.entries(planets).map(([k, p]) => `<button class="btn btn-small" data-k="${k}" disabled>${p.name}</button>`).join('')}</div>
      <p>All three on Earth's orbit around a Sun-like star. Planet sizes are to scale.</p></div>
      <div class="ix-read"><div><span>Star dims by</span><b id="tmDepth">—</b></div><div><span>Transit lasts</span><b id="tmDur">—</b></div></div></div>`;
    function setPlanet(k) {
      key = k; sys = TRANSIT.system({ Ms: 1, Rs: 1, Rp: planets[k].Rp, P: 365.25, b: 0.15 });
      $$('#tmBtns .btn', root).forEach(b => b.classList.toggle('on', b.dataset.k === k));
      $('#tmDepth', root).textContent = fmtDepth(sys.depthMax);
      $('#tmDur', root).textContent = `${(sys.T14 * 24).toFixed(1)} hours`;
      t0 = performance.now();
    }
    function frame(now) {
      const half = sys.T14 * 0.8, period = reduceMotion ? Infinity : 6000;
      const t = isFinite(period) ? -half + 2 * half * (((now - t0) % period) / period) : 0;
      TransitDraw.star($('#tmStar', root), sys, t, { color: [255, 242, 214] });
      TransitDraw.curve($('#tmCurve', root), sys, { half, t, points: null });
      if (!reduceMotion) raf = requestAnimationFrame(frame);
    }
    $('#tmBtns', root).addEventListener('click', e => { const b = e.target.closest('button'); if (b && !locked) { setPlanet(b.dataset.k); if (reduceMotion) frame(performance.now()); } });
    setPlanet('earth');
    raf = requestAnimationFrame(frame);
    const ro = new ResizeObserver(() => reduceMotion && frame(performance.now())); ro.observe($('#tmStar', root));
    return {
      unlock(action) { locked = false; $$('#tmBtns .btn', root).forEach(b => b.disabled = false); $('#tmLock', root).textContent = 'Switch planets and compare the dips.'; if (action) setPlanet(action); if (reduceMotion) frame(performance.now()); },
      destroy() { cancelAnimationFrame(raf); ro.disconnect(); },
    };
  },
};
function fmtDepth(d) { if (d <= 0) return 'No dip'; const ppm = d * 1e6; return ppm < 1000 ? `${Math.round(ppm)} ppm (${(d * 100).toPrecision(2)}%)` : `${(d * 100).toPrecision(3)}%`; }

/* ---------- Transit drawing shared by the lesson and the lab ---------- */
const TransitDraw = {
  star(cv, sys, t, opt = {}) {
    const ctx = cv.getContext('2d'); if (!ctx) return;
    const C = cssVars(), dpr = sizeCanvas(cv), W = cv.width, H = cv.height;
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = C.space; ctx.fillRect(0, 0, W, H);
    const R = Math.min(W * 0.3, H * 0.4), cx = W / 2, cy = H / 2;
    const [r, g, b] = opt.color || [255, 242, 214];
    const glow = ctx.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 1.35);
    glow.addColorStop(0, `rgba(${r},${g},${b},.35)`); glow.addColorStop(1, `rgba(${r},${g},${b},0)`);
    ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(cx, cy, R * 1.35, 0, TAU); ctx.fill();
    ctx.fillStyle = `rgb(${r},${g},${b})`; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fill();
    // transit chord
    ctx.save(); ctx.setLineDash([4 * dpr, 5 * dpr]); ctx.strokeStyle = C.label; ctx.lineWidth = dpr;
    ctx.beginPath(); ctx.moveTo(0, cy - sys.b * R); ctx.lineTo(W, cy - sys.b * R); ctx.stroke(); ctx.restore();
    const q = TRANSIT.position(sys, t);
    if (q.front) {
      const px = cx + q.x * R, py = cy - q.y * R, pr = Math.max(sys.k * R, 0.8 * dpr);
      ctx.fillStyle = '#05070c'; ctx.beginPath(); ctx.arc(px, py, pr, 0, TAU); ctx.fill();
      if (pr >= 5 * dpr) { ctx.strokeStyle = C.label; ctx.lineWidth = dpr; ctx.stroke(); }
      if (pr < 5 * dpr) { ctx.strokeStyle = C.trail; ctx.lineWidth = 1.4 * dpr; ctx.beginPath(); ctx.arc(px, py, 9 * dpr, 0, TAU); ctx.stroke(); }
    }
    ctx.fillStyle = C.label; ctx.font = `${11 * dpr}px ${FONT}`; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    ctx.fillText(opt.caption || 'Simulated view from Earth. Star and planet sizes to scale.', 10 * dpr, H - 8 * dpr);
  },
  curve(cv, sys, o) {
    const ctx = cv.getContext('2d'); if (!ctx) return;
    const C = cssVars(), dpr = sizeCanvas(cv), W = cv.width, H = cv.height;
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = C.space; ctx.fillRect(0, 0, W, H);
    const half = o.half, sig = o.sigma || 0, depth = Math.max(sys.depthMax, 1e-6);
    let lo = 1 - depth * 1.25 - 3 * sig, hi = 1 + depth * 0.3 + 3 * sig;
    if (o.estimate != null) lo = Math.min(lo, 1 - o.estimate * 1.05);
    const L = 64 * dpr, Rm = 10 * dpr, T = 12 * dpr, B = 22 * dpr;
    const X = t => L + (W - L - Rm) * (t + half) / (2 * half), Y = f => T + (H - T - B) * (hi - f) / (hi - lo);
    ctx.strokeStyle = C.ring; ctx.lineWidth = dpr;
    ctx.beginPath(); ctx.moveTo(L, Y(1)); ctx.lineTo(W - Rm, Y(1)); ctx.stroke();
    ctx.fillStyle = C.label; ctx.font = `${11 * dpr}px ${FONT}`; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    const pct = f => { const d = (1 - f) * 100; const dec = depth * 100 < 0.05 ? 4 : depth * 100 < 0.5 ? 3 : 2; return (100 - d).toFixed(dec) + '%'; };
    ctx.fillText('100%', L - 6 * dpr, Y(1)); ctx.fillText(pct(1 - sys.depthMax), L - 6 * dpr, Y(1 - sys.depthMax));
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    const hrs = half * 24, stepH = niceStep(hrs / 2);
    for (let h = -Math.floor(hrs / stepH) * stepH; h <= hrs; h += stepH) ctx.fillText(`${trimNum(h)} h`, X(h / 24), H - 4 * dpr);
    if (o.points) {
      ctx.fillStyle = C.label;
      for (const [t, f] of o.points) { const x = X(t), y = Y(f); if (y > 0 && y < H) { ctx.beginPath(); ctx.arc(x, y, 1.9 * dpr, 0, TAU); ctx.fill(); } }
    }
    ctx.strokeStyle = C.trail; ctx.lineWidth = 2 * dpr; ctx.beginPath();
    const N = 600;
    for (let i = 0; i <= N; i++) { const t = -half + 2 * half * i / N, x = X(t), y = Y(TRANSIT.flux(sys, t)); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
    ctx.stroke();
    if (o.estimate != null) {
      ctx.save(); ctx.setLineDash([6 * dpr, 4 * dpr]); ctx.strokeStyle = C.grav; ctx.lineWidth = 1.6 * dpr;
      const y = Y(1 - o.estimate); ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(W - Rm, y); ctx.stroke(); ctx.restore();
      ctx.fillStyle = C.grav; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom'; ctx.fillText('your estimate', L + 4 * dpr, y - 3 * dpr);
    }
    if (o.t != null) { ctx.strokeStyle = C.text; ctx.globalAlpha = .5; ctx.lineWidth = dpr; ctx.beginPath(); ctx.moveTo(X(o.t), T); ctx.lineTo(X(o.t), H - B); ctx.stroke(); ctx.globalAlpha = 1; }
  },
};

/* ======================= Lesson player ======================= */
const STEP_NAMES = ['The question', 'The ideas', 'Predict and test', 'Check yourself', 'Sources and next'];
HOOKS.lesson = (() => {
  let ls = null, step = 0, seen = 0, ix = null, predicted = false, answers = [];
  function srcHtml(id) { const s = CONTENT.SOURCES[id]; if (!s) return ''; return `<li>${esc(s.cite)} ${s.url ? `<a href="${s.url}" target="_blank" rel="noopener">Open source</a>` : ''}<br><span class="kind">${esc(s.kind)}</span></li>`; }
  function header() {
    const lv = CONTENT.LEVELS[ls.level];
    return `<p class="crumbs"><a href="#/learn">Learning paths</a> / Level ${ls.level}: ${esc(lv.name)}</p>
      <h1 class="lesson-title">${esc(ls.title)}</h1>
      <p class="lesson-meta">${esc(ls.category)}. About ${ls.duration} minutes.</p>
      <details class="info"><summary>Lesson details</summary><div class="info-body"><dl>
        <dt>Lesson ID</dt><dd>${ls.id}</dd>
        <dt>Level</dt><dd>${ls.level}, ${esc(lv.name)}</dd>
        <dt>Builds on</dt><dd>${ls.prerequisites.length ? ls.prerequisites.map(p => `<a href="#/learn/${p}">${esc(byId[p] ? byId[p].title : p)}</a>`).join(', ') : 'Nothing; start here'}</dd>
        <dt>You will</dt><dd><ul>${ls.objectives.map(o => `<li>${esc(o)}</li>`).join('')}</ul></dd>
        <dt>Assessment</dt><dd>${esc(ls.assessment)}</dd>
        <dt>Last reviewed</dt><dd>${CONTENT.REVIEWED}, internal check only. Not yet reviewed by an external astronomer.</dd>
      </dl></div></details>
      <ol class="steps" id="lsSteps">${STEP_NAMES.map((n, i) => `<li><button data-i="${i}" data-n="${i + 1}"><span class="lbl">${i + 1}. ${n}</span></button></li>`).join('')}</ol>
      <div id="lsStep"></div>
      <div class="step-nav"><button class="btn" id="lsBack">Back</button><button class="btn btn-primary" id="lsNext">Next</button></div>`;
  }
  function renderStep() {
    if (ix && step !== 2) { ix.destroy(); ix = null; }
    const box = $('#lsStep');
    if (step === 0) box.innerHTML = `<section class="step"><h2 class="sr">The question</h2><p class="big-q">${esc(ls.hook.question)}</p><p>${esc(ls.hook.text)}</p>
      <div class="callout"><h3>Why it matters</h3><p>${esc(ls.why)}</p></div></section>`;
    if (step === 1) box.innerHTML = `<section class="step"><h2>The ideas</h2>${ls.concepts.map(c => `<h3>${esc(c.h)}</h3><p>${esc(c.p)}</p>`).join('')}
      ${ls.formulas.map(f => `<div class="formula"><span class="m">${f.html}</span><small>${f.label}</small></div>`).join('')}
      <h3>Key terms</h3><dl class="terms">${ls.terms.map(t => `<dt>${esc(t.t)}</dt><dd>${esc(t.d)}</dd>`).join('')}</dl></section>`;
    if (step === 2) {
      if (ix) { ix.destroy(); ix = null; }
      const p = ls.predict;
      box.innerHTML = `<section class="step"><h2>Predict and test</h2>
        <div class="predict-box"><p class="q">${esc(p.q)}</p><div class="opts" id="lsPred">${p.options.map((o, i) => `<button class="opt" data-i="${i}"><span>${esc(o)}</span><span class="mark"></span></button>`).join('')}</div>
        <p class="feedback" id="lsReveal" aria-live="polite" hidden></p></div><div id="lsIx"></div></section>`;
      ix = INTERACTIVES[ls.interactive]($('#lsIx'));
      if (predicted) markPrediction(predicted.i, false);
      $('#lsPred').addEventListener('click', e => { const b = e.target.closest('.opt'); if (b && !predicted) markPrediction(Number(b.dataset.i), true); });
    }
    if (step === 3) {
      box.innerHTML = `<section class="step"><h2>Check yourself</h2><h3>Watch out for</h3><ul class="myths">${ls.misconceptions.map(m => `<li><p class="myth"><s>${esc(m.myth)}</s></p><p class="fact">${esc(m.fact)}</p></li>`).join('')}</ul>
        <h3>Three quick questions</h3><ol class="quiz" id="lsQuiz">${ls.checks.map((c, qi) => `<li data-q="${qi}"><p class="q">${esc(c.q)}</p><div class="opts">${c.options.map((o, i) => `<button class="opt" data-i="${i}"><span>${esc(o)}</span><span class="mark"></span></button>`).join('')}</div><p class="feedback" aria-live="polite" hidden></p></li>`).join('')}</ol>
        <div id="lsScore"></div></section>`;
      answers.forEach((a, qi) => a != null && markAnswer(qi, a));
      if (answers.filter(a => a != null).length === ls.checks.length) showScore(false);
      $('#lsQuiz').addEventListener('click', e => { const b = e.target.closest('.opt'); if (!b) return; const qi = Number(b.closest('li').dataset.q); if (answers[qi] != null) return; answers[qi] = Number(b.dataset.i); markAnswer(qi, answers[qi]); if (answers.filter(a => a != null).length === ls.checks.length) showScore(true); });
    }
    if (step === 4) {
      const done = Progress.get().lessons[ls.id];
      box.innerHTML = `<section class="step"><h2>Sources and next steps</h2>
        ${done ? `<div class="score"><p><b>Lesson complete.</b> First attempt: ${done.score} of ${done.total} correct.</p></div>` : `<div class="callout"><p>Answer the three questions in step 4 to complete this lesson.</p></div>`}
        <h3>Where these facts come from</h3><ol class="src-list">${ls.sources.map(srcHtml).join('')}</ol>
        <p class="muted" style="margin-top:10px">Reviewed ${CONTENT.REVIEWED}. See <a href="#/about">sources and methods</a> for how sources are ranked.</p>
        <h3>Keep going</h3><div class="next-links">${ls.next.map(n => `<a class="btn" href="${n.href}">${esc(n.label)}</a>`).join('')}<a class="btn needs-claude" href="#/tutor?lesson=${ls.id}">Ask the tutor about this lesson</a></div></section>`;
    }
    $$('#lsSteps button').forEach((b, i) => { b.toggleAttribute('aria-current', i === step); if (i === step) b.setAttribute('aria-current', 'step'); b.classList.toggle('seen', i <= seen); b.disabled = i > seen; });
    $('#lsBack').disabled = step === 0;
    const next = $('#lsNext');
    if (step === 4) { next.textContent = 'All lessons'; next.disabled = false; }
    else { next.textContent = 'Next'; next.disabled = step === 2 && !predicted; }
    if (step === 2 && !predicted) next.title = 'Make a prediction first'; else next.removeAttribute('title');
  }
  function markPrediction(i, fresh) {
    const p = ls.predict; predicted = { i };
    $$('#lsPred .opt').forEach((b, j) => {
      b.disabled = true;
      if (j === p.answer) { b.classList.add('is-correct'); $('.mark', b).textContent = j === i ? 'Your prediction, correct' : 'Answer'; }
      else if (j === i) { b.classList.add('is-wrong'); $('.mark', b).textContent = 'Your prediction'; }
    });
    const r = $('#lsReveal'); r.hidden = false;
    r.innerHTML = `<b>${i === p.answer ? 'You predicted it.' : 'Not this time.'}</b> ${esc(p.reveal)}`;
    if (ix) ix.unlock(fresh ? (p.select || p.fire) : null);
    if (fresh) Progress.prediction('lesson:' + ls.id, i === p.answer);
    $('#lsNext').disabled = false; $('#lsNext').removeAttribute('title');
  }
  function markAnswer(qi, i) {
    const c = ls.checks[qi], li = $(`#lsQuiz li[data-q="${qi}"]`);
    $$('.opt', li).forEach((b, j) => {
      b.disabled = true;
      if (j === c.answer) { b.classList.add('is-correct'); $('.mark', b).textContent = j === i ? 'Correct' : 'Answer'; }
      else if (j === i) { b.classList.add('is-wrong'); $('.mark', b).textContent = 'Your answer'; }
    });
    const f = $('.feedback', li); f.hidden = false; f.innerHTML = `<b>${i === c.answer ? 'Correct.' : 'Not quite.'}</b> ${esc(c.why)}`;
  }
  function showScore(fresh) {
    const firstTry = answers.map((a, i) => a === ls.checks[i].answer), score = firstTry.filter(Boolean).length;
    if (fresh) Progress.lesson(ls.id, { score, total: ls.checks.length, firstTry });
    $('#lsScore').innerHTML = `<div class="score"><p><b>${score} of ${ls.checks.length} correct.</b> ${score >= 2 ? 'That counts toward mastery of ' + esc(ls.category.toLowerCase()) + '.' : 'Worth revisiting the ideas in step 2.'} Your first answers are what count.</p></div>`;
    seen = Math.max(seen, 4); renderStepsNav();
  }
  function renderStepsNav() { $$('#lsSteps button').forEach((b, i) => { b.classList.toggle('seen', i <= seen); b.disabled = i > seen; }); }
  function go(i) { step = clamp(i, 0, 4); seen = Math.max(seen, step); renderStep(); window.scrollTo(0, $('#lsSteps').getBoundingClientRect().top + window.scrollY - 12); }
  return {
    enter(id) {
      if (ix) { ix.destroy(); ix = null; }
      ls = byId[id];
      const root = $('#lessonRoot');
      if (!ls) { root.innerHTML = `<div class="page-head"><h1>Lesson not found</h1><p>There is no lesson called "${esc(id || '')}". <a href="#/learn">See all lessons</a>.</p></div>`; return; }
      step = 0; seen = 0; predicted = false; answers = new Array(ls.checks.length).fill(null);
      if (Progress.get().lessons[ls.id]) seen = 4;
      root.innerHTML = header();
      $('#lsSteps').addEventListener('click', e => { const b = e.target.closest('button'); if (b && !b.disabled) go(Number(b.dataset.i)); });
      $('#lsBack').addEventListener('click', () => go(step - 1));
      $('#lsNext').addEventListener('click', () => { if (step === 4) location.hash = '#/learn'; else go(step + 1); });
      renderStep();
    },
    leave() { if (ix) { ix.destroy(); ix = null; } },
  };
})();

/* ======================= Labs index ======================= */
HOOKS.labs = {
  enter() {
    $('#labCards').innerHTML = CONTENT.LABS.map(l => l.status === 'ready'
      ? `<a class="lab-card" href="#/labs/${l.id}"><div class="row" style="justify-content:space-between"><h3>${esc(l.title)}</h3>${Progress.get().labs[l.id] ? '<span class="tag done">Explored</span>' : '<span class="tag ready">Ready</span>'}</div><p class="muted">Levels ${l.levels}</p><p>${esc(l.blurb)}</p></a>`
      : `<div class="lab-card planned-card"><div class="row" style="justify-content:space-between"><h3>${esc(l.title)}</h3><span class="tag">Planned</span></div><p>${esc(l.blurb)}</p></div>`).join('');
  },
};

/* ======================= Progress ======================= */
HOOKS.progress = (() => {
  let off = null, armed = 0;
  function render() {
    const st = Progress.get(), done = LESSONS.filter(l => st.lessons[l.id]);
    const checks = done.reduce((a, l) => { const r = st.lessons[l.id]; a.c += r.score; a.t += r.total; return a; }, { c: 0, t: 0 });
    const preds = Object.values(st.predictions), predOk = preds.filter(p => p.correct).length;
    const labs = Object.keys(st.labs).length;
    const cats = [...new Set(LESSONS.map(l => l.category))];
    const topicPreds = { 'Scale and distance': ['lesson:L0-SCALE-01'], 'Gravity and orbits': ['lesson:L1-ORB-01', 'orbit:'], 'Exoplanets': ['lesson:L2-EXO-01', 'transit:'] };
    const mastery = cats.map(cat => {
      let c = 0, t = 0;
      LESSONS.filter(l => l.category === cat).forEach(l => { const r = st.lessons[l.id]; if (r) { c += r.score; t += r.total; } });
      Object.entries(st.predictions).forEach(([k, p]) => { if ((topicPreds[cat] || []).some(pre => k === pre || (pre.endsWith(':') && k.startsWith(pre)))) { t++; if (p.correct) c++; } });
      return { cat, c, t };
    });
    const next = LESSONS.find(l => !st.lessons[l.id] && l.prerequisites.every(p => st.lessons[p])) || LESSONS.find(l => !st.lessons[l.id]);
    const mode = Progress.mode();
    $('#progressRoot').innerHTML = `
      <div class="stats">
        <div class="stat"><b>${done.length} of ${LESSONS.length}</b><span>lessons complete</span></div>
        <div class="stat"><b>${checks.t ? `${checks.c} of ${checks.t}` : '—'}</b><span>questions right first time</span></div>
        <div class="stat"><b>${preds.length}</b><span>predictions made${preds.length ? `, ${predOk} correct` : ''}</span></div>
        <div class="stat"><b>${labs} of ${CONTENT.LABS.filter(l => l.status === 'ready').length}</b><span>labs explored</span></div>
      </div>
      <section class="section"><h2>Continue learning</h2>
        ${next ? `<p class="lead">Next up: <b>${esc(next.title)}</b> (Level ${next.level}, about ${next.duration} minutes).</p><a class="btn btn-primary" href="#/learn/${next.id}">${done.length ? 'Continue with this lesson' : 'Start the first lesson'}</a>` : `<p class="lead">You have finished every lesson that's written so far. Try the labs' experiments, or ask the tutor something you're curious about.</p><a class="btn btn-primary" href="#/labs">Open the labs</a>`}
      </section>
      <section class="section"><h2>Topic mastery</h2><p class="lead">Share of first answers and predictions you got right in each topic. It means more as the count grows.</p>
        <ul class="mastery">${mastery.map(m => `<li><div class="mh"><b>${esc(m.cat)}</b><span class="muted">${m.t ? `${m.c} of ${m.t} answers` : 'Not started'}</span></div><div class="bar" role="img" aria-label="${m.t ? Math.round(100 * m.c / m.t) : 0}%"><i style="width:${m.t ? (100 * m.c / m.t).toFixed(0) : 0}%"></i></div></li>`).join('')}</ul></section>
      <section class="section"><h2>Completed lessons</h2>
        ${done.length ? `<ul class="done-list">${done.map(l => { const r = st.lessons[l.id]; return `<li><a href="#/learn/${l.id}">${esc(l.title)}</a><span class="muted">${r.score} of ${r.total} first try</span></li>`; }).join('')}</ul>` : '<p class="lead">None yet. Lessons take about 10 to 15 minutes each.</p>'}
      </section>
      <section class="section"><h2>Where this is saved</h2>
        <p class="sync">${document.documentElement.classList.contains('public') ? 'Saved in this browser only. Nothing is sent anywhere; clearing your browser data erases it.' : mode === 'account' ? 'Saved privately to your Claude account, so it follows you between devices. Only you can see it.' : mode === 'readonly' ? 'Saved in this browser only. Your access level on this page does not allow saving to your account.' : 'Saved in this browser only. Open this page signed in to claude.ai to keep it in your account.'}</p>
        <div class="row" style="margin-top:10px"><button class="btn btn-small" id="resetProg">Erase my progress</button></div>
      </section>`;
    $('#resetProg').addEventListener('click', e => {
      if (Date.now() - armed < 5000) { Progress.reset(); armed = 0; return; }
      armed = Date.now(); e.target.textContent = 'Tap again to erase everything';
      setTimeout(() => { if (Date.now() - armed >= 5000 && $('#resetProg')) $('#resetProg').textContent = 'Erase my progress'; }, 5100);
    });
  }
  return { enter() { render(); off = Progress.on(render); }, leave() { off && off(); } };
})();

/* ======================= About ======================= */
HOOKS.about = (() => {
  let built = false;
  return { enter() {
    if (built) return; built = true;
    const groups = {};
    Object.entries(CONTENT.SOURCES).forEach(([id, s]) => { (groups[s.tier] = groups[s.tier] || []).push([id, s]); });
    $('#allSources').innerHTML = Object.keys(groups).sort().map(t => groups[t].map(([id, s]) => `<li>${esc(s.cite)} ${s.url ? `<a href="${s.url}" target="_blank" rel="noopener">Open source</a>` : ''}<br><span class="kind">${esc(s.kind)}, tier ${s.tier}</span></li>`).join('')).join('');
  } };
})();

/* ======================= Boot ======================= */
function boot() {
  $$('.pn').forEach(n => n.textContent = PRODUCT_NAME);
  window.addEventListener('hashchange', route);
  route();
  Progress.connect();
}
return { boot, route, Progress, HOOKS, $, $$, esc, clamp, cssVars, sizeCanvas, niceStep, trimNum, reduceMotion, TransitDraw, fmtDepth, LESSONS, byId, PRODUCT_NAME, FONT };
})();
