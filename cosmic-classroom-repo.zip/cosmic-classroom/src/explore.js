/* ---------- Explore: hub + topic screens with live sky data and procedural illustrations ---------- */
const EXPLORE = (() => {
'use strict';
const { $, $$, esc, clamp, sizeCanvas, reduceMotion } = APP;
const A = ASTRO, TAU = Math.PI * 2, D2R = Math.PI / 180;
const FONT = APP.FONT;

/* ======================= Data ======================= */
const WORLDS = [ // NASA NSSDCA planetary fact sheets
  { id: 'mercury', name: 'Mercury', d: 4879, g: 3.7, day: 4222.6, year: 88.0, dist: 57.9, temp: 167, kind: 'Rocky planet', color: '#b7b0a7',
    blurb: 'The smallest planet and the closest to the Sun. With almost no atmosphere, it swings from about 430 °C by day to −180 °C at night.' },
  { id: 'venus', name: 'Venus', d: 12104, g: 8.9, day: 2802.0, year: 224.7, dist: 108.2, temp: 464, kind: 'Rocky planet', color: '#f3e3b3',
    blurb: 'Similar in size to Earth, but its thick carbon-dioxide atmosphere traps heat, making it the hottest planet. It spins backwards, very slowly.' },
  { id: 'earth', name: 'Earth', d: 12756, g: 9.8, day: 24.0, year: 365.2, dist: 149.6, temp: 15, kind: 'Rocky planet', color: '#5b9be0',
    blurb: 'The only world known to have life and oceans of liquid water on its surface.' },
  { id: 'mars', name: 'Mars', d: 6792, g: 3.7, day: 24.7, year: 687.0, dist: 228.0, temp: -65, kind: 'Rocky planet', color: '#e07a4f',
    blurb: 'A cold desert with a thin atmosphere, polar ice caps and Olympus Mons, the largest volcano known in the Solar System.' },
  { id: 'jupiter', name: 'Jupiter', d: 142984, g: 23.1, day: 9.9, year: 4331, dist: 778.5, temp: -110, kind: 'Gas giant', color: '#e8c9a0',
    blurb: 'More than twice as massive as all the other planets combined. The Great Red Spot is a storm wider than Earth.' },
  { id: 'saturn', name: 'Saturn', d: 120536, g: 9.0, day: 10.7, year: 10747, dist: 1432.0, temp: -140, kind: 'Gas giant', color: '#e6d29a',
    blurb: 'The least dense planet. Its rings of ice and rock span about 280,000 km yet are, in most places, only tens of metres thick.' },
  { id: 'uranus', name: 'Uranus', d: 51118, g: 8.7, day: 17.2, year: 30685, dist: 2867.0, temp: -195, kind: 'Ice giant', color: '#a8e0e6',
    blurb: 'An ice giant tipped on its side. Each pole gets about 42 years of continuous sunlight, then 42 years of darkness.' },
  { id: 'neptune', name: 'Neptune', d: 49528, g: 11.0, day: 16.1, year: 60190, dist: 4515.0, temp: -200, kind: 'Ice giant', color: '#6f8df0',
    blurb: 'The farthest planet from the Sun, with the fastest winds measured in the Solar System, over 2,000 km/h.' },
];
const EXTRA = [
  { id: 'moon', name: 'The Moon', d: 3475, g: 1.6, year: null },
  { id: 'pluto', name: 'Pluto', d: 2376, g: 0.7, year: 90560 },
];
const CITIES = [
  ['Greenwich, UK', 51.48, 0.0], ['New York', 40.71, -74.01], ['Los Angeles', 34.05, -118.24], ['Mexico City', 19.43, -99.13], ['São Paulo', -23.55, -46.63],
  ['Buenos Aires', -34.60, -58.38], ['Reykjavík', 64.15, -21.94], ['Madrid', 40.42, -3.70], ['Cairo', 30.04, 31.24], ['Lagos', 6.52, 3.38], ['Nairobi', -1.29, 36.82],
  ['Johannesburg', -26.20, 28.05], ['Dubai', 25.20, 55.27], ['Delhi', 28.61, 77.21], ['Dhaka', 23.81, 90.41], ['Beijing', 39.90, 116.40], ['Tokyo', 35.68, 139.69],
  ['Sydney', -33.87, 151.21], ['Auckland', -36.85, 174.76],
];
const MISSIONS = [
  { y: 1977, name: 'Voyager 1 and 2', who: 'NASA', icon: 'probe', text: 'The grand tour of the outer planets. Voyager 1 crossed into interstellar space in 2012, Voyager 2 in 2018.' },
  { y: 1990, name: 'Hubble Space Telescope', who: 'NASA and ESA', icon: 'scope', text: 'Orbiting about 500 km up, above the blur of the atmosphere. Astronauts serviced it five times.' },
  { y: 1998, name: 'International Space Station', who: 'NASA, Roscosmos, ESA, JAXA, CSA', icon: 'station', text: 'First module launched in 1998; people have lived aboard continuously since November 2000.' },
  { y: 2006, name: 'New Horizons', who: 'NASA', icon: 'probe', text: 'First flyby of Pluto in July 2015, then of the distant object Arrokoth on 1 January 2019.' },
  { y: 2011, name: 'Juno', who: 'NASA', icon: 'probe', text: 'Arrived at Jupiter in July 2016 on a polar orbit, mapping its gravity, magnetic field and deep atmosphere.' },
  { y: 2018, name: 'Parker Solar Probe', who: 'NASA', icon: 'probe', text: 'On 24 December 2024 it passed about 6.1 million km from the Sun\'s surface, the closest any spacecraft has come.' },
  { y: 2021, name: 'James Webb Space Telescope', who: 'NASA, ESA and CSA', icon: 'webb', text: 'Launched 25 December 2021. It observes in infrared from about 1.5 million km from Earth, near the L2 point.' },
  { y: 2023, name: 'JUICE', who: 'ESA', icon: 'probe', text: 'Launched April 2023, due at Jupiter in 2031 to study the icy moons Ganymede, Callisto and Europa.' },
  { y: 2023, name: 'Psyche', who: 'NASA', icon: 'probe', text: 'Launched October 2023 toward a metal-rich asteroid, arriving in 2029.' },
  { y: 2024, name: 'Europa Clipper', who: 'NASA', icon: 'probe', text: 'Launched October 2024, arriving at Jupiter in 2030 to investigate the ocean beneath Europa\'s ice.' },
  { y: 2026, name: 'Artemis II', who: 'NASA and CSA', icon: 'capsule', text: 'The first crewed flight around the Moon since 1972, 1–11 April 2026 (UTC). Its four astronauts reached 406,771 km from Earth, a record for humans.' },
];

/* ======================= Location (per-viewer convenience) ======================= */
const Loc = (() => {
  let loc = { name: CITIES[0][0], lat: CITIES[0][1], lon: CITIES[0][2], set: false };
  try { const s = JSON.parse(localStorage.getItem('cc.location') || 'null'); if (s && isFinite(s.lat) && isFinite(s.lon)) loc = s; } catch (e) { /* ignore */ }
  const subs = new Set();
  return {
    get: () => loc,
    set(v) { loc = { ...v, set: true }; try { localStorage.setItem('cc.location', JSON.stringify(loc)); } catch (e) { /* ignore */ } subs.forEach(f => f(loc)); },
    on: f => { subs.add(f); return () => subs.delete(f); },
  };
})();
function locationPicker(onChange) {
  const l = Loc.get();
  const wrap = document.createElement('div'); wrap.className = 'loc';
  wrap.innerHTML = `<label class="loc-label" for="locSel">Observing from</label>
    <div class="row"><select id="locSel">${CITIES.map(c => `<option ${c[0] === l.name ? 'selected' : ''}>${esc(c[0])}</option>`).join('')}<option value="custom" ${CITIES.some(c => c[0] === l.name) ? '' : 'selected'}>Custom coordinates</option></select>
    <span class="loc-coords" id="locCoords"></span></div>
    <div class="row loc-custom" id="locCustom" hidden><label>Latitude <input id="locLat" type="number" step="0.01" min="-90" max="90" inputmode="decimal"></label><label>Longitude <input id="locLon" type="number" step="0.01" min="-180" max="180" inputmode="decimal"></label><button class="btn btn-small" id="locSave">Use these</button></div>`;
  const show = () => { const v = Loc.get(); $('#locCoords', wrap).textContent = `${Math.abs(v.lat).toFixed(2)}° ${v.lat >= 0 ? 'N' : 'S'}, ${Math.abs(v.lon).toFixed(2)}° ${v.lon >= 0 ? 'E' : 'W'}`; };
  $('#locSel', wrap).addEventListener('change', e => {
    const c = CITIES.find(x => x[0] === e.target.value);
    $('#locCustom', wrap).hidden = !!c;
    if (c) { Loc.set({ name: c[0], lat: c[1], lon: c[2] }); show(); onChange && onChange(); }
    else { $('#locLat', wrap).value = Loc.get().lat; $('#locLon', wrap).value = Loc.get().lon; }
  });
  $('#locSave', wrap).addEventListener('click', () => {
    const lat = clamp(Number($('#locLat', wrap).value), -90, 90), lon = clamp(Number($('#locLon', wrap).value), -180, 180);
    if (!isFinite(lat) || !isFinite(lon)) return;
    Loc.set({ name: `${lat.toFixed(2)}, ${lon.toFixed(2)}`, lat, lon }); show(); onChange && onChange();
  });
  show();
  return wrap;
}

/* ======================= Formatting ======================= */
const tz = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'local time'; } catch (e) { return 'local time'; } })();
const fmtTime = d => d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const fmtDate = (d, opt = {}) => d.toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric', ...opt });
const fmtDay = d => d.toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' });
const daysUntil = d => Math.ceil((d - Date.now()) / 86400000);
const inDays = d => { const n = daysUntil(d); return n <= 0 ? 'today' : n === 1 ? 'tomorrow' : `in ${n} days`; };
const num = (x, p = 0) => Number(x).toLocaleString(undefined, { maximumFractionDigits: p, minimumFractionDigits: p });

/* ======================= Procedural illustrations ======================= */
function rng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function spaceBg(ctx, W, H, seed = 7, density = 1) {
  ctx.fillStyle = '#03060e'; ctx.fillRect(0, 0, W, H);
  const r = rng(seed), n = Math.round(W * H / 2600 * density);
  for (let i = 0; i < n; i++) { const a = r() * 0.7 + 0.1; ctx.fillStyle = `rgba(230,236,255,${a * r()})`; const s = r() < 0.06 ? 1.6 : 0.9; ctx.fillRect(r() * W, r() * H, s * (W / 400 + 0.6), s * (W / 400 + 0.6)); }
}
function blob(ctx, x, y, rx, ry, rot = 0) { ctx.beginPath(); ctx.ellipse(x, y, rx, ry, rot, 0, TAU); ctx.fill(); }
function shade(ctx, cx, cy, r, strength = 0.6) {
  const g = ctx.createRadialGradient(cx - r * 0.38, cy - r * 0.38, r * 0.05, cx, cy, r * 1.04);
  g.addColorStop(0, 'rgba(255,255,255,0.16)'); g.addColorStop(0.5, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${strength})`);
  ctx.fillStyle = g; ctx.fillRect(cx - r, cy - r, 2 * r, 2 * r);
}
function bands(ctx, cx, cy, r, colors, wobble, seed) {
  const n = colors.length, h = 2 * r / n, rr = rng(seed);
  for (let i = 0; i < n; i++) { ctx.fillStyle = colors[i]; ctx.fillRect(cx - r, cy - r + i * h - 1, 2 * r, h + 2); }
  for (let i = 0; i < n * 6; i++) {
    ctx.fillStyle = colors[Math.floor(rr() * n)]; ctx.globalAlpha = 0.35;
    const y = cy - r + rr() * 2 * r; blob(ctx, cx - r + rr() * 2 * r, y, r * (0.15 + rr() * 0.4), r * wobble * (0.3 + rr()), 0);
  }
  ctx.globalAlpha = 1;
}
function drawWorld(ctx, id, cx, cy, r, opt = {}) {
  if (r <= 0.5) return;
  const R = rng({ mercury: 3, venus: 5, earth: 11, mars: 13, jupiter: 17, saturn: 19, uranus: 23, neptune: 29, moon: 31, pluto: 37, sun: 41 }[id] || 1);
  if (id === 'saturn' && !opt.noRings) ring(ctx, cx, cy, r, 'back');
  ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.clip();
  const fill = c => { ctx.fillStyle = c; ctx.fillRect(cx - r, cy - r, 2 * r, 2 * r); };
  if (id === 'mercury') {
    fill('#9a948d');
    for (let i = 0; i < 40; i++) { const x = cx + (R() * 2 - 1) * r, y = cy + (R() * 2 - 1) * r, s = r * (0.03 + R() * 0.12); ctx.fillStyle = 'rgba(60,56,52,.35)'; blob(ctx, x, y, s, s); ctx.fillStyle = 'rgba(220,214,206,.25)'; blob(ctx, x - s * 0.2, y - s * 0.2, s * 0.6, s * 0.6); }
  } else if (id === 'venus') {
    fill('#e9d29f'); bands(ctx, cx, cy, r, ['#efdcae', '#e2c487', '#f1e2b9', '#dcbd7e', '#ecd6a3', '#e5c98f'], 0.25, 5);
  } else if (id === 'earth') {
    fill('#2f6fb8');
    const land = [[-0.35, -0.2, 0.32, 0.42, 0.3, '#4f8a4b'], [0.25, -0.35, 0.3, 0.2, -0.4, '#6b8c4a'], [0.35, 0.2, 0.22, 0.34, 0.2, '#8c7a52'], [-0.2, 0.45, 0.25, 0.14, 0.5, '#4f8a4b'], [0.55, -0.05, 0.12, 0.18, 0, '#7a8a50']];
    land.forEach(([x, y, a, b, rot, c]) => { ctx.fillStyle = c; blob(ctx, cx + x * r, cy + y * r, a * r, b * r, rot); });
    ctx.fillStyle = '#f2f6fa'; blob(ctx, cx, cy - r * 0.98, r * 0.6, r * 0.14); blob(ctx, cx, cy + r * 0.98, r * 0.7, r * 0.16);
    ctx.fillStyle = 'rgba(255,255,255,.55)';
    for (let i = 0; i < 14; i++) blob(ctx, cx + (R() * 2 - 1) * r, cy + (R() * 2 - 1) * r, r * (0.12 + R() * 0.3), r * 0.04, R() * 0.6 - 0.3);
  } else if (id === 'mars') {
    fill('#c1603a');
    ctx.fillStyle = 'rgba(120,52,30,.55)'; [[-0.2, 0.0, 0.45, 0.16, 0.2], [0.35, 0.15, 0.25, 0.12, -0.3], [0.0, 0.3, 0.3, 0.1, 0]].forEach(([x, y, a, b, rot]) => blob(ctx, cx + x * r, cy + y * r, a * r, b * r, rot));
    ctx.fillStyle = 'rgba(230,150,110,.35)'; blob(ctx, cx + 0.2 * r, cy - 0.35 * r, 0.35 * r, 0.2 * r);
    ctx.fillStyle = '#f5f1ec'; blob(ctx, cx, cy - r * 0.95, r * 0.35, r * 0.12);
  } else if (id === 'jupiter') {
    bands(ctx, cx, cy, r, ['#d9c4a5', '#e9dcc3', '#b98962', '#efe3cc', '#c99c73', '#f2e7d2', '#a8774f', '#e7d6b8', '#c79a72', '#e9dcc3', '#d2b591'], 0.08, 17);
    ctx.fillStyle = '#c4573b'; ctx.globalAlpha = 0.9; blob(ctx, cx + 0.28 * r, cy + 0.36 * r, 0.2 * r, 0.11 * r); ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(240,220,200,.6)'; blob(ctx, cx + 0.28 * r, cy + 0.36 * r, 0.12 * r, 0.06 * r);
  } else if (id === 'saturn') {
    bands(ctx, cx, cy, r, ['#d8c38f', '#e9d8a6', '#d3b97f', '#efe0b5', '#cdb27a', '#e6d29f', '#d9c18c'], 0.06, 19);
  } else if (id === 'uranus') {
    fill('#9fd9e0'); bands(ctx, cx, cy, r, ['#a6dde3', '#9ad5dc', '#a9e0e6', '#94d0d8'], 0.05, 23);
  } else if (id === 'neptune') {
    fill('#3f66d9'); bands(ctx, cx, cy, r, ['#4a70e0', '#3a5fcf', '#4d74e4', '#3557c4', '#4469d8'], 0.06, 29);
  } else if (id === 'moon') {
    fill('#bdbab3');
    const maria = [[-0.25, -0.35, 0.22, 0.2], [0.12, -0.3, 0.13, 0.12], [0.22, -0.06, 0.16, 0.14], [0.56, -0.24, 0.1, 0.08], [0.45, 0.14, 0.11, 0.13], [0.24, 0.26, 0.08, 0.08], [-0.16, 0.36, 0.13, 0.1], [-0.55, -0.02, 0.24, 0.36], [-0.42, 0.38, 0.08, 0.07], [0.0, -0.64, 0.38, 0.06]];
    ctx.fillStyle = '#85827c'; maria.forEach(([x, y, a, b]) => blob(ctx, cx + x * r, cy + y * r, a * r, b * r));
    for (let i = 0; i < 26; i++) { const s = r * (0.015 + R() * 0.04); ctx.fillStyle = 'rgba(90,88,84,.35)'; blob(ctx, cx + (R() * 2 - 1) * r, cy + (R() * 2 - 1) * r, s, s); }
    ctx.fillStyle = 'rgba(245,244,238,.85)'; blob(ctx, cx - 0.1 * r, cy + 0.64 * r, 0.035 * r, 0.035 * r);
  } else if (id === 'pluto') {
    fill('#cdb497'); ctx.fillStyle = '#f2e6d5'; blob(ctx, cx + 0.12 * r, cy + 0.12 * r, 0.32 * r, 0.3 * r, 0.4);
    ctx.fillStyle = 'rgba(110,70,55,.75)'; blob(ctx, cx - 0.45 * r, cy + 0.2 * r, 0.42 * r, 0.16 * r, 0.1);
  } else if (id === 'sun') {
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
    g.addColorStop(0, '#fff7d6'); g.addColorStop(0.6, '#ffd257'); g.addColorStop(0.92, '#ffa133'); g.addColorStop(1, '#f07a1f');
    ctx.fillStyle = g; ctx.fillRect(cx - r, cy - r, 2 * r, 2 * r);
    for (let i = 0; i < Math.min(900, r * r / 8); i++) { const s = r * (0.01 + R() * 0.025); ctx.fillStyle = `rgba(${R() < 0.5 ? '255,255,230' : '190,90,20'},.10)`; blob(ctx, cx + (R() * 2 - 1) * r, cy + (R() * 2 - 1) * r, s, s); }
    if (opt.spots) [[0.25, -0.15, 0.05], [0.32, -0.1, 0.03], [-0.3, 0.2, 0.04]].forEach(([x, y, s]) => { ctx.fillStyle = 'rgba(150,70,20,.6)'; blob(ctx, cx + x * r, cy + y * r, s * r * 1.8, s * r * 1.5); ctx.fillStyle = 'rgba(60,25,10,.9)'; blob(ctx, cx + x * r, cy + y * r, s * r, s * r * 0.85); });
  }
  if (id !== 'sun' && !opt.flat) shade(ctx, cx, cy, r, opt.shade ?? 0.62);
  ctx.restore();
  if (id === 'saturn' && !opt.noRings) ring(ctx, cx, cy, r, 'front');
}
function ring(ctx, cx, cy, r, half) {
  ctx.save();
  if (half === 'front') { ctx.beginPath(); ctx.rect(cx - 3 * r, cy, 6 * r, 3 * r); ctx.clip(); }
  const bandsR = [[1.25, 1.52, 'rgba(200,180,140,.55)'], [1.52, 1.95, 'rgba(230,212,170,.85)'], [2.0, 2.28, 'rgba(210,192,150,.7)']];
  for (const [a, b, c] of bandsR) { ctx.strokeStyle = c; ctx.lineWidth = (b - a) * r * 0.42; ctx.beginPath(); ctx.ellipse(cx, cy, (a + b) / 2 * r, (a + b) / 2 * r * 0.3, -0.12, 0, TAU); ctx.stroke(); }
  ctx.restore();
}
function drawMoonPhase(ctx, cx, cy, r, illum, waxing, south = false) {
  drawWorld(ctx, 'moon', cx, cy, r, { shade: 0.25 });
  const litRight = waxing !== south;
  ctx.save(); ctx.translate(cx, cy); if (!litRight) ctx.scale(-1, 1);
  const w = r * (1 - 2 * illum);  // >0 crescent, <0 gibbous
  ctx.beginPath(); ctx.arc(0, 0, r + 0.5, -Math.PI / 2, Math.PI / 2, true);
  if (w >= 0) ctx.ellipse(0, 0, Math.abs(w), r + 0.5, 0, Math.PI / 2, -Math.PI / 2, true);
  else ctx.ellipse(0, 0, Math.abs(w), r + 0.5, 0, Math.PI / 2, Math.PI * 1.5, false);
  ctx.closePath(); ctx.fillStyle = 'rgba(3,5,12,.88)'; ctx.fill();
  ctx.restore();
}
function eclipseIcon(ctx, cx, cy, r, kind, type) {
  if (kind === 'solar') {
    if (type === 'total') {
      const g = ctx.createRadialGradient(cx, cy, r * 0.9, cx, cy, r * 2.4); g.addColorStop(0, 'rgba(240,244,255,.9)'); g.addColorStop(0.35, 'rgba(200,215,255,.35)'); g.addColorStop(1, 'rgba(200,215,255,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r * 2.4, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(235,240,255,.35)'; ctx.lineWidth = Math.max(1, r * 0.05);
      for (let i = 0; i < 10; i++) { const a = i / 10 * TAU + 0.2; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); ctx.lineTo(cx + Math.cos(a) * r * (1.7 + (i % 3) * 0.35), cy + Math.sin(a) * r * (1.7 + (i % 3) * 0.35)); ctx.stroke(); }
      ctx.fillStyle = '#02040a'; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
      ctx.fillStyle = '#ff6b6b'; ctx.beginPath(); ctx.arc(cx + r * 0.95, cy - r * 0.3, r * 0.08, 0, TAU); ctx.fill();
    } else {
      drawWorld(ctx, 'sun', cx, cy, r);
      ctx.fillStyle = '#02040a'; ctx.beginPath();
      if (type === 'annular') ctx.arc(cx, cy, r * 0.86, 0, TAU); else ctx.arc(cx + r * 0.55, cy - r * 0.35, r * 0.98, 0, TAU);
      ctx.fill();
    }
  } else {
    drawWorld(ctx, 'moon', cx, cy, r, { shade: 0.3 });
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.clip();
    if (type === 'total') { ctx.fillStyle = 'rgba(150,45,20,.72)'; ctx.fillRect(cx - r, cy - r, 2 * r, 2 * r); }
    else if (type === 'partial') { ctx.fillStyle = 'rgba(70,18,8,.88)'; ctx.beginPath(); ctx.arc(cx - r * 0.9, cy + r * 0.5, r * 1.5, 0, TAU); ctx.fill(); }
    else { const g = ctx.createLinearGradient(cx - r, cy, cx + r, cy); g.addColorStop(0, 'rgba(0,0,0,.6)'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(cx - r, cy - r, 2 * r, 2 * r); }
    ctx.restore();
  }
}
function canvasArt(cv, paint) { const ctx = cv.getContext('2d'); if (!ctx) return; const dpr = sizeCanvas(cv); ctx.setTransform(1, 0, 0, 1, 0, 0); paint(ctx, cv.width, cv.height, dpr); }
function spacecraft(ctx, kind, cx, cy, s) {
  ctx.save(); ctx.translate(cx, cy); ctx.lineJoin = 'round';
  const panel = (x, y, w, h) => { ctx.fillStyle = '#2b4f8f'; ctx.fillRect(x, y, w, h); ctx.strokeStyle = 'rgba(160,190,240,.6)'; ctx.lineWidth = Math.max(1, s * 0.02); ctx.strokeRect(x, y, w, h); };
  if (kind === 'station') {
    ctx.fillStyle = '#c9ced8'; ctx.fillRect(-s * 0.95, -s * 0.04, s * 1.9, s * 0.08);
    [-0.85, -0.55, 0.55, 0.85].forEach(x => { panel(x * s - s * 0.09, -s * 0.5, s * 0.18, s * 0.42); panel(x * s - s * 0.09, s * 0.08, s * 0.18, s * 0.42); });
    ctx.fillStyle = '#e4e7ee'; ctx.fillRect(-s * 0.08, -s * 0.3, s * 0.16, s * 0.6); ctx.fillRect(-s * 0.3, -s * 0.08, s * 0.6, s * 0.16);
  } else if (kind === 'probe') {
    ctx.strokeStyle = '#d8dce6'; ctx.lineWidth = Math.max(1, s * 0.04); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(s * 0.9, s * 0.5); ctx.stroke();
    ctx.fillStyle = '#e8ebf2'; ctx.beginPath(); ctx.ellipse(-s * 0.05, -s * 0.25, s * 0.5, s * 0.16, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#b9a36a'; ctx.fillRect(-s * 0.2, -s * 0.12, s * 0.4, s * 0.32);
    ctx.fillStyle = '#9aa1ad'; ctx.fillRect(-s * 0.05, s * 0.2, s * 0.1, s * 0.3);
  } else if (kind === 'scope') {
    ctx.rotate(-0.35); ctx.fillStyle = '#d9dde6'; ctx.fillRect(-s * 0.7, -s * 0.18, s * 1.2, s * 0.36);
    ctx.fillStyle = '#9aa1ad'; ctx.fillRect(s * 0.5, -s * 0.2, s * 0.12, s * 0.4); panel(-s * 0.3, -s * 0.62, s * 0.5, s * 0.36); panel(-s * 0.3, s * 0.26, s * 0.5, s * 0.36);
  } else if (kind === 'webb') {
    ctx.fillStyle = 'rgba(200,170,220,.35)'; ctx.beginPath(); ctx.moveTo(-s, s * 0.5); ctx.lineTo(s, s * 0.5); ctx.lineTo(s * 0.6, s * 0.75); ctx.lineTo(-s * 0.6, s * 0.75); ctx.closePath(); ctx.fill();
    const hx = (x, y, k) => { ctx.beginPath(); for (let i = 0; i < 6; i++) { const a = i / 6 * TAU + Math.PI / 6; ctx.lineTo(x + Math.cos(a) * k, y + Math.sin(a) * k); } ctx.closePath(); ctx.fill(); };
    ctx.fillStyle = '#e8b84a'; const k = s * 0.17;
    [[0, -0.3], [-0.29, -0.13], [0.29, -0.13], [-0.29, 0.21], [0.29, 0.21], [0, 0.04], [0, 0.38]].forEach(([x, y]) => hx(x * s, y * s, k * 0.95));
  } else if (kind === 'capsule') {
    ctx.fillStyle = '#e4e7ee'; ctx.beginPath(); ctx.moveTo(-s * 0.4, s * 0.25); ctx.lineTo(s * 0.4, s * 0.25); ctx.lineTo(s * 0.18, -s * 0.35); ctx.lineTo(-s * 0.18, -s * 0.35); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#b9bfcb'; ctx.fillRect(-s * 0.36, s * 0.25, s * 0.72, s * 0.35);
    panel(-s * 1.05, s * 0.32, s * 0.6, s * 0.14); panel(s * 0.45, s * 0.32, s * 0.6, s * 0.14);
  }
  ctx.restore();
}

/* ======================= Sky computations ======================= */
const PLANETS_SKY = ['mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune'];
function nightPlan(loc, date = new Date()) {
  const j0 = A.jd(date), step = 10 / 1440, N = 144;
  const sunAlt = [], times = [];
  for (let i = 0; i <= N; i++) { const j = j0 + i * step; times.push(j); sunAlt.push(A.bodyAltAz('sun', j, loc.lat, loc.lon).alt); }
  const bodies = ['moon', ...PLANETS_SKY].map(name => {
    const alts = times.map(j => A.bodyAltAz(name, j, loc.lat, loc.lon));
    let best = null, rise = null, set = null;
    alts.forEach((h, i) => {
      if (i && alts[i - 1].alt < 0 && h.alt >= 0 && rise === null) rise = times[i];
      if (i && alts[i - 1].alt >= 0 && h.alt < 0 && set === null) set = times[i];
      if (sunAlt[i] < -12 && h.alt > 5 && (!best || h.alt > best.alt)) best = { alt: h.alt, az: h.az, j: times[i] };
    });
    const elong = A.elongation(name, j0), now = alts[0];
    const naked = !['uranus', 'neptune'].includes(name);
    let status;
    if (name !== 'moon' && elong < 12) status = { k: 'sun', t: 'Too close to the Sun to see' };
    else if (!best) status = { k: 'down', t: 'Not up during dark hours' };
    else status = { k: 'up', t: `Best around ${fmtTime(A.fromJd(best.j))}, ${Math.round(best.alt)}° high in the ${dirName(best.az)}` };
    return { name, now, best, rise, set, elong, naked, status };
  });
  const sunNow = sunAlt[0];
  const darkStart = (() => { for (let i = 0; i <= N; i++) if (sunAlt[i] < -12) return times[i]; return null; })();
  return { bodies, sunNow, darkStart, j0 };
}
const DIRS = { N: 'north', NE: 'northeast', E: 'east', SE: 'southeast', S: 'south', SW: 'southwest', W: 'west', NW: 'northwest' };
const dirName = az => DIRS[A.compass(az)];
const cap = s => s[0].toUpperCase() + s.slice(1);
const NAMES = { mercury: 'Mercury', venus: 'Venus', mars: 'Mars', jupiter: 'Jupiter', saturn: 'Saturn', uranus: 'Uranus', neptune: 'Neptune', moon: 'Moon', sun: 'Sun' };
const SKY_COLORS = { mercury: '#c9c2b8', venus: '#fff1c4', mars: '#ff8a5c', jupiter: '#f2d6ae', saturn: '#eedc9e', uranus: '#b5ecf2', neptune: '#8ea6ff' };
function nextShower(now = new Date()) {
  const y = now.getUTCFullYear();
  const list = A.SHOWERS.flatMap(s => [y, y + 1].map(yy => ({ ...s, date: new Date(Date.UTC(yy, s.peak[0] - 1, s.peak[1], 0)) })));
  return list.filter(s => s.date.getTime() > now.getTime() - 86400000).sort((a, b) => a.date - b.date);
}
const nextEclipses = (now = new Date()) => A.ECLIPSES.map(e => ({ ...e, d: new Date(e.date + 'T12:00:00Z') })).filter(e => e.d.getTime() > now.getTime() - 86400000);

/* ======================= Hub ======================= */
const TOPICS = [
  { id: 'tonight', title: 'Observe tonight', art: artTonight, sub: subTonight },
  { id: 'moon', title: 'Moon phase', art: artMoon, sub: () => { const p = A.moonPhase(A.jd(new Date())); return `${p.name}, ${Math.round(p.illum * 100)}% lit`; } },
  { id: 'planets', title: 'Planets', art: artPlanets, sub: () => 'Eight worlds, compared' },
  { id: 'solar-system', title: 'Solar System', art: artOrrery, sub: () => `Positions on ${fmtDate(new Date(), { year: undefined })}` },
  { id: 'eclipses', title: 'Eclipses', art: artEclipse, sub: () => { const e = nextEclipses()[0]; return e ? `Next: ${e.type} ${e.kind}, ${fmtDate(e.d)}` : 'Upcoming eclipses'; } },
  { id: 'meteors', title: 'Meteor showers', art: artMeteors, sub: () => { const s = nextShower()[0]; return `Next peak: ${s.name}, ${fmtDate(s.date, { year: undefined })}`; } },
  { id: 'jupiter', title: "Jupiter's moons", art: artJupiter, sub: () => 'Where the four big moons are now' },
  { id: 'sun', title: 'The Sun', art: (ctx, W, H) => { spaceBg(ctx, W, H, 41, 0.5); const r = Math.min(W, H) * 0.34; const g = ctx.createRadialGradient(W / 2, H / 2, r, W / 2, H / 2, r * 1.6); g.addColorStop(0, 'rgba(255,170,60,.45)'); g.addColorStop(1, 'rgba(255,170,60,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); drawWorld(ctx, 'sun', W / 2, H / 2, r, { spots: true }); }, sub: () => 'Our star, layer by layer' },
  { id: 'weight', title: 'Weight and age', art: artWeight, sub: () => 'What you would weigh on Mars' },
  { id: 'missions', title: 'Missions and ISS', art: (ctx, W, H) => { spaceBg(ctx, W, H, 53); drawWorld(ctx, 'earth', W * 0.18, H * 1.05, W * 0.55); spacecraft(ctx, 'station', W * 0.6, H * 0.36, Math.min(W, H) * 0.3); }, sub: () => 'From Voyager to Artemis II' },
];
function artTonight(ctx, W, H, dpr) {
  const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#03060e'); g.addColorStop(1, '#16264a'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  const r = rng(61); for (let i = 0; i < 70; i++) { ctx.fillStyle = `rgba(235,240,255,${r() * 0.9})`; ctx.fillRect(r() * W, r() * H * 0.75, 1.2 * dpr, 1.2 * dpr); }
  ctx.fillStyle = '#fff1c4'; ctx.beginPath(); ctx.arc(W * 0.72, H * 0.42, 3.6 * dpr, 0, TAU); ctx.fill();
  ctx.fillStyle = '#ff8a5c'; ctx.beginPath(); ctx.arc(W * 0.3, H * 0.3, 2.6 * dpr, 0, TAU); ctx.fill();
  drawMoonPhase(ctx, W * 0.84, H * 0.2, Math.min(W, H) * 0.09, 0.3, true);
  ctx.fillStyle = '#060a14'; ctx.beginPath(); ctx.moveTo(0, H); ctx.lineTo(0, H * 0.78); ctx.quadraticCurveTo(W * 0.25, H * 0.66, W * 0.45, H * 0.8); ctx.quadraticCurveTo(W * 0.7, H * 0.7, W, H * 0.82); ctx.lineTo(W, H); ctx.fill();
}
function artMoon(ctx, W, H) { spaceBg(ctx, W, H, 31, 0.6); const p = A.moonPhase(A.jd(new Date())); drawMoonPhase(ctx, W / 2, H / 2, Math.min(W, H) * 0.36, p.illum, p.waxing, Loc.get().lat < 0); }
function artPlanets(ctx, W, H) { spaceBg(ctx, W, H, 19); drawWorld(ctx, 'saturn', W * 0.58, H * 0.5, Math.min(W, H) * 0.2); drawWorld(ctx, 'earth', W * 0.16, H * 0.72, Math.min(W, H) * 0.09); drawWorld(ctx, 'mars', W * 0.18, H * 0.28, Math.min(W, H) * 0.05); }
function artOrrery(ctx, W, H, dpr) {
  spaceBg(ctx, W, H, 71, 0.5); const j = A.jd(new Date()), cx = W / 2, cy = H / 2, k = Math.min(W, H) * 0.44 / 1.7;
  ctx.fillStyle = '#ffd257'; ctx.beginPath(); ctx.arc(cx, cy, 5 * dpr, 0, TAU); ctx.fill();
  ['mercury', 'venus', 'earth', 'mars'].forEach(n => { const pts = A.orbitPoints(n, j, 90); ctx.strokeStyle = 'rgba(150,170,205,.3)'; ctx.lineWidth = dpr; ctx.beginPath(); pts.forEach(([x, y], i) => i ? ctx.lineTo(cx + x * k, cy - y * k) : ctx.moveTo(cx + x * k, cy - y * k)); ctx.stroke(); const p = A.helio(n, j); ctx.fillStyle = n === 'earth' ? '#5b9be0' : (WORLDS.find(w => w.id === n) || {}).color; ctx.beginPath(); ctx.arc(cx + p.x * k, cy - p.y * k, 3.2 * dpr, 0, TAU); ctx.fill(); });
}
function artEclipse(ctx, W, H) { spaceBg(ctx, W, H, 83, 0.6); eclipseIcon(ctx, W / 2, H / 2, Math.min(W, H) * 0.2, 'solar', 'total'); }
function artMeteors(ctx, W, H, dpr) {
  spaceBg(ctx, W, H, 97); const rx = W * 0.78, ry = H * 0.18, r = rng(5);
  for (let i = 0; i < 6; i++) { const a = Math.PI * (0.6 + r() * 0.5), d0 = 30 * dpr + r() * W * 0.25, L = W * (0.18 + r() * 0.2); const x0 = rx + Math.cos(a) * d0, y0 = ry + Math.sin(a) * d0, x1 = x0 + Math.cos(a) * L, y1 = y0 + Math.sin(a) * L; const g = ctx.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(220,240,255,.95)'); ctx.strokeStyle = g; ctx.lineWidth = 1.6 * dpr; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); }
}
function artJupiter(ctx, W, H, dpr) {
  spaceBg(ctx, W, H, 17, 0.5); const r = Math.min(W, H) * 0.14, cx = W / 2, cy = H / 2;
  drawWorld(ctx, 'jupiter', cx, cy, r);
  const sc = (W / 2 - 8 * dpr) / 27;
  A.galilean(A.jd(new Date())).forEach(m => { if (m.behind && Math.abs(m.x) < 1) return; ctx.fillStyle = '#e9ecf3'; ctx.beginPath(); ctx.arc(cx + m.x * sc, cy, 2.3 * dpr, 0, TAU); ctx.fill(); });
}
function artWeight(ctx, W, H, dpr) {
  spaceBg(ctx, W, H, 113, 0.5); drawWorld(ctx, 'mars', W * 0.78, H * 0.3, Math.min(W, H) * 0.16);
  const cx = W * 0.4, cy = H * 0.6, s = Math.min(W, H) * 0.3;
  ctx.fillStyle = '#d9dde6'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(cx - s, cy - s * 0.55, 2 * s, 1.1 * s, s * 0.18) : ctx.rect(cx - s, cy - s * 0.55, 2 * s, 1.1 * s); ctx.fill();
  ctx.fillStyle = '#0d1425'; ctx.beginPath(); ctx.arc(cx, cy - s * 0.05, s * 0.36, Math.PI, TAU); ctx.fill();
  ctx.strokeStyle = '#ff8a5c'; ctx.lineWidth = 2 * dpr; ctx.beginPath(); ctx.moveTo(cx, cy - s * 0.05); ctx.lineTo(cx - s * 0.22, cy - s * 0.3); ctx.stroke();
}
function subTonight() {
  const plan = nightPlan(Loc.get()), vis = plan.bodies.filter(b => b.name !== 'moon' && b.naked && b.status.k === 'up').map(b => NAMES[b.name]);
  return vis.length ? `Tonight: ${vis.join(', ')}` : 'No bright planets tonight';
}
function tileHtml(t) { return `<a class="tile" href="#/explore/${t.id}"><div class="tile-art"><canvas data-art="${t.id}" aria-hidden="true"></canvas></div><div class="tile-txt"><h3>${esc(t.title)}</h3><p data-sub="${t.id}"></p></div></a>`; }
function paintTiles(root) {
  $$('canvas[data-art]', root).forEach(cv => { const t = TOPICS.find(x => x.id === cv.dataset.art); canvasArt(cv, (ctx, W, H, dpr) => t.art(ctx, W, H, dpr)); });
  $$('[data-sub]', root).forEach(p => { const t = TOPICS.find(x => x.id === p.dataset.sub); try { p.textContent = t.sub(); } catch (e) { p.textContent = ''; } });
}
function mountTiles(root, ids) {
  root.innerHTML = (ids ? TOPICS.filter(t => ids.includes(t.id)) : TOPICS).map(tileHtml).join('');
  requestAnimationFrame(() => paintTiles(root));
  const ro = new ResizeObserver(() => paintTiles(root)); ro.observe(root);
  return ro;
}

/* ======================= Topic screens ======================= */
const SCREENS = {};
let cleanup = [];
const onCleanup = f => cleanup.push(f);
function loop(fn) { let raf = 0, last = performance.now(); const tick = now => { const dt = Math.min(0.05, (now - last) / 1000); last = now; fn(dt, now); raf = requestAnimationFrame(tick); }; raf = requestAnimationFrame(tick); onCleanup(() => cancelAnimationFrame(raf)); }
function watch(el, fn) { const ro = new ResizeObserver(fn); ro.observe(el); onCleanup(() => ro.disconnect()); }
const head = (title, lede) => `<p class="crumbs" style="margin:22px 0 6px"><a href="#/explore">Explore</a></p><h1 class="topic-title">${esc(title)}</h1><p class="topic-lede">${lede}</p>`;
const sourceNote = s => `<p class="src-note">${s}</p>`;

/* ---------- Observe tonight ---------- */
SCREENS.tonight = root => {
  let offset = 0, plan = null;
  root.innerHTML = head('Observe tonight', 'What is in your sky, where to look, and when. Positions are calculated live for your location.') + `
    <div id="tnLoc"></div>
    <div class="topic-grid">
      <div>
        <div class="dome-wrap"><canvas id="tnDome" role="img" aria-label="Map of the sky overhead"></canvas></div>
        <div class="field" style="margin-top:12px"><div class="field-head"><label for="tnTime">Time</label><output id="tnTimeOut"></output></div>
          <input type="range" id="tnTime" min="0" max="1440" step="15" value="0"><p class="hint">Drag to look ahead up to 24 hours. Times are in your device's time zone (${esc(tz)}).</p></div>
        <p class="hint">The map shows the whole sky as if lying on your back with your head to the north: east is on the left. Dashed line: the ecliptic, where the planets travel.</p>
      </div>
      <div>
        <div class="callout" id="tnSky"></div>
        <h2 class="h-sub">Planets and the Moon</h2>
        <ul class="sky-list" id="tnList"></ul>
        ${sourceNote('Positions from JPL approximate planetary elements and Astronomical Almanac formulas, accurate to a fraction of a degree. Rise and set times assume a flat horizon.')}
      </div>
    </div>`;
  $('#tnLoc', root).appendChild(locationPicker(() => { plan = nightPlan(Loc.get()); list(); draw(); }));
  function list() {
    const sunTxt = plan.sunNow > 0 ? 'The Sun is up. Only the Moon and sometimes Venus are easy to spot in daylight.' : plan.sunNow > -12 ? 'Twilight. The brightest planets appear first.' : 'It is dark: a good time to look.';
    const ph = A.moonPhase(plan.j0);
    $('#tnSky', root).innerHTML = `<p><b>Right now at ${esc(Loc.get().name)}:</b> ${sunTxt}</p><p>The Moon is ${ph.name.toLowerCase()}, ${Math.round(ph.illum * 100)}% lit. ${ph.illum > 0.6 ? 'Its glare will hide faint stars.' : 'Its glare is modest.'}</p>`;
    const order = { up: 0, down: 1, sun: 2 };
    $('#tnList', root).innerHTML = plan.bodies.slice().sort((a, b) => order[a.status.k] - order[b.status.k]).map(b => {
      const up = b.now.alt > 0;
      const sw = b.name === 'moon' ? `<canvas class="sky-sw" data-moon aria-hidden="true"></canvas>` : `<span class="sky-dot" style="background:${SKY_COLORS[b.name]}"></span>`;
      const extra = [up ? `Up now, ${Math.round(b.now.alt)}° high in the ${dirName(b.now.az)}` : b.rise ? `Rises ${fmtTime(A.fromJd(b.rise))}` : 'Below the horizon', b.set && up ? `sets ${fmtTime(A.fromJd(b.set))}` : ''].filter(Boolean).join(', ');
      return `<li class="sky-item" data-k="${b.status.k}">${sw}<div><b>${NAMES[b.name]}</b>${b.naked ? '' : ' <span class="tag">Binoculars</span>'}<p>${esc(b.status.t)}.</p><p class="muted">${esc(extra)}.</p></div></li>`;
    }).join('');
    const mc = $('canvas[data-moon]', root); if (mc) canvasArt(mc, (ctx, W, H) => { ctx.clearRect(0, 0, W, H); drawMoonPhase(ctx, W / 2, H / 2, W * 0.45, ph.illum, ph.waxing, Loc.get().lat < 0); });
  }
  function draw() {
    const cv = $('#tnDome', root), loc = Loc.get(), j = A.jd(new Date()) + offset / 1440;
    $('#tnTimeOut', root).textContent = offset === 0 ? `Now, ${fmtTime(new Date())}` : `${fmtDay(A.fromJd(j))}, ${fmtTime(A.fromJd(j))}`;
    canvasArt(cv, (ctx, W, H, dpr) => {
      const cx = W / 2, cy = H / 2, R = Math.min(W, H) / 2 - 22 * dpr;
      const sunH = A.bodyAltAz('sun', j, loc.lat, loc.lon);
      ctx.fillStyle = '#03060e'; ctx.fillRect(0, 0, W, H);
      const day = clamp((sunH.alt + 12) / 12, 0, 1);
      const sky = `rgb(${Math.round(6 + 37 * day)},${Math.round(11 + 81 * day)},${Math.round(23 + 125 * day)})`;
      ctx.fillStyle = sky; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fill();
      const xy = (alt, az) => { const rr = R * (90 - alt) / 90, a = az * D2R; return [cx - rr * Math.sin(a), cy - rr * Math.cos(a)]; };
      ctx.strokeStyle = 'rgba(200,215,240,.18)'; ctx.lineWidth = dpr;
      [30, 60].forEach(a => { ctx.beginPath(); ctx.arc(cx, cy, R * (90 - a) / 90, 0, TAU); ctx.stroke(); });
      ctx.strokeStyle = 'rgba(200,215,240,.5)'; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke();
      ctx.fillStyle = 'rgba(225,232,245,.85)'; ctx.font = `700 ${12 * dpr}px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      [['N', 0], ['E', 90], ['S', 180], ['W', 270]].forEach(([t, az]) => { const a = az * D2R; ctx.fillText(t, cx - (R + 12 * dpr) * Math.sin(a), cy - (R + 12 * dpr) * Math.cos(a)); });
      // ecliptic
      ctx.save(); ctx.setLineDash([4 * dpr, 5 * dpr]); ctx.strokeStyle = 'rgba(242,184,91,.45)'; ctx.beginPath(); let pen = false;
      for (let L = 0; L <= 360; L += 3) { const eq = A.eclToEq(L, 0, j), h = A.altAz(eq.ra, eq.dec, j, loc.lat, loc.lon); if (h.alt < 0) { pen = false; continue; } const [x, y] = xy(h.alt, h.az); pen ? ctx.lineTo(x, y) : ctx.moveTo(x, y); pen = true; }
      ctx.stroke(); ctx.restore();
      // stars
      const starA = clamp((-sunH.alt - 4) / 10, 0, 1);
      if (starA > 0) A.STARS.forEach(([n, ra, dec, mag]) => { const h = A.altAz(ra, dec, j, loc.lat, loc.lon); if (h.alt < 0) return; const [x, y] = xy(h.alt, h.az), s = (3.2 - mag * 0.9) * dpr; ctx.fillStyle = `rgba(240,244,255,${starA})`; ctx.beginPath(); ctx.arc(x, y, Math.max(0.8 * dpr, s * 0.6), 0, TAU); ctx.fill(); if (mag < 0.9) { ctx.fillStyle = `rgba(200,212,235,${starA * 0.7})`; ctx.font = `${10 * dpr}px ${FONT}`; ctx.fillText(n, x, y + 10 * dpr); } });
      // planets
      ctx.font = `700 ${11 * dpr}px ${FONT}`;
      PLANETS_SKY.forEach(p => { const h = A.bodyAltAz(p, j, loc.lat, loc.lon); if (h.alt < 0) return; const [x, y] = xy(h.alt, h.az); ctx.fillStyle = SKY_COLORS[p]; ctx.beginPath(); ctx.arc(x, y, (p === 'venus' || p === 'jupiter' ? 4.5 : 3.6) * dpr, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.92)'; ctx.fillText(NAMES[p], x, y - 11 * dpr); });
      const mh = A.bodyAltAz('moon', j, loc.lat, loc.lon);
      if (mh.alt > 0) { const [x, y] = xy(mh.alt, mh.az), ph = A.moonPhase(j); drawMoonPhase(ctx, x, y, 9 * dpr, ph.illum, ph.waxing, loc.lat < 0); ctx.fillStyle = '#fff'; ctx.fillText('Moon', x, y - 16 * dpr); }
      if (sunH.alt > -1) { const [x, y] = xy(Math.max(sunH.alt, 0), sunH.az); const g = ctx.createRadialGradient(x, y, 0, x, y, 22 * dpr); g.addColorStop(0, 'rgba(255,240,180,1)'); g.addColorStop(0.35, 'rgba(255,210,90,.8)'); g.addColorStop(1, 'rgba(255,210,90,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 22 * dpr, 0, TAU); ctx.fill(); ctx.fillStyle = '#3b2600'; ctx.fillText('Sun', x, y); }
    });
  }
  $('#tnTime', root).addEventListener('input', e => { offset = Number(e.target.value); draw(); });
  plan = nightPlan(Loc.get()); list(); draw();
  watch($('#tnDome', root), draw);
  const t = setInterval(() => { if (offset === 0) draw(); }, 60000); onCleanup(() => clearInterval(t));
};

/* ---------- Moon ---------- */
SCREENS.moon = root => {
  let dayOff = 0;
  root.innerHTML = head('Moon phase', 'The Moon as it looks tonight, why its shape changes, and the dates of the next phases.') + `
    <div class="topic-grid">
      <div>
        <div class="moon-stage"><canvas id="mnBig" role="img" aria-label="The Moon's current phase"></canvas></div>
        <div class="row" style="justify-content:center;margin-top:10px"><button class="btn btn-small" id="mnPrev">Previous day</button><button class="btn btn-small" id="mnToday">Today</button><button class="btn btn-small" id="mnNext">Next day</button></div>
        <div class="toggles" style="margin-top:6px;text-align:center"><label style="justify-content:center"><input type="checkbox" id="mnSouth"> Show the view from the Southern Hemisphere</label></div>
      </div>
      <div>
        <p class="moon-date" id="mnDate"></p>
        <h2 class="moon-name" id="mnName"></h2>
        <dl class="kv" id="mnKv"></dl>
        <h2 class="h-sub">Coming up</h2>
        <ul class="phase-next" id="mnNextList"></ul>
      </div>
    </div>
    <h2 class="h-sub">The next 30 days</h2>
    <div class="moon-strip" id="mnStrip"></div>
    <h2 class="h-sub">Why the shape changes</h2>
    <div class="diagram"><canvas id="mnDiag" role="img" aria-label="Diagram of the Moon's orbit and phases"></canvas></div>
    <p class="hint">Diagram not to scale. Half of the Moon is always lit by the Sun; the phase is how much of that lit half faces Earth.</p>
    ${sourceNote('Phase angle from Meeus, Astronomical Algorithms (ch. 48). Phase times checked against published values to within about 15 minutes.')}`;
  const south = () => $('#mnSouth', root).checked;
  $('#mnSouth', root).checked = Loc.get().lat < 0;
  function render() {
    const now = new Date(), j = A.jd(now) + dayOff, d = A.fromJd(j), p = A.moonPhase(j), m = A.moon(j);
    canvasArt($('#mnBig', root), (ctx, W, H) => { spaceBg(ctx, W, H, 31, 0.5); drawMoonPhase(ctx, W / 2, H / 2, Math.min(W, H) * 0.42, p.illum, p.waxing, south()); });
    $('#mnDate', root).textContent = dayOff === 0 ? `Now, ${fmtDate(d)}` : fmtDay(d) + ', ' + d.getFullYear();
    $('#mnName', root).textContent = p.name;
    $('#mnKv', root).innerHTML = `<dt>Lit</dt><dd>${(p.illum * 100).toFixed(0)}%</dd><dt>Age</dt><dd>${p.age.toFixed(1)} days since new moon</dd><dt>Distance</dt><dd>${num(Math.round(m.distKm / 100) * 100)} km</dd><dt>Trend</dt><dd>${p.waxing ? 'Waxing: getting fuller' : 'Waning: getting thinner'}</dd>`;
    const ev = [[0, 'New moon'], [90, 'First quarter'], [180, 'Full moon'], [270, 'Last quarter']].map(([t, n]) => ({ n, t, j: A.nextPhase(j, t) })).sort((a, b) => a.j - b.j);
    $('#mnNextList', root).innerHTML = ev.map(e => `<li><canvas data-ph="${e.t}" aria-hidden="true"></canvas><div><b>${e.n}</b><p>${fmtDay(A.fromJd(e.j))}, ${fmtTime(A.fromJd(e.j))}, ${inDays(A.fromJd(e.j))}</p></div></li>`).join('');
    $$('canvas[data-ph]', root).forEach(cv => { const t = Number(cv.dataset.ph); canvasArt(cv, (ctx, W, H) => { ctx.clearRect(0, 0, W, H); drawMoonPhase(ctx, W / 2, H / 2, W * 0.44, (1 - Math.cos(t * D2R)) / 2, t < 180, south()); }); });
    $('#mnStrip', root).innerHTML = Array.from({ length: 30 }, (_, i) => { const dd = A.fromJd(A.jd(now) + i); return `<div class="ms-day ${i === dayOff ? 'on' : ''}" data-i="${i}"><canvas aria-hidden="true"></canvas><span>${dd.toLocaleDateString([], { day: 'numeric', month: 'short' })}</span></div>`; }).join('');
    $$('.ms-day', root).forEach(el => { const i = Number(el.dataset.i), pp = A.moonPhase(A.jd(now) + i); canvasArt($('canvas', el), (ctx, W, H) => { ctx.clearRect(0, 0, W, H); drawMoonPhase(ctx, W / 2, H / 2, W * 0.42, pp.illum, pp.waxing, south()); }); el.addEventListener('click', () => { dayOff = i; render(); }); });
    diagram(p);
  }
  function diagram(p) {
    canvasArt($('#mnDiag', root), (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 9, 0.4);
      const cx = W * 0.56, cy = H / 2, R = Math.min(W * 0.32, H * 0.38);
      for (let i = 0; i < 9; i++) { const y = H * (0.1 + i * 0.1); ctx.strokeStyle = 'rgba(255,214,110,.25)'; ctx.lineWidth = dpr; ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W * 0.14, y); ctx.stroke(); }
      ctx.fillStyle = '#ffd257'; ctx.font = `700 ${12 * dpr}px ${FONT}`; ctx.textAlign = 'left'; ctx.fillText('Sunlight', 6 * dpr, H * 0.06 + 6 * dpr);
      ctx.strokeStyle = 'rgba(150,170,205,.35)'; ctx.setLineDash([4 * dpr, 4 * dpr]); ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
      drawWorld(ctx, 'earth', cx, cy, R * 0.18);
      const names = ['New', 'Waxing crescent', 'First quarter', 'Waxing gibbous', 'Full', 'Waning gibbous', 'Last quarter', 'Waning crescent'];
      for (let i = 0; i < 8; i++) {
        const e = i * 45, a = (180 + e) * D2R, x = cx + R * Math.cos(a), y = cy - R * Math.sin(a), mr = R * 0.1;
        ctx.fillStyle = '#2a2f3a'; ctx.beginPath(); ctx.arc(x, y, mr, 0, TAU); ctx.fill();
        ctx.fillStyle = '#e8e6df'; ctx.beginPath(); ctx.arc(x, y, mr, Math.PI / 2, Math.PI * 1.5); ctx.fill();
        ctx.fillStyle = 'rgba(205,216,235,.8)'; ctx.font = `${10 * dpr}px ${FONT}`; ctx.textAlign = 'center';
        const lx = cx + (R + mr + 16 * dpr) * Math.cos(a), ly = cy - (R + mr + 12 * dpr) * Math.sin(a);
        ctx.fillText(names[i], clamp(lx, 40 * dpr, W - 40 * dpr), clamp(ly, 10 * dpr, H - 6 * dpr));
      }
      const a = (180 + p.elong) * D2R, x = cx + R * Math.cos(a), y = cy - R * Math.sin(a);
      ctx.strokeStyle = '#5cd6e6'; ctx.lineWidth = 2.5 * dpr; ctx.beginPath(); ctx.arc(x, y, R * 0.16, 0, TAU); ctx.stroke();
      ctx.fillStyle = '#5cd6e6'; ctx.font = `700 ${11 * dpr}px ${FONT}`; ctx.fillText('Moon now', x, y + R * 0.16 + 13 * dpr);
    });
  }
  $('#mnPrev', root).addEventListener('click', () => { dayOff--; render(); });
  $('#mnNext', root).addEventListener('click', () => { dayOff++; render(); });
  $('#mnToday', root).addEventListener('click', () => { dayOff = 0; render(); });
  $('#mnSouth', root).addEventListener('change', render);
  render(); watch($('#mnBig', root), render);
};

/* ---------- Planets ---------- */
SCREENS.planets = root => {
  let sel = 'earth';
  root.innerHTML = head('Planets', 'Eight worlds in order from the Sun. Tap one for its numbers and how it compares with Earth.') + `
    <div class="scale-strip"><canvas id="plScale" role="img" aria-label="The eight planets drawn to the same scale"></canvas></div>
    <p class="hint">Sizes to scale, distances not. On this scale the Sun would be a disk about ${Math.round(1391400 / 142984 * 10) / 10} times wider than Jupiter.</p>
    <div class="planet-detail" id="plDetail"></div>
    <div class="planet-grid" id="plGrid">${WORLDS.map(w => `<button class="planet-card" data-id="${w.id}"><canvas aria-hidden="true"></canvas><b>${w.name}</b><span>${w.kind}</span></button>`).join('')}</div>
    <p class="hint">Planet images are illustrations drawn by this site, not photographs.</p>
    ${sourceNote('Data from the NASA NSSDCA Planetary Fact Sheet. Distance from Earth today from JPL approximate elements.')}`;
  function scale() {
    canvasArt($('#plScale', root), (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 3, 0.5);
      const total = WORLDS.reduce((s, w) => s + w.d, 0), gap = 10 * dpr, k = Math.min((W - gap * 9) / total, (H * 0.7) / 142984);
      let x = gap; const cy = H * 0.46, pos = [];
      ctx.font = `${10 * dpr}px ${FONT}`;
      WORLDS.forEach(w => { const r = w.d * k / 2; drawWorld(ctx, w.id, x + r, cy, Math.max(r, 1.2 * dpr), { noRings: w.id === 'saturn' && r < 6 }); pos.push([w.name, x + r]); x += 2 * r + gap; });
      ctx.fillStyle = 'rgba(205,216,235,.85)';
      const rocky = pos.slice(0, 4), fits = rocky.every(([n, px], i) => i === 0 || px - ctx.measureText(n).width / 2 > rocky[i - 1][1] + ctx.measureText(rocky[i - 1][0]).width / 2 + 4 * dpr);
      if (fits) { ctx.textAlign = 'center'; rocky.forEach(([n, px]) => ctx.fillText(n, Math.max(px, ctx.measureText(n).width / 2 + 4 * dpr), H - 8 * dpr)); }
      else { ctx.textAlign = 'left'; ctx.fillText('Mercury, Venus, Earth, Mars', 6 * dpr, H - 8 * dpr); }
      ctx.textAlign = 'center'; pos.slice(4).forEach(([n, px], i) => ctx.fillText(n, Math.min(px, W - ctx.measureText(n).width / 2 - 4 * dpr), H - (fits || i % 2 ? 8 : 22) * dpr));
    });
  }
  function grid() { $$('.planet-card', root).forEach(b => { b.classList.toggle('on', b.dataset.id === sel); canvasArt($('canvas', b), (ctx, W, H) => { spaceBg(ctx, W, H, 2, 0.4); drawWorld(ctx, b.dataset.id, W / 2, H / 2, Math.min(W, H) * (b.dataset.id === 'saturn' ? 0.2 : 0.36)); }); }); }
  function detail() {
    const w = WORLDS.find(x => x.id === sel), e = WORLDS[2], j = A.jd(new Date());
    const g = sel === 'earth' ? null : A.geo(sel, j);
    const bar = (label, v, ref, unit) => { const pct = Math.min(100, v / Math.max(v, ref) * 100), pe = Math.min(100, ref / Math.max(v, ref) * 100); return `<div class="cmp"><span>${label}</span><div class="cmp-bars"><i style="width:${pct}%;background:${w.color}"></i><i class="earth" style="width:${pe}%"></i></div><b>${unit}</b></div>`; };
    const dayTxt = w.day > 48 ? `${num(w.day / 24, 1)} Earth days` : `${num(w.day, 1)} hours`;
    const yearTxt = w.year > 1000 ? `${num(w.year / 365.25, 1)} Earth years` : `${num(w.year, 1)} days`;
    $('#plDetail', root).innerHTML = `<div class="pd-art"><canvas id="plBig" role="img" aria-label="Illustration of ${w.name}"></canvas></div>
      <div class="pd-txt"><p class="muted" style="margin:0">${w.kind}, planet ${WORLDS.indexOf(w) + 1} from the Sun</p><h2>${w.name}</h2><p>${esc(w.blurb)}</p>
      <dl class="kv"><dt>Diameter</dt><dd>${num(w.d)} km</dd><dt>Surface gravity</dt><dd>${w.g.toFixed(1)} m/s²</dd><dt>Length of day</dt><dd>${dayTxt}</dd><dt>Length of year</dt><dd>${yearTxt}</dd><dt>Average distance from the Sun</dt><dd>${num(w.dist, 1)} million km</dd><dt>Mean temperature</dt><dd>${w.temp} °C</dd>
      ${g ? `<dt>Distance from Earth today</dt><dd>${num(g.dist * 149.6, 0)} million km</dd>` : ''}</dl>
      ${sel === 'earth' ? '' : `<h3 class="h-sub" style="margin-top:14px">Compared with Earth</h3>${bar('Width', w.d, e.d, `${(w.d / e.d).toFixed(2)}×`)}${bar('Gravity', w.g, e.g, `${(w.g / e.g).toFixed(2)}×`)}<p class="hint"><span class="sw-earth"></span> Earth</p>`}
      ${w.id === 'jupiter' || w.id === 'saturn' || w.id === 'uranus' || w.id === 'neptune' ? '<p class="hint">Gas and ice giants have no solid surface; gravity is given at the cloud tops.</p>' : ''}</div>`;
    canvasArt($('#plBig', root), (ctx, W, H) => { spaceBg(ctx, W, H, 12); drawWorld(ctx, w.id, W / 2, H / 2, Math.min(W, H) * (w.id === 'saturn' ? 0.24 : 0.4)); });
  }
  $('#plGrid', root).addEventListener('click', e => { const b = e.target.closest('.planet-card'); if (!b) return; sel = b.dataset.id; grid(); detail(); $('#plDetail', root).scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' }); });
  const all = () => { scale(); grid(); detail(); };
  all(); watch($('#plScale', root), all);
};

/* ---------- Solar System (orrery) ---------- */
SCREENS['solar-system'] = root => {
  let off = 0, playing = false, view = 'inner';
  root.innerHTML = head('Solar System', 'Where each planet is in its orbit, seen from above. Step through time to watch the inner planets lap the outer ones.') + `
    <div class="orrery"><canvas id="orCv" role="img" aria-label="Top-down view of planetary orbits"></canvas><span class="chip chip-time orrery-date" id="orDate"></span></div>
    <div class="row" style="margin-top:10px"><button class="btn btn-small" data-d="-30">−30 days</button><button class="btn btn-small" data-d="-1">−1 day</button><button class="btn btn-small" data-d="0">Today</button><button class="btn btn-small" data-d="1">+1 day</button><button class="btn btn-small" data-d="30">+30 days</button><button class="btn btn-small btn-primary" id="orPlay">Play</button></div>
    <fieldset style="margin-top:14px"><legend>View</legend><div class="seg"><label><input type="radio" name="orView" value="inner" checked><span>Inner planets, true distances</span></label><label><input type="radio" name="orView" value="all"><span>All planets, compressed</span></label></div></fieldset>
    <p class="hint" id="orNote"></p>
    ${sourceNote('Positions from JPL "Approximate Positions of the Planets" (Standish), valid 1800–2050. Checked against published opposition dates to within a day.')}`;
  function draw() {
    const j = A.jd(new Date()) + off;
    $('#orDate', root).textContent = fmtDate(A.fromJd(j));
    $('#orNote', root).textContent = view === 'inner' ? 'Distances to scale out to Mars. Planet dots are enlarged; at this scale they would be far too small to see.' : 'Distances compressed (square-root scale) so Neptune fits. Planet dots are enlarged. No single view can show sizes, distances and periods to scale at once.';
    canvasArt($('#orCv', root), (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 71, 0.6);
      const cx = W / 2, cy = H / 2, half = Math.min(W, H) / 2 - 14 * dpr;
      const names = view === 'inner' ? ['mercury', 'venus', 'earth', 'mars'] : ['mercury', 'venus', 'earth', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune'];
      const map = view === 'inner' ? (x, y) => { const k = half / 1.7; return [cx + x * k, cy - y * k]; } : (x, y) => { const r = Math.hypot(x, y), s = Math.sqrt(r) / Math.sqrt(31) * half / (r || 1); return [cx + x * s, cy - y * s]; };
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, 18 * dpr); g.addColorStop(0, 'rgba(255,220,120,1)'); g.addColorStop(1, 'rgba(255,200,80,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, 18 * dpr, 0, TAU); ctx.fill(); ctx.fillStyle = '#ffd257'; ctx.beginPath(); ctx.arc(cx, cy, 6 * dpr, 0, TAU); ctx.fill();
      ctx.font = `700 ${11 * dpr}px ${FONT}`; ctx.textAlign = 'center';
      names.forEach(n => {
        const pts = A.orbitPoints(n, j, 180); ctx.strokeStyle = 'rgba(150,170,205,.32)'; ctx.lineWidth = dpr; ctx.beginPath();
        pts.forEach(([x, y], i) => { const [X, Y] = map(x, y); i ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y); }); ctx.stroke();
        const p = A.helio(n, j), [X, Y] = map(p.x, p.y), w = WORLDS.find(q => q.id === n), pr = (n === 'jupiter' || n === 'saturn' ? 6 : 4.5) * dpr;
        drawWorld(ctx, n, X, Y, pr, { noRings: true, shade: 0.4 });
        if (view === 'inner' || !['mercury', 'venus', 'earth', 'mars'].includes(n)) { ctx.fillStyle = 'rgba(230,236,248,.9)'; const tw = ctx.measureText(w.name).width; ctx.fillText(w.name, clamp(X, tw / 2 + 4 * dpr, W - tw / 2 - 4 * dpr), Y - pr - 6 * dpr); }
      });
      if (view === 'all') { ctx.fillStyle = 'rgba(205,216,235,.8)'; ctx.font = `${10 * dpr}px ${FONT}`; ctx.fillText('inner planets', cx, cy + 26 * dpr); }
      if (view === 'inner') { ctx.fillStyle = 'rgba(205,216,235,.7)'; ctx.font = `${10 * dpr}px ${FONT}`; ctx.textAlign = 'left'; const k = half / 1.7; ctx.fillRect(14 * dpr, H - 16 * dpr, k, 2 * dpr); ctx.fillText('1 AU, 150 million km', 14 * dpr, H - 22 * dpr); }
    });
  }
  $$('button[data-d]', root).forEach(b => b.addEventListener('click', () => { const d = Number(b.dataset.d); off = d === 0 ? 0 : off + d; draw(); }));
  $('#orPlay', root).addEventListener('click', () => { playing = !playing; $('#orPlay', root).textContent = playing ? 'Pause' : 'Play'; });
  $$('input[name="orView"]', root).forEach(i => i.addEventListener('change', () => { view = i.value; draw(); }));
  loop(dt => { if (playing) { off += dt * (view === 'inner' ? 40 : 400); draw(); } });
  draw(); watch($('#orCv', root), draw);
};

/* ---------- Sun ---------- */
SCREENS.sun = root => {
  root.innerHTML = head('The Sun', 'A middle-aged, middle-sized star that holds 99.8% of the Solar System\'s mass.') + `
    <div class="callout warn-callout"><p><b>Never look directly at the Sun</b>, even briefly, and never through binoculars or a telescope without a certified solar filter. It can permanently damage your eyes.</p></div>
    <div class="topic-grid">
      <div class="sun-art"><canvas id="snCv" role="img" aria-label="Cutaway illustration of the Sun's layers"></canvas></div>
      <div>
        <h2 class="h-sub" style="margin-top:0">Inside out</h2>
        <ul class="layers">
          <li><i style="background:#fff6c8"></i><div><b>Core</b><p>About 15 million °C. Hydrogen fuses into helium here, releasing the energy that makes sunlight.</p></div></li>
          <li><i style="background:#ffd257"></i><div><b>Radiative zone</b><p>Energy creeps outward as light, absorbed and re-emitted countless times.</p></div></li>
          <li><i style="background:#ff9a2e"></i><div><b>Convection zone</b><p>Hot gas rises and sinks in churning cells, like a pot of boiling water.</p></div></li>
          <li><i style="background:#f07a1f"></i><div><b>Photosphere</b><p>The visible surface, about 5,500 °C. Sunspots are cooler patches where magnetic fields block the heat.</p></div></li>
          <li><i style="background:#ff6b6b"></i><div><b>Chromosphere</b><p>A thin, reddish layer seen during total eclipses.</p></div></li>
          <li><i style="background:#cfd8ff"></i><div><b>Corona</b><p>The outer atmosphere, over a million °C, far hotter than the surface below. Why is still being researched.</p></div></li>
        </ul>
      </div>
    </div>
    <h2 class="h-sub">At your location</h2>
    <div id="snLoc"></div>
    <dl class="kv" id="snNow" style="max-width:520px"></dl>
    <h2 class="h-sub">By the numbers</h2>
    <dl class="kv" style="max-width:520px"><dt>Diameter</dt><dd>1.39 million km, 109 Earths</dd><dt>Age</dt><dd>About 4.6 billion years</dd><dt>Light travel time to Earth</dt><dd>8 min 19 s</dd><dt>Solar cycle</dt><dd>About 11 years</dd></dl>
    <p class="hint">Solar Cycle 25 reached its maximum period in 2024, according to NASA and NOAA, and activity is now expected to decline gradually toward the next minimum.</p>
    ${sourceNote('IAU 2015 nominal solar values; NASA Sun fact sheet; NASA and NOAA solar-cycle announcement (October 2024). Sunspots in the illustration are not real current spots.')}`;
  function draw() {
    canvasArt($('#snCv', root), (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 41, 0.4);
      const cx = W * 0.5, cy = H * 0.52, r = Math.min(W, H) * 0.36;
      const cg = ctx.createRadialGradient(cx, cy, r * 0.95, cx, cy, r * 1.7); cg.addColorStop(0, 'rgba(220,228,255,.45)'); cg.addColorStop(1, 'rgba(220,228,255,0)'); ctx.fillStyle = cg; ctx.beginPath(); ctx.arc(cx, cy, r * 1.7, 0, TAU); ctx.fill();
      drawWorld(ctx, 'sun', cx, cy, r, { spots: true });
      ctx.save(); ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r * 1.01, -Math.PI / 2, 0); ctx.closePath(); ctx.clip();
      [[1, '#f07a1f'], [0.97, '#ff9a2e'], [0.7, '#ffd257'], [0.25, '#fff6c8']].forEach(([f, c]) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(cx, cy, r * f, 0, TAU); ctx.fill(); });
      ctx.restore();
      ctx.strokeStyle = 'rgba(255,107,107,.8)'; ctx.lineWidth = 2.2 * dpr; ctx.beginPath(); ctx.arc(cx, cy, r * 1.015, Math.PI * 0.05, Math.PI * 0.95); ctx.stroke();
      ctx.fillStyle = 'rgba(255,120,90,.85)'; ctx.beginPath(); ctx.ellipse(cx - r * 0.72, cy + r * 0.72, r * 0.08, r * 0.14, 0.8, 0, TAU); ctx.fill();
      ctx.fillStyle = '#e9eef7'; ctx.font = `700 ${11 * dpr}px ${FONT}`; ctx.textAlign = 'left';
      const lab = (t, x, y, tx, ty) => { const w = ctx.measureText(t).width; ctx.strokeStyle = 'rgba(233,238,247,.6)'; ctx.lineWidth = dpr; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(tx, ty); ctx.stroke(); const right = tx + 4 * dpr + w > W - 6 * dpr; ctx.textAlign = right ? 'right' : 'left'; ctx.fillText(t, right ? Math.min(tx - 4 * dpr, W - 6 * dpr) : tx + 4 * dpr, ty + (right ? -6 : 4) * dpr); ctx.textAlign = 'left'; };
      ctx.textAlign = 'right';
      [['Core', 0.12, 0.12, 1.3], ['Radiative zone', 0.45, 0.32, 1.13], ['Convection zone', 0.8, 0.5, 0.96]].forEach(([t, ax, ay, row]) => {
        const y = cy - r * row, x2 = W - 8 * dpr, w = ctx.measureText(t).width;
        ctx.strokeStyle = 'rgba(233,238,247,.6)'; ctx.lineWidth = dpr; ctx.beginPath(); ctx.moveTo(cx + r * ax, cy - r * ay); ctx.lineTo(x2 - w - 6 * dpr, y); ctx.stroke();
        ctx.fillText(t, x2, y + 4 * dpr);
      });
      ctx.textAlign = 'left';
      ctx.fillText('Corona', Math.max(8 * dpr, cx - r * 1.45), Math.max(16 * dpr, cy - r * 1.1));
    });
  }
  function now() {
    const loc = Loc.get(), j = A.jd(new Date()), h = A.bodyAltAz('sun', j, loc.lat, loc.lon);
    let rise = null, set = null, prev = h.alt;
    for (let i = 1; i <= 288; i++) { const a = A.bodyAltAz('sun', j + i * 5 / 1440, loc.lat, loc.lon).alt; if (prev < -0.83 && a >= -0.83 && !rise) rise = j + i * 5 / 1440; if (prev >= -0.83 && a < -0.83 && !set) set = j + i * 5 / 1440; prev = a; }
    $('#snNow', root).innerHTML = `<dt>Right now</dt><dd>${h.alt > 0 ? `${Math.round(h.alt)}° above the ${dirName(h.az)} horizon` : `Below the horizon (${Math.round(-h.alt)}°)`}</dd><dt>Next sunrise</dt><dd>${rise ? `${fmtDay(A.fromJd(rise))}, ${fmtTime(A.fromJd(rise))}` : 'None in the next 24 hours'}</dd><dt>Next sunset</dt><dd>${set ? `${fmtDay(A.fromJd(set))}, ${fmtTime(A.fromJd(set))}` : 'None in the next 24 hours'}</dd>`;
  }
  $('#snLoc', root).appendChild(locationPicker(now));
  draw(); now(); watch($('#snCv', root), draw);
};

/* ---------- Eclipses ---------- */
SCREENS.eclipses = root => {
  let mode = 'solar';
  const list = nextEclipses(), first = list[0];
  root.innerHTML = head('Eclipses', 'When the Sun, Earth and Moon line up, one casts a shadow on another. Here is how it works and when the next ones happen.') + `
    ${first ? `<div class="next-card"><div class="nc-art"><canvas id="ecNext" aria-hidden="true"></canvas></div><div><p class="muted" style="margin:0">Next eclipse, ${inDays(first.d)}</p><h2>${cap(first.type)} ${first.kind} eclipse</h2><p><b>${fmtDate(first.d)}</b>. ${esc(first.where)}.</p>${first.kind === 'solar' ? '<p class="hint">Solar eclipses need eye protection except during totality.</p>' : '<p class="hint">Lunar eclipses are safe to watch with your eyes.</p>'}</div></div>` : ''}
    <h2 class="h-sub">How eclipses happen</h2>
    <div class="seg" style="margin-bottom:10px"><label><input type="radio" name="ecMode" value="solar" checked><span>Solar eclipse</span></label><label><input type="radio" name="ecMode" value="lunar"><span>Lunar eclipse</span></label></div>
    <div class="diagram"><canvas id="ecDiag" role="img" aria-label="Diagram of Sun, Moon and Earth during an eclipse"></canvas></div>
    <p class="hint" id="ecExplain"></p>
    <h2 class="h-sub">Coming up</h2>
    <ul class="eclipse-list">${list.map((e, i) => `<li><canvas data-i="${i}" aria-hidden="true"></canvas><div><b>${cap(e.type)} ${e.kind} eclipse</b><p>${fmtDate(e.d)}, ${inDays(e.d)}</p><p class="muted">${esc(e.where)}</p></div></li>`).join('')}</ul>
    ${sourceNote('Dates from NASA\'s Five Millennium Canon of eclipses (Espenak and Meeus), eclipse.gsfc.nasa.gov. Dates are in Universal Time.')}`;
  const explain = { solar: 'Solar eclipse: the Moon passes between the Sun and Earth, and its shadow falls on a narrow strip of Earth. Inside the dark inner shadow (umbra) the eclipse is total; in the lighter outer shadow (penumbra) it is partial. If the Moon is near its farthest point, it looks too small to cover the Sun and leaves a ring: an annular eclipse.', lunar: 'Lunar eclipse: Earth passes between the Sun and the Moon, and the Moon moves into Earth\'s shadow. Sunlight bent through Earth\'s atmosphere turns a totally eclipsed Moon red. Everyone on the night side of Earth can see it.' };
  function diag() {
    $('#ecExplain', root).textContent = explain[mode] + ' Diagram not to scale.';
    canvasArt($('#ecDiag', root), (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 13, 0.4);
      const cy = H / 2, sunR = H * 0.36, sx = -sunR * 0.35;
      drawWorld(ctx, 'sun', sx, cy, sunR);
      const ex = mode === 'solar' ? W * 0.82 : W * 0.55, er = H * 0.13, mx = mode === 'solar' ? W * 0.55 : W * 0.86, mr = H * 0.045;
      const occX = mode === 'solar' ? mx : ex, occR = mode === 'solar' ? mr : er;
      const tipX = occX + (occX - sx) * occR / (sunR - occR) * (mode === 'solar' ? 1 : 0.45);
      const pen = ctx.createLinearGradient(occX, 0, W, 0); pen.addColorStop(0, 'rgba(0,0,0,.45)'); pen.addColorStop(1, 'rgba(0,0,0,.15)');
      ctx.fillStyle = pen; ctx.beginPath(); ctx.moveTo(occX, cy - occR); ctx.lineTo(W, cy - occR - (W - occX) * (sunR + occR) / (occX - sx) * 0.6); ctx.lineTo(W, cy + occR + (W - occX) * (sunR + occR) / (occX - sx) * 0.6); ctx.lineTo(occX, cy + occR); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,.75)'; ctx.beginPath(); ctx.moveTo(occX, cy - occR); ctx.lineTo(tipX, cy); ctx.lineTo(occX, cy + occR); ctx.closePath(); ctx.fill();
      drawWorld(ctx, 'earth', ex, cy, er);
      if (mode === 'lunar') { drawWorld(ctx, 'moon', mx, cy, mr); ctx.fillStyle = 'rgba(150,45,20,.6)'; ctx.beginPath(); ctx.arc(mx, cy, mr, 0, TAU); ctx.fill(); } else drawWorld(ctx, 'moon', mx, cy, mr);
      ctx.fillStyle = '#e9eef7'; ctx.font = `700 ${11 * dpr}px ${FONT}`; ctx.textAlign = 'center';
      ctx.fillText('Sun', Math.max(30 * dpr, sx + sunR * 0.6), cy + sunR + 4 * dpr > H ? H - 8 * dpr : cy + sunR * 0.95);
      ctx.fillText('Earth', ex, cy + er + 16 * dpr); ctx.fillText('Moon', mx, cy - mr - 10 * dpr);
      ctx.fillStyle = 'rgba(205,216,235,.75)'; ctx.font = `${10 * dpr}px ${FONT}`;
      ctx.fillText('umbra', (occX + tipX) / 2 + (mode === 'solar' ? 0 : 6 * dpr), cy + 3 * dpr); ctx.fillText('penumbra', occX + (W - occX) * 0.55, cy - occR - 20 * dpr);
    });
  }
  function icons() {
    if (first) canvasArt($('#ecNext', root), (ctx, W, H) => { spaceBg(ctx, W, H, 83, 0.6); eclipseIcon(ctx, W / 2, H / 2, Math.min(W, H) * 0.24, first.kind, first.type); });
    $$('.eclipse-list canvas', root).forEach(cv => { const e = list[Number(cv.dataset.i)]; canvasArt(cv, (ctx, W, H) => { spaceBg(ctx, W, H, 5, 0.3); eclipseIcon(ctx, W / 2, H / 2, Math.min(W, H) * 0.26, e.kind, e.type); }); });
  }
  $$('input[name="ecMode"]', root).forEach(i => i.addEventListener('change', () => { mode = i.value; diag(); }));
  const all = () => { diag(); icons(); };
  all(); watch($('#ecDiag', root), all);
};

/* ---------- Meteor showers ---------- */
SCREENS.meteors = root => {
  const upcoming = nextShower(), next = upcoming[0];
  const seen = new Set(), year = upcoming.filter(s => !seen.has(s.name) && seen.add(s.name));
  const moonAt = d => A.moonPhase(A.jd(d) + 0.1).illum;
  const nm = moonAt(next.date);
  root.innerHTML = head('Meteor showers', 'Several times a year Earth ploughs through dust left by a comet or asteroid. The grains burn up as shooting stars.') + `
    <div class="meteor-stage"><canvas id="mtCv" role="img" aria-label="Animated meteors streaking from a radiant point"></canvas>
      <div class="meteor-over"><p class="muted" style="margin:0">Next peak, ${inDays(next.date)}</p><h2>${esc(next.name)}</h2><p>${fmtDate(next.date)}. Up to ${next.zhr} an hour under ideal skies. Radiant in ${esc(next.radiant)}.</p>
      <p>Moon ${Math.round(nm * 100)}% lit at the peak: ${nm < 0.35 ? 'good dark skies.' : nm < 0.7 ? 'some moonlight will hide fainter meteors.' : 'bright moonlight will wash out many meteors.'}</p></div></div>
    <p class="hint">Meteors seem to come from one point, the radiant, because the particles travel in parallel and perspective makes them spread out, like snowflakes in headlights.</p>
    <h2 class="h-sub">The year's main showers</h2>
    <ul class="shower-list">${year.map(s => { const mi = moonAt(s.date); return `<li><div class="sh-head"><b>${esc(s.name)}</b><span class="muted">${fmtDate(s.date, { year: undefined })}, ${inDays(s.date)}</span></div>
      <div class="rate" role="img" aria-label="Up to ${s.zhr} meteors per hour"><i style="width:${Math.max(4, s.zhr / 150 * 100)}%"></i></div>
      <p>Up to <b>${s.zhr}</b> an hour. Active ${esc(s.active)}. From ${esc(s.parent)}; radiant in ${esc(s.radiant)}.</p><p class="muted">${esc(s.note)} Moon ${Math.round(mi * 100)}% lit at this year's peak.</p></li>`; }).join('')}</ul>
    <p class="hint">"Up to" is the zenithal hourly rate: what one observer would see under perfectly dark skies with the radiant overhead. Real counts are usually lower.</p>
    ${sourceNote('Dates and rates from the International Meteor Organization shower calendar. Peaks shift by about a day from year to year; Moon illumination is calculated for the dates shown.')}`;
  const cv = $('#mtCv', root), r = rng(9);
  let streaks = [];
  function frame(dt) {
    canvasArt(cv, (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 97, 1.1);
      const rx = W * 0.72, ry = H * 0.2;
      ctx.strokeStyle = 'rgba(242,184,91,.5)'; ctx.lineWidth = dpr; ctx.beginPath(); ctx.arc(rx, ry, 6 * dpr, 0, TAU); ctx.stroke();
      if (!reduceMotion && r() < dt * 2.2) { const a = r() * TAU, d0 = (20 + r() * 120) * dpr; streaks.push({ a, d: d0, L: (40 + r() * 110) * dpr, life: 0, max: 0.6 + r() * 0.5 }); }
      if (reduceMotion && !streaks.length) for (let i = 0; i < 9; i++) streaks.push({ a: r() * TAU, d: (40 + r() * 160) * dpr, L: (50 + r() * 100) * dpr, life: 0.3, max: 1e9 });
      streaks = streaks.filter(s => (s.life += dt) < s.max);
      streaks.forEach(s => {
        const prog = reduceMotion ? 0.6 : s.life / s.max, d = s.d + prog * s.L * 1.6;
        const x1 = rx + Math.cos(s.a) * d, y1 = ry + Math.sin(s.a) * d, x0 = rx + Math.cos(s.a) * (d - s.L), y0 = ry + Math.sin(s.a) * (d - s.L);
        const g = ctx.createLinearGradient(x0, y0, x1, y1); const al = Math.sin(Math.PI * Math.min(1, prog)); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, `rgba(225,240,255,${0.95 * al})`);
        ctx.strokeStyle = g; ctx.lineWidth = 1.8 * dpr; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      });
    });
  }
  if (reduceMotion) { frame(0); watch(cv, () => frame(0)); } else loop(frame);
};

/* ---------- Jupiter's moons ---------- */
SCREENS.jupiter = root => {
  let hours = 0;
  const INFO = { Io: 'The most volcanically active body in the Solar System. Orbits in 1.77 days.', Europa: 'An icy shell over what is very likely a salty ocean. Orbits in 3.55 days.', Ganymede: 'The largest moon in the Solar System, wider than Mercury. Orbits in 7.15 days.', Callisto: 'One of the most heavily cratered surfaces known. Orbits in 16.7 days.' };
  root.innerHTML = head("Jupiter's moons", 'Galileo saw these four moons in 1610 and watched them change places night after night. A small pair of binoculars shows them today.') + `
    <div class="jup-stage"><canvas id="jpCv" role="img" aria-label="Jupiter and its four large moons as seen from Earth"></canvas></div>
    <div class="field" style="margin-top:12px"><div class="field-head"><label for="jpT">Time</label><output id="jpTOut"></output></div><input type="range" id="jpT" min="-48" max="96" step="1" value="0"><p class="hint">Drag to watch the moons move over six days. Io changes side in less than a day.</p></div>
    <p class="callout" id="jpVis"></p>
    <ul class="moon-cards" id="jpList"></ul>
    <p class="hint">View as in binoculars with north up: west is on the right. Telescopes often flip or mirror this. Moon sizes are enlarged; distances from Jupiter are to scale.</p>
    ${sourceNote('Positions from Meeus, Astronomical Algorithms (ch. 44, lower-accuracy method), checked against the book\'s worked example to within 0.02 Jupiter radii.')}`;
  function draw() {
    const j = A.jd(new Date()) + hours / 24, ms = A.galilean(j);
    $('#jpTOut', root).textContent = hours === 0 ? 'Now' : `${hours > 0 ? '+' : '−'}${Math.abs(hours)} h, ${fmtDay(A.fromJd(j))} ${fmtTime(A.fromJd(j))}`;
    canvasArt($('#jpCv', root), (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 17, 0.5);
      const cx = W / 2, cy = H * 0.48, sc = (W / 2 - 18 * dpr) / 28, rj = Math.max(sc, 9 * dpr);
      ms.filter(m => m.behind).forEach(m => moon(ctx, m, cx, cy, sc, dpr, rj));
      drawWorld(ctx, 'jupiter', cx, cy, rj);
      ms.filter(m => !m.behind).forEach(m => moon(ctx, m, cx, cy, sc, dpr, rj));
      ctx.fillStyle = 'rgba(205,216,235,.7)'; ctx.font = `700 ${11 * dpr}px ${FONT}`; ctx.textAlign = 'left'; ctx.fillText('East', 8 * dpr, H - 10 * dpr); ctx.textAlign = 'right'; ctx.fillText('West', W - 8 * dpr, H - 10 * dpr);
    });
    $('#jpList', root).innerHTML = ms.map(m => { const pos = Math.abs(m.x) < 1 ? (m.behind ? 'Hidden behind Jupiter' : 'Crossing in front of Jupiter') : `${Math.abs(m.x).toFixed(1)} Jupiter radii to the ${m.x > 0 ? 'west' : 'east'}`; return `<li><b>${m.name}</b><p>${pos}.</p><p class="muted">${INFO[m.name]}</p></li>`; }).join('');
    const el = A.elongation('jupiter', j);
    $('#jpVis', root).textContent = el < 15 ? 'Jupiter is too close to the Sun to observe right now; this shows where the moons are even so.' : `Jupiter is ${el > 120 ? 'well placed for viewing, up for much of the night' : el > 60 ? 'visible for part of the night' : 'low in twilight'}. See Observe tonight for when it rises.`;
  }
  function moon(ctx, m, cx, cy, sc, dpr, rj) {
    if (m.behind && Math.abs(m.x) < 1) return;
    const x = cx + m.x * sc, r = { Io: 3.3, Europa: 3, Ganymede: 4, Callisto: 3.7 }[m.name] * dpr;
    ctx.fillStyle = { Io: '#f3dd8a', Europa: '#e9e2d0', Ganymede: '#c8bba6', Callisto: '#9d8f80' }[m.name];
    ctx.beginPath(); ctx.arc(x, cy, r, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(225,232,245,.9)'; ctx.font = `${11 * dpr}px ${FONT}`; ctx.textAlign = 'center';
    const lift = { Io: -1, Europa: 1, Ganymede: -1.9, Callisto: 1.9 }[m.name];
    ctx.fillText(m.name, x, cy + lift * (rj + 12 * dpr) + (lift > 0 ? 4 * dpr : 0));
  }
  $('#jpT', root).addEventListener('input', e => { hours = Number(e.target.value); draw(); });
  draw(); watch($('#jpCv', root), draw);
};

/* ---------- Weight and age ---------- */
SCREENS.weight = root => {
  root.innerHTML = head('Weight and age on other worlds', 'Your mass is the same everywhere. What changes is gravity\'s pull, and how long a year lasts.') + `
    <div class="wa-inputs"><label>Your mass <span class="unit-in"><input id="waKg" type="number" min="1" max="500" value="60" inputmode="decimal"> kg</span></label><label>Your age <span class="unit-in"><input id="waAge" type="number" min="0" max="130" value="30" inputmode="decimal"> years</span></label></div>
    <ul class="wa-grid" id="waGrid"></ul>
    <p class="hint">"Scale reads" is what a bathroom scale set up on Earth would show, because it measures the pull of gravity. Gas and ice giants have no ground to stand on; their values are at the cloud tops.</p>
    ${sourceNote('Surface gravity and orbital periods from the NASA NSSDCA Planetary Fact Sheet.')}`;
  const worlds = [...WORLDS.slice(0, 3), EXTRA[0], ...WORLDS.slice(3), EXTRA[1]];
  function render() {
    const kg = clamp(Number($('#waKg', root).value) || 0, 0, 500), age = clamp(Number($('#waAge', root).value) || 0, 0, 130);
    $('#waGrid', root).innerHTML = worlds.map(w => {
      const read = kg * w.g / 9.8, yrs = w.year ? age * 365.25 / w.year : null;
      return `<li><canvas data-w="${w.id}" aria-hidden="true"></canvas><div><b>${w.name}</b><p>Scale reads <b>${read < 10 ? read.toFixed(1) : Math.round(read)} kg</b></p><div class="rate"><i style="width:${Math.min(100, w.g / 23.1 * 100)}%"></i></div>
        <p class="muted">${yrs === null ? 'Orbits Earth, so your age is the same' : w.id === 'earth' ? `${age} years old` : yrs < 1 ? `${yrs.toFixed(2)} ${w.name} years old: not one full orbit yet` : `${yrs < 10 ? yrs.toFixed(1) : Math.round(yrs)} ${w.name.replace('The ', '')} years old`}</p></div></li>`;
    }).join('');
    $$('canvas[data-w]', root).forEach(cv => canvasArt(cv, (ctx, W, H) => { ctx.clearRect(0, 0, W, H); drawWorld(ctx, cv.dataset.w, W / 2, H / 2, Math.min(W, H) * (cv.dataset.w === 'saturn' ? 0.2 : 0.42)); }));
  }
  ['#waKg', '#waAge'].forEach(s => $(s, root).addEventListener('input', render));
  render();
};

/* ---------- Missions and ISS ---------- */
SCREENS.missions = root => {
  root.innerHTML = head('Missions and the ISS', 'Spacecraft that changed what we know, and the station where people live in orbit.') + `
    <div class="topic-grid">
      <div class="iss-stage"><canvas id="isCv" role="img" aria-label="Illustration of the Space Station's tilted orbit around Earth"></canvas></div>
      <div>
        <h2 class="h-sub" style="margin-top:0">International Space Station</h2>
        <dl class="kv"><dt>Height</dt><dd>About 400 km</dd><dt>Speed</dt><dd>About 28,000 km/h</dd><dt>One orbit</dt><dd>About 92 minutes</dd><dt>Orbits per day</dt><dd>About 15.5</dd><dt>Orbit tilt</dt><dd>51.6° to the equator</dd><dt>Mass</dt><dd>About 420 tonnes</dd></dl>
        <p class="hint">Because of the 51.6° tilt, the station passes over every place between latitudes 51.6° north and south. NASA plans to retire and deorbit it around 2030.</p>
        <p class="hint">The animation shows the shape and tilt of the orbit, not the station's live position. For passes over your town, NASA's <a href="https://spotthestation.nasa.gov/" target="_blank" rel="noopener">Spot the Station</a> uses current orbit data.</p>
      </div>
    </div>
    <h2 class="h-sub">Missions timeline</h2>
    <ol class="mission-list">${MISSIONS.map((m, i) => `<li><canvas data-m="${i}" aria-hidden="true"></canvas><div><p class="muted" style="margin:0">${m.y}, ${esc(m.who)}</p><b>${esc(m.name)}</b><p>${esc(m.text)}</p></div></li>`).join('')}</ol>
    ${sourceNote('Mission facts from NASA, ESA and CSA mission pages. Artemis II details checked against NASA reporting, October 2026.')}`;
  $$('canvas[data-m]', root).forEach(cv => { const m = MISSIONS[Number(cv.dataset.m)]; canvasArt(cv, (ctx, W, H) => { spaceBg(ctx, W, H, 7 + Number(cv.dataset.m), 0.5); if (m.name === 'Artemis II') drawWorld(ctx, 'moon', W * 0.8, H * 0.25, W * 0.18); spacecraft(ctx, m.icon, W / 2, H / 2, Math.min(W, H) * 0.42); }); });
  let ph = 0;
  function draw(dt) {
    ph += reduceMotion ? 0 : dt * TAU / 10;
    canvasArt($('#isCv', root), (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 53, 0.7);
      const cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.33, oR = R * 1.12, tilt = 51.6 * D2R * 0.55;
      const pt = a => { const x = Math.cos(a) * oR, y = Math.sin(a) * oR * 0.32; return [cx + x * Math.cos(tilt) - y * Math.sin(tilt), cy + x * Math.sin(tilt) + y * Math.cos(tilt), Math.sin(a)]; };
      const path = (from, to) => { ctx.beginPath(); for (let a = from; a <= to; a += 0.03) { const [x, y] = pt(a); a === from ? ctx.moveTo(x, y) : ctx.lineTo(x, y); } ctx.stroke(); };
      ctx.strokeStyle = 'rgba(92,214,230,.35)'; ctx.lineWidth = 1.6 * dpr; path(Math.PI, TAU);
      const [sx, sy, front] = pt(ph % TAU);
      if (front < 0) spacecraft(ctx, 'station', sx, sy, 9 * dpr);
      drawWorld(ctx, 'earth', cx, cy, R);
      ctx.strokeStyle = 'rgba(92,214,230,.85)'; path(0, Math.PI);
      if (front >= 0) spacecraft(ctx, 'station', sx, sy, 11 * dpr);
      ctx.fillStyle = 'rgba(205,216,235,.75)'; ctx.font = `${10 * dpr}px ${FONT}`; ctx.textAlign = 'left'; ctx.fillText('Orbit height exaggerated about 2× so it is visible', 8 * dpr, H - 8 * dpr);
    });
  }
  if (reduceMotion) { draw(0); watch($('#isCv', root), () => draw(0)); } else loop(draw);
};

/* ======================= Hooks ======================= */
const TITLES = Object.fromEntries(TOPICS.map(t => [t.id, t.title]));
APP.HOOKS.explore = (() => {
  let ro = null, timer = null;
  return {
    enter() { if (!ro) ro = mountTiles($('#exploreTiles')); else paintTiles($('#exploreTiles')); timer = setInterval(() => paintTiles($('#exploreTiles')), 120000); },
    leave() { clearInterval(timer); },
  };
})();
APP.HOOKS.topic = {
  enter(id) {
    cleanup.forEach(f => f()); cleanup = [];
    const root = $('#topicRoot');
    if (!SCREENS[id]) { root.innerHTML = head('Not found', `There is no topic called "${esc(id || '')}". <a href="#/explore">See all topics</a>.`); return; }
    SCREENS[id](root);
  },
  leave() { cleanup.forEach(f => f()); cleanup = []; },
  title: id => TITLES[id] || 'Explore',
};
return { mountTiles, paintTiles, Loc, nightPlan, drawWorld, drawMoonPhase, TOPICS, WORLDS, spaceBg, rng, canvasArt };
})();
