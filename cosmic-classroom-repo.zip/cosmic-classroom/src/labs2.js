/* ---------- Labs A, C, E, F ---------- */
const LABS2 = (() => {
'use strict';
const { $, $$, esc, clamp, sizeCanvas, reduceMotion } = APP;
const { drawWorld, spaceBg, rng, canvasArt, WORLDS } = EXPLORE;
const A = ASTRO, TAU = Math.PI * 2, D2R = Math.PI / 180, FONT = APP.FONT;
const num = (x, p = 0) => Number(x).toLocaleString(undefined, { maximumFractionDigits: p, minimumFractionDigits: p });
const sig = (x, n = 3) => Number(x.toPrecision(n)).toLocaleString(undefined, { maximumFractionDigits: 20 });

/* ======================= Shared lab shell ======================= */
let cleanup = [];
const onCleanup = f => cleanup.push(f);
function loop(fn) { let raf = 0, last = performance.now(); const tick = now => { const dt = Math.min(0.05, (now - last) / 1000); last = now; fn(dt, now); raf = requestAnimationFrame(tick); }; raf = requestAnimationFrame(tick); onCleanup(() => cancelAnimationFrame(raf)); }
function watch(el, fn) { const ro = new ResizeObserver(fn); ro.observe(el); onCleanup(() => ro.disconnect()); }
function shell(root, o) {
  root.innerHTML = `<div class="lab-intro"><p class="crumbs" style="margin:0 0 8px"><a href="#/labs">Laboratories</a></p><h1>${o.title}</h1><p>${o.intro}</p></div>
    <div class="lab"><section class="stage" aria-label="${esc(o.title)} view">${o.stage}</section>
    <section class="panel" aria-label="${esc(o.title)} tools"><div class="tabs" role="tablist" aria-label="Lab sections">${o.tabs.map((t, i) => `<button class="tab" role="tab" id="lx-tab-${t.id}" aria-controls="lx-p-${t.id}" aria-selected="${i === 0}" ${i ? 'tabindex="-1"' : ''}>${t.label}</button>`).join('')}</div>
    ${o.tabs.map((t, i) => `<div class="tabpanel ${t.prose ? 'prose' : ''}" role="tabpanel" id="lx-p-${t.id}" aria-labelledby="lx-tab-${t.id}" ${i ? 'hidden' : ''}>${t.html}</div>`).join('')}</section></div>`;
  const tabs = $$('.tab', root);
  const select = tab => { tabs.forEach(t => { const on = t === tab; t.setAttribute('aria-selected', on); t.tabIndex = on ? 0 : -1; $('#' + t.getAttribute('aria-controls'), root).hidden = !on; }); o.onTab && o.onTab(tab.id.replace('lx-tab-', '')); };
  tabs.forEach((t, i) => { t.addEventListener('click', () => select(t)); t.addEventListener('keydown', e => { if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return; const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length]; n.focus(); select(n); }); });
  return { select: id => select($('#lx-tab-' + id, root)) };
}
function experiments(el, labId, list, hooks) {
  el.innerHTML = list.map(e => `<li class="exp" id="xp-${e.id}"><h3>${esc(e.title)}</h3><p class="law">${esc(e.law)}</p><p>${esc(e.setup)}</p>
    <button class="btn btn-small" data-act="setup" data-id="${e.id}">Set up this experiment</button>
    <div class="qa" hidden><p class="q">${esc(e.q)}</p><div class="opts">${e.options.map((o, i) => `<button class="opt" data-act="answer" data-id="${e.id}" data-i="${i}"><span>${esc(o)}</span><span class="mark"></span></button>`).join('')}</div><div class="result" aria-live="polite" hidden></div></div></li>`).join('');
  let active = null;
  el.addEventListener('click', ev => {
    const b = ev.target.closest('button[data-act]'); if (!b) return;
    const e = list.find(x => x.id === b.dataset.id), card = $('#xp-' + e.id, el);
    if (b.dataset.act === 'setup') {
      $$('.exp', el).forEach(n => n.classList.remove('is-active')); card.classList.add('is-active'); active = e.id;
      hooks.setup(e); $('.qa', card).hidden = false; $('.result', card).hidden = true; b.textContent = 'Start over';
      $$('.opt', card).forEach(o => { o.disabled = false; o.classList.remove('is-correct', 'is-wrong'); $('.mark', o).textContent = ''; });
    } else if (b.dataset.act === 'answer' && active === e.id) {
      const i = Number(b.dataset.i), right = i === e.answer;
      $$('.opt', card).forEach((o, j) => { o.disabled = true; if (j === e.answer) { o.classList.add('is-correct'); $('.mark', o).textContent = j === i ? 'Your answer, correct' : 'Answer'; } else if (j === i) { o.classList.add('is-wrong'); $('.mark', o).textContent = 'Your answer'; } });
      APP.Progress.prediction(labId + ':' + e.id, right);
      const res = $('.result', card); res.hidden = false;
      res.innerHTML = `<p><span class="verdict">${right ? 'Correct.' : `Not quite. The answer is “${esc(e.options[e.answer])}”.`}</span> ${esc(e.explain)}</p><div class="row"><button class="btn btn-small btn-primary" data-act="run" data-id="${e.id}">Run it</button></div>`;
    } else if (b.dataset.act === 'run') {
      const out = hooks.run(e); b.disabled = true;
      if (out) { const p = document.createElement('p'); p.innerHTML = out; $('.result', card).insertBefore(p, $('.result .row', card)); }
      const st = $('.stage', document.getElementById('view-labx')); if (st) { const r = st.getBoundingClientRect(); if (r.top < 0 || r.bottom > innerHeight) st.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' }); }
    }
  });
}
function labeler(ctx) { // draws a label only if it does not overlap one already placed this frame
  const placed = [];
  return (t, x, y, force = false) => {
    const w = ctx.measureText(t).width, h = parseFloat(ctx.font) || 12, r = [x - w / 2 - 2, y - h, x + w / 2 + 2, y + 3];
    if (!force && placed.some(p => !(r[2] < p[0] || r[0] > p[2] || r[3] < p[1] || r[1] > p[3]))) return false;
    placed.push(r); ctx.fillText(t, x, y); return true;
  };
}
const badge = (s, txt) => `<span class="badge" data-s="${s}">${txt}</span>`;
const checkRow = (name, s, label, txt) => `<li class="check"><div class="check-head"><span>${name}</span>${badge(s, label)}</div><p>${txt}</p></li>`;

/* =====================================================================
   LAB A — Solar System explorer
   ===================================================================== */
function solarLab(root) {
  const S = { j: A.jd(new Date()), playing: false, speed: 10, scale: 'sqrt', tilt: 50, rot: 20, zoom: 1, sel: 'earth', orbits: true, labels: true, trueSize: false, hits: [] };
  const NAMES = WORLDS.map(w => w.id);
  const ui = shell(root, {
    title: 'Solar System explorer',
    intro: 'The eight planets where they really are today, from JPL orbital elements. Tilt and turn the view, run time forward, and compare worlds. <b>No single picture can show sizes and distances to scale at once</b>; the View tab lets you see why.',
    stage: `<div class="viewport" id="ssView"><canvas id="ssCv" role="img" aria-label="The Solar System in perspective"></canvas>
        <div class="hud hud-tl"><span class="chip chip-time" id="ssDate"></span></div>
        <div class="hud hud-tr"><button class="zoom" id="ssIn" aria-label="Zoom in">+</button><button class="zoom" id="ssOut" aria-label="Zoom out">−</button><button class="zoom" id="ssFit" aria-label="Fit all planets">⤢</button></div></div>
      <div class="caption"><p class="scale-note" id="ssNote"></p></div>
      <div class="transport"><button class="btn btn-primary" id="ssPlay">Play</button><button class="btn" id="ssToday">Today</button>
        <label class="playback"><span class="pb-text">Speed</span><select id="ssSpeed"><option value="1">1 day/s</option><option value="10" selected>10 days/s</option><option value="100">100 days/s</option><option value="365.25">1 year/s</option><option value="3652.5">10 years/s</option></select></label></div>
      <dl class="readouts"><div class="ro"><dt>Selected</dt><dd id="ssRo1">—</dd></div><div class="ro"><dt>From the Sun</dt><dd id="ssRo2">—</dd></div><div class="ro"><dt>From Earth</dt><dd id="ssRo3">—</dd></div><div class="ro"><dt>Orbital speed</dt><dd id="ssRo4">—</dd></div></dl>
      <div class="story"><h2>What you're seeing</h2><p id="ssStory"></p></div>`,
    tabs: [
      { id: 'planet', label: 'Planet', html: `<div class="row" id="ssPick">${WORLDS.map(w => `<button class="btn btn-small" data-id="${w.id}">${w.name}</button>`).join('')}</div><div id="ssInfo" style="margin-top:14px"></div>` },
      { id: 'compare', label: 'Compare', html: `<div class="row"><label class="loc-custom" style="margin:0">First<select id="ssA">${WORLDS.map(w => `<option value="${w.id}" ${w.id === 'earth' ? 'selected' : ''}>${w.name}</option>`).join('')}</select></label><label class="loc-custom" style="margin:0">Second<select id="ssB">${WORLDS.map(w => `<option value="${w.id}" ${w.id === 'jupiter' ? 'selected' : ''}>${w.name}</option>`).join('')}</select></label></div>
        <div class="cmp-art"><canvas id="ssCmpCv" role="img" aria-label="The two planets drawn to the same scale"></canvas></div><table class="cmp-table" id="ssCmp"></table>` },
      { id: 'view', label: 'View', html: `<fieldset><legend>Distances</legend><div class="seg"><label><input type="radio" name="ssScale" value="sqrt" checked><span>Compressed</span></label><label><input type="radio" name="ssScale" value="true"><span>True distances</span></label></div><p class="hint">Compressed uses the square root of distance so Neptune and Mercury fit on one screen. True distances leave the inner planets crowded near the Sun: zoom in to find them.</p></fieldset>
        <div class="toggles"><label><input type="checkbox" id="ssTrue"> Draw planets at true size</label><label><input type="checkbox" id="ssOrb" checked> Show orbits</label><label><input type="checkbox" id="ssLab" checked> Show labels</label></div>
        <div class="field" style="margin-top:12px"><div class="field-head"><label for="ssTilt">Viewing angle</label><output id="ssTiltOut"></output></div><input type="range" id="ssTilt" min="0" max="88" step="1"><p class="hint">0° looks straight down on the plane of the planets. Near 90° you see it edge-on, and the orbits' small tilts show up.</p></div>
        <div class="field"><div class="field-head"><label for="ssRot">Turn</label><output id="ssRotOut"></output></div><input type="range" id="ssRot" min="0" max="359" step="1"><p class="hint">With a mouse you can also drag the view.</p></div>` },
      { id: 'model', label: 'Model', prose: true, html: `<h3>Model check</h3><ul class="checks" id="ssChecks"></ul>
        <h3>How positions are calculated</h3><p>Each planet's orbit comes from the JPL "Approximate Positions of the Planets" elements (Standish), valid from 1800 to 2050. The page solves Kepler's equation for the planet's place in its orbit on the chosen date. Earth stands in for the Earth–Moon barycentre.</p>
        <h3>What it leaves out</h3><ul><li>Light travel time: you see Neptune where it was about four hours earlier.</li><li>Moons, dwarf planets, asteroids and comets.</li><li>Small gravitational tugs between planets beyond what the averaged elements include.</li></ul>
        <h3>Sources</h3><ul><li>E. M. Standish, JPL Solar System Dynamics, "Approximate Positions of the Planets".</li><li>NASA NSSDCA Planetary Fact Sheet for sizes, gravity, day and year lengths.</li></ul>` },
    ],
  });
  const KMS = PHYS.KMS_PER_AUYR, MU = PHYS.MU_SUN, AU_KM = 149597870.7;
  function map(v) { if (S.scale === 'true') return v; const r = Math.hypot(v[0], v[1], v[2]) || 1, f = Math.sqrt(r) / r; return [v[0] * f, v[1] * f, v[2] * f]; }
  function proj(v, W, H, k) {
    const [x, y, z] = map(v), cr = Math.cos(S.rot * D2R), sr = Math.sin(S.rot * D2R), ct = Math.cos(S.tilt * D2R), st = Math.sin(S.tilt * D2R);
    const x1 = x * cr - y * sr, y1 = x * sr + y * cr;
    return [W / 2 + x1 * k, H / 2 - (y1 * ct + z * st) * k, -y1 * st + z * ct];
  }
  const fitR = () => S.scale === 'true' ? 31 : Math.sqrt(31);
  function draw() {
    const d = A.fromJd(S.j);
    $('#ssDate', root).textContent = d.toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' });
    canvasArt($('#ssCv', root), (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 71, 0.8);
      const k = (Math.min(W, H) / 2 * 0.94) / fitR() * S.zoom;
      // Sun
      const [sx, sy] = proj([0, 0, 0], W, H, k);
      const sunR = S.trueSize ? Math.max(0.6 * dpr, 695700 / AU_KM * k) : 8 * dpr;
      const g = ctx.createRadialGradient(sx, sy, 0, sx, sy, sunR * 3); g.addColorStop(0, 'rgba(255,220,120,.9)'); g.addColorStop(1, 'rgba(255,200,80,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(sx, sy, sunR * 3, 0, TAU); ctx.fill(); drawWorld(ctx, 'sun', sx, sy, sunR);
      if (S.orbits) NAMES.forEach(n => {
        const pts = A.orbitPoints(n, S.j, 200);
        ctx.strokeStyle = n === S.sel ? 'rgba(92,214,230,.75)' : 'rgba(150,170,205,.28)'; ctx.lineWidth = (n === S.sel ? 1.6 : 1) * dpr; ctx.beginPath();
        pts.forEach((p, i) => { const [X, Y] = proj(p, W, H, k); i ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y); }); ctx.stroke();
      });
      const bodies = NAMES.map(n => { const h = A.helio(n, S.j), [X, Y, Z] = proj([h.x, h.y, h.z], W, H, k); return { n, X, Y, Z, h }; }).sort((a, b) => a.Z - b.Z);
      S.hits = [];
      ctx.font = `700 ${11 * dpr}px ${FONT}`; ctx.textAlign = 'center';
      const place = labeler(ctx), labels = [];
      bodies.forEach(b => {
        const w = WORLDS.find(q => q.id === b.n);
        let r = S.trueSize ? Math.max(0.5 * dpr, w.d / 2 / AU_KM * k) : (2.2 + 2.1 * Math.log10(w.d / 2000)) * dpr;
        if (S.scale === 'sqrt' && S.trueSize) r = Math.max(0.5 * dpr, w.d / 2 / AU_KM * k / (2 * Math.sqrt(Math.hypot(b.h.x, b.h.y, b.h.z))));
        // vertical drop line to the ecliptic for depth cue when tilted
        if (S.tilt > 20) { const [X0, Y0] = proj([b.h.x, b.h.y, 0], W, H, k); ctx.strokeStyle = 'rgba(150,170,205,.25)'; ctx.lineWidth = dpr; ctx.beginPath(); ctx.moveTo(b.X, b.Y); ctx.lineTo(X0, Y0); ctx.stroke(); }
        drawWorld(ctx, b.n, b.X, b.Y, r, { noRings: r < 5 * dpr, shade: 0.45 });
        if (b.n === S.sel) { ctx.strokeStyle = '#5cd6e6'; ctx.lineWidth = 2 * dpr; ctx.beginPath(); ctx.arc(b.X, b.Y, Math.max(r, 4 * dpr) + 6 * dpr, 0, TAU); ctx.stroke(); }
        if (S.labels) { const tw = ctx.measureText(w.name).width; labels.push([b.n === S.sel, w.name, clamp(b.X, tw / 2 + 4 * dpr, W - tw / 2 - 4 * dpr), b.Y - Math.max(r, 4 * dpr) - 8 * dpr]); }
        S.hits.push([b.n, b.X / dpr, b.Y / dpr]);
      });
      ctx.fillStyle = 'rgba(230,236,248,.92)'; labels.sort((a, b) => b[0] - a[0]).forEach(([sel, t, x, y]) => place(t, x, y, sel));
      if (S.scale === 'true' && S.tilt < 30) { const k1 = k; ctx.fillStyle = 'rgba(205,216,235,.75)'; ctx.font = `${10 * dpr}px ${FONT}`; ctx.textAlign = 'left'; const L = Math.min(k1 * 5, W * 0.4); ctx.fillRect(12 * dpr, H - 14 * dpr, L, 2 * dpr); ctx.fillText(`${sig(L / k1, 2)} AU`, 12 * dpr, H - 20 * dpr); }
    });
    readouts();
  }
  function readouts() {
    const w = WORLDS.find(q => q.id === S.sel), h = A.helio(S.sel, S.j), r = Math.hypot(h.x, h.y, h.z), el = A.elements(S.sel, S.j);
    const v = Math.sqrt(MU * (2 / r - 1 / el.a)) * KMS;
    $('#ssRo1', root).textContent = w.name; $('#ssRo2', root).textContent = `${r.toFixed(r < 2 ? 3 : 2)} AU`;
    if (S.sel === 'earth') $('#ssRo3', root).textContent = '—';
    else { const g = A.geo(S.sel, S.j); const lm = g.dist * 499.005 / 60; $('#ssRo3', root).textContent = `${g.dist.toFixed(2)} AU, light ${lm < 60 ? Math.round(lm) + ' min' : (lm / 60).toFixed(1) + ' h'}`; }
    $('#ssRo4', root).textContent = `${v.toFixed(1)} km/s`;
    const peri = el.a * (1 - el.e), apo = el.a * (1 + el.e), where = (r - peri) / (apo - peri);
    $('#ssStory', root).textContent = `${w.name} is ${r.toFixed(2)} AU from the Sun, ${where < 0.2 ? 'near its closest point (perihelion), so it is moving at close to its top speed' : where > 0.8 ? 'near its farthest point (aphelion), so it is moving at close to its slowest' : 'between its closest and farthest points'}. Its orbit ranges from ${peri.toFixed(2)} to ${apo.toFixed(2)} AU. ${S.playing ? 'Inner planets lap the outer ones: that is Kepler\'s third law at work.' : 'Press Play to run time forward.'}`;
    $('#ssNote', root).textContent = (S.scale === 'true' ? 'Distances to scale. ' : 'Distances compressed (square-root scale). ') + (S.trueSize ? 'Planets at true size relative to the distances; most shrink below a pixel, which is the point.' : 'Planets drawn far larger than true size so you can see them.');
  }
  function info() {
    const w = WORLDS.find(q => q.id === S.sel), el = A.elements(S.sel, S.j), T = Math.pow(el.a, 1.5);
    $$('#ssPick .btn', root).forEach(b => b.classList.toggle('on', b.dataset.id === S.sel));
    $('#ssInfo', root).innerHTML = `<h2 style="margin:0 0 4px;font-size:1.25rem">${w.name}</h2><p class="muted" style="margin:0 0 8px">${w.kind}</p><p style="margin:0 0 12px">${esc(w.blurb)}</p>
      <dl class="kv"><dt>Diameter</dt><dd>${num(w.d)} km</dd><dt>Surface gravity</dt><dd>${w.g.toFixed(1)} m/s²</dd><dt>Day</dt><dd>${w.day > 48 ? num(w.day / 24, 1) + ' Earth days' : num(w.day, 1) + ' hours'}</dd><dt>Year</dt><dd>${w.year > 1000 ? num(w.year / 365.25, 1) + ' Earth years' : num(w.year, 1) + ' days'}</dd><dt>Mean temperature</dt><dd>${w.temp} °C</dd>
      <dt>Orbit size (semi-major axis)</dt><dd>${el.a.toFixed(3)} AU</dd><dt>Orbit shape (eccentricity)</dt><dd>${el.e.toFixed(4)}</dd><dt>Orbit tilt to Earth's</dt><dd>${el.I.toFixed(2)}°</dd><dt>Period from Kepler's third law</dt><dd>${T < 2 ? num(T * 365.25, 1) + ' days' : T.toFixed(2) + ' years'}</dd></dl>`;
  }
  function compare() {
    const a = WORLDS.find(q => q.id === $('#ssA', root).value), b = WORLDS.find(q => q.id === $('#ssB', root).value);
    const rows = [['Diameter', 'd', v => num(v) + ' km'], ['Gravity', 'g', v => v.toFixed(1) + ' m/s²'], ['Day', 'day', v => v > 48 ? num(v / 24, 1) + ' d' : num(v, 1) + ' h'], ['Year', 'year', v => v > 1000 ? num(v / 365.25, 1) + ' yr' : num(v, 1) + ' d'], ['Distance from Sun', 'dist', v => num(v, 1) + ' M km'], ['Mean temperature', 'temp', v => v + ' °C']];
    $('#ssCmp', root).innerHTML = `<thead><tr><th></th><th>${a.name}</th><th>${b.name}</th><th>Ratio</th></tr></thead><tbody>${rows.map(([l, k, f]) => `<tr><th>${l}</th><td>${f(a[k])}</td><td>${f(b[k])}</td><td>${k === 'temp' ? '—' : (b[k] / a[k]).toPrecision(3) + '×'}</td></tr>`).join('')}</tbody>`;
    canvasArt($('#ssCmpCv', root), (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 4, 0.4);
      const big = Math.max(a.d, b.d), k = Math.min(W * 0.4, H * 0.8) / big;
      const ra = a.d * k / 2, rb = b.d * k / 2;
      drawWorld(ctx, a.id, W * 0.28, H / 2, Math.max(ra, 1.5 * dpr), { noRings: a.id === 'saturn' && ra < 8 }); drawWorld(ctx, b.id, W * 0.72, H / 2, Math.max(rb, 1.5 * dpr), { noRings: b.id === 'saturn' && rb < 8 });
      ctx.fillStyle = 'rgba(230,236,248,.9)'; ctx.font = `700 ${11 * dpr}px ${FONT}`; ctx.textAlign = 'center'; ctx.fillText(a.name, W * 0.28, H - 8 * dpr); ctx.fillText(b.name, W * 0.72, H - 8 * dpr);
    });
  }
  function checks() {
    const j = A.jd(new Date());
    const rows = WORLDS.map(w => { const el = A.elements(w.id, j), T = Math.pow(el.a, 1.5) * 365.25, d = (T - w.year) / w.year; return [w.name, T, w.year, d]; });
    const worst = Math.max(...rows.map(r => Math.abs(r[3])));
    $('#ssChecks', root).innerHTML = checkRow("Kepler's third law against NASA's periods", worst < 0.003 ? 'ok' : 'warn', worst < 0.003 ? 'Holds' : 'Drifting',
      `Period from orbit size (T² = a³) compared with NASA's measured year: largest difference ${(worst * 100).toFixed(2)}% (${rows.find(r => Math.abs(r[3]) === worst)[0]}). Small gaps come from each planet's own mass, which the simple law ignores, and from rounding in the published values.`)
      + checkRow('Positions against known oppositions', 'ok', 'Holds', 'In automated tests, Mars, Jupiter and Saturn reached opposition within a day of the published dates (2025 to 2027).');
  }
  // controls
  $('#ssPick', root).addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; S.sel = b.dataset.id; info(); draw(); });
  $('#ssCv', root).addEventListener('click', e => { if (dragMoved) return; const r = e.target.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; let best = null; S.hits.forEach(([n, X, Y]) => { const d = Math.hypot(X - x, Y - y); if (d < 28 && (!best || d < best[1])) best = [n, d]; }); if (best) { S.sel = best[0]; info(); draw(); } });
  let drag = null, dragMoved = false;
  const cv = $('#ssCv', root);
  cv.addEventListener('pointerdown', e => { dragMoved = false; if (e.pointerType !== 'mouse') return; drag = { x: e.clientX, y: e.clientY, rot: S.rot, tilt: S.tilt }; cv.setPointerCapture(e.pointerId); });
  cv.addEventListener('pointermove', e => { if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.abs(dx) + Math.abs(dy) > 3) dragMoved = true; S.rot = ((drag.rot - dx * 0.4) % 360 + 360) % 360; S.tilt = clamp(drag.tilt + dy * 0.3, 0, 88); syncView(); draw(); });
  cv.addEventListener('pointerup', () => { drag = null; });
  $('#ssIn', root).addEventListener('click', () => { S.zoom = Math.min(S.zoom * 1.6, 200); draw(); });
  $('#ssOut', root).addEventListener('click', () => { S.zoom = Math.max(S.zoom / 1.6, 0.5); draw(); });
  $('#ssFit', root).addEventListener('click', () => { S.zoom = 1; draw(); });
  $('#ssPlay', root).addEventListener('click', () => { S.playing = !S.playing; $('#ssPlay', root).textContent = S.playing ? 'Pause' : 'Play'; readouts(); });
  $('#ssToday', root).addEventListener('click', () => { S.j = A.jd(new Date()); draw(); });
  $('#ssSpeed', root).addEventListener('change', e => { S.speed = Number(e.target.value); });
  $$('input[name="ssScale"]', root).forEach(i => i.addEventListener('change', () => { S.scale = i.value; S.zoom = 1; draw(); }));
  $('#ssTrue', root).addEventListener('change', e => { S.trueSize = e.target.checked; draw(); });
  $('#ssOrb', root).addEventListener('change', e => { S.orbits = e.target.checked; draw(); });
  $('#ssLab', root).addEventListener('change', e => { S.labels = e.target.checked; draw(); });
  function syncView() { $('#ssTilt', root).value = S.tilt; $('#ssRot', root).value = Math.round(S.rot); $('#ssTiltOut', root).textContent = `${Math.round(S.tilt)}°`; $('#ssRotOut', root).textContent = `${Math.round(S.rot)}°`; }
  $('#ssTilt', root).addEventListener('input', e => { S.tilt = Number(e.target.value); syncView(); draw(); });
  $('#ssRot', root).addEventListener('input', e => { S.rot = Number(e.target.value); syncView(); draw(); });
  ['#ssA', '#ssB'].forEach(s => $(s, root).addEventListener('change', compare));
  loop(dt => { if (S.playing) { S.j += dt * S.speed; if (S.j > 2469807.5) { S.j = 2469807.5; S.playing = false; $('#ssPlay', root).textContent = 'Play'; $('#ssStory', root).textContent = 'Stopped at 1 January 2050, the end of the range these orbital elements are valid for.'; return; } draw(); } });
  syncView(); info(); compare(); checks(); draw(); watch($('#ssView', root), draw);
  watch($('#ssCmpCv', root), compare);
}

/* =====================================================================
   LAB C — Cosmic scale explorer
   ===================================================================== */
function scaleLab(root) {
  const LY = 9.4607304725808e15, AU = 1.495978707e11;
  const STOPS = [
    { id: 'earth', name: 'Earth', w: 7.45, kind: 'scale', text: 'Earth is 12,742 km across. Everything you have ever done happened on this sphere.' },
    { id: 'moon', name: 'Earth and Moon', w: 9.0, kind: 'scale', text: 'The Moon orbits 384,400 km away, about 30 Earths. Its position here is today\'s, from the ephemeris.' },
    { id: 'sun', name: 'The Sun', w: 9.75, kind: 'scale', text: 'The Sun is 1.39 million km wide, 109 Earths. Earth is 150 million km away, well off this view.' },
    { id: 'inner', name: 'Inner planets', w: 11.65, kind: 'scale', text: 'Mercury, Venus, Earth and Mars, at today\'s positions. Light takes about 8 minutes to reach us from the Sun.' },
    { id: 'outer', name: 'All the planets', w: 13.15, kind: 'scale', text: 'Neptune orbits 30 times farther out than Earth. Sunlight takes about four hours to reach it.' },
    { id: 'oort', name: 'Oort cloud', w: 16.6, kind: 'schematic', text: 'A vast shell of icy bodies thought to surround the Solar System, from roughly 2,000 to 100,000 AU. It has never been seen directly; its size is inferred from the orbits of long-period comets.' },
    { id: 'stars', name: 'Nearest stars', w: 17.55, kind: 'scale', text: 'The nearest stars, a few light-years apart. Positions are real but approximate, projected onto a flat map seen from above Earth\'s north pole.' },
    { id: 'galaxy', name: 'Milky Way', w: 21.25, kind: 'schematic', text: 'Our galaxy: a barred spiral about 100,000 light-years across, with the Sun about 26,700 light-years from the centre. We cannot photograph it from outside; this shape is a schematic based on surveys.' },
    { id: 'group', name: 'Local Group', w: 23.0, kind: 'schematic', text: 'The Milky Way, Andromeda (2.5 million light-years away), Triangulum and dozens of small galaxies. Distances are real; directions are schematic.' },
    { id: 'web', name: 'Cosmic web', w: 25.2, kind: 'schematic', text: 'On the largest scales, galaxies gather into filaments and walls around huge voids. Our home supercluster, Laniakea, spans about 520 million light-years. The pattern drawn here is illustrative.' },
    { id: 'universe', name: 'Observable universe', w: 27.0, kind: 'scale', text: 'Light from the edge has travelled 13.8 billion years, but space has stretched meanwhile: that edge is now about 46.5 billion light-years away. The faint glow at the boundary is the cosmic microwave background.' },
  ];
  const S = { lw: 7.45, anim: null };
  shell(root, {
    title: 'Cosmic scale explorer',
    intro: 'Zoom from Earth to the edge of the observable universe, a factor of about 10<sup>20</sup>. Each step of the slider is a power of ten. The badge on the view tells you whether what you see is <b>to scale</b> or <b>schematic</b>.',
    stage: `<div class="viewport" id="csView"><canvas id="csCv" role="img" aria-label="Zoomable view of cosmic scales"></canvas>
        <div class="hud hud-tl"><span class="chip" id="csKind"></span></div><div class="hud hud-tr"><span class="chip chip-time" id="csWidth"></span></div></div>
      <div class="field" style="margin-top:12px"><div class="field-head"><label for="csZoom">View width</label><output id="csZoomOut"></output></div><input type="range" id="csZoom" min="7" max="27.2" step="0.01"><p class="hint" id="csLight"></p></div>
      <div class="row" id="csStops">${STOPS.map(s => `<button class="btn btn-small" data-id="${s.id}">${s.name}</button>`).join('')}</div>
      <div class="story"><h2 id="csTitle"></h2><p id="csText"></p></div>`,
    tabs: [
      { id: 'tour', label: 'Tour', html: `<ol class="tour" id="csTour">${STOPS.map((s, i) => `<li><button class="tour-btn" data-id="${s.id}"><b>${i + 1}. ${s.name}</b><span>${s.kind === 'scale' ? 'To scale' : 'Schematic'}</span></button></li>`).join('')}</ol><p class="hint">The tour is a sequence, so it is numbered. Each stop zooms by a factor of 10 to 1,000 over the last.</p>` },
      { id: 'model', label: 'Model', prose: true, html: `<h3>What is data and what is drawn</h3><ul><li><b>To scale, from data:</b> Earth, the Moon and planets at today's positions (JPL elements and the Astronomical Almanac); the nearest stars from catalogue positions; the size of the observable universe.</li><li><b>Real distances, schematic layout:</b> the Local Group's galaxies sit at their measured distances, but in simplified directions.</li><li><b>Schematic:</b> the Oort cloud, the Milky Way's shape and the cosmic web. These are drawn to convey structure, not to map it.</li></ul>
        <h3>Why the universe is wider than its age</h3><p>The universe is 13.8 billion years old, yet the edge of what we can see is about 46.5 billion light-years away. Space kept expanding while the light travelled, so the places it left are now much farther away.</p>
        <h3>Sources</h3><ul><li>Planck Collaboration (2020), cosmological parameters: age 13.8 billion years.</li><li>GRAVITY Collaboration (2019): 8.178 kpc to the Galactic Centre.</li><li>Tully et al. (2014), Nature 513, 71: the Laniakea supercluster.</li><li>Gaia DR3 and Hipparcos parallaxes for nearby stars.</li></ul>` },
    ],
  });
  const R = rng(5);
  const NEAR = [['α Centauri', 219.9, -60.8, 4.37], ['Barnard\'s Star', 269.45, 4.69, 5.96], ['Wolf 359', 164.12, 7.01, 7.86], ['Lalande 21185', 165.83, 35.97, 8.31], ['Sirius', 101.29, -16.72, 8.6], ['Luyten 726-8', 24.75, -17.95, 8.79], ['Ross 154', 282.46, -23.84, 9.7], ['Ross 248', 355.48, 44.17, 10.3], ['ε Eridani', 53.23, -9.46, 10.5], ['Lacaille 9352', 346.47, -35.85, 10.7], ['Ross 128', 176.94, 0.8, 11.0], ['Procyon', 114.83, 5.22, 11.46], ['61 Cygni', 316.7, 38.75, 11.4], ['ε Indi', 330.84, -56.79, 11.9], ['τ Ceti', 26.02, -15.94, 11.9]]
    .map(([n, ra, dec, d]) => [n, d * LY * Math.cos(dec * D2R) * Math.cos(ra * D2R), d * LY * Math.cos(dec * D2R) * Math.sin(ra * D2R)]);
  const GC = [-26700 * LY, 0];
  const arms = []; for (let a = 0; a < 4; a++) for (let i = 0; i < 520; i++) { const t = i / 520 * 2.6 * Math.PI, rr = (4000 + 46000 * i / 520) * LY, sp = (R() - 0.5) * 5000 * LY; const ang = t + a * Math.PI / 2; arms.push([GC[0] + Math.cos(ang) * (rr + sp), GC[1] + Math.sin(ang) * (rr + sp), R()]); }
  const web = []; for (let i = 0; i < 260; i++) web.push([(R() - 0.5) * 3e25, (R() - 0.5) * 3e25]);
  const LG = [['Milky Way', -26700 * 9.4607304725808e15, 0, 1], ['Andromeda', 2.5e6 * LY * 0.82, 2.5e6 * LY * 0.57, 1.3], ['Triangulum', 2.73e6 * LY * 0.7, 2.73e6 * LY * 0.71, 0.5], ['Large Magellanic Cloud', -160000 * LY * 0.6, -160000 * LY * 0.8, 0.25], ['Small Magellanic Cloud', -200000 * LY * 0.3, -200000 * LY * 0.95, 0.18]];
  function center(lw) { // where the view is centred, eased between anchors (metres, heliocentric)
    const j = A.jd(new Date()), e = A.helio('earth', j), E = [e.x * AU, e.y * AU];
    if (lw < 9.4) return E; // the Earth–Sun gap is too wide to pan smoothly at these scales: the view recentres on the Sun
    const anchors = [[9.4, [0, 0]], [19.6, [0, 0]], [20.8, GC], [22.3, GC], [23.0, [0.5 * 2.365e22 * 0.82, 0.5 * 2.365e22 * 0.57]], [24.5, [0, 0]]];
    for (let i = 1; i < anchors.length; i++) if (lw <= anchors[i][0]) { const [l0, p0] = anchors[i - 1], [l1, p1] = anchors[i], f = (lw - l0) / (l1 - l0), s = f * f * (3 - 2 * f); return [p0[0] + (p1[0] - p0[0]) * s, p0[1] + (p1[1] - p0[1]) * s]; }
    return [0, 0];
  }
  const fmtLen = m => m < 1e9 ? `${sig(m / 1000, 3)} km` : m < 0.05 * LY ? (m < 1e11 ? `${sig(m / 1e9, 3)} million km` : `${sig(m / AU, 3)} AU`) : m < 1e6 * LY ? `${sig(m / LY, 3)} light-years` : m < 1e9 * LY ? `${sig(m / LY / 1e6, 3)} million light-years` : `${sig(m / LY / 1e9, 3)} billion light-years`;
  const fmtLight = m => { const s = m / 299792458; return s < 60 ? `${sig(s, 2)} seconds` : s < 3600 ? `${sig(s / 60, 2)} minutes` : s < 86400 * 2 ? `${sig(s / 3600, 2)} hours` : s < 3.15576e7 * 2 ? `${sig(s / 86400, 2)} days` : `${sig(s / 3.15576e7, 3)} years`; };
  function draw() {
    const lw = S.lw, w = Math.pow(10, lw), j = A.jd(new Date());
    const stop = STOPS.reduce((b, s) => Math.abs(s.w - lw) < Math.abs(b.w - lw) ? s : b, STOPS[0]);
    $('#csZoomOut', root).textContent = `10^${lw.toFixed(1)} m`; $('#csZoom', root).value = lw;
    $('#csWidth', root).textContent = fmtLen(w);
    $('#csLight', root).textContent = `Light takes ${fmtLight(w)} to cross this view.`;
    $('#csKind', root).textContent = stop.kind === 'scale' ? 'To scale' : 'Schematic'; $('#csKind', root).dataset.k = stop.kind;
    $('#csTitle', root).textContent = stop.name; $('#csText', root).textContent = stop.text;
    $$('#csStops .btn', root).forEach(b => b.classList.toggle('on', b.dataset.id === stop.id));
    canvasArt($('#csCv', root), (ctx, W, H, dpr) => {
      spaceBg(ctx, W, H, 2, 0.6);
      const p = Math.min(W, H) / w, [cx0, cy0] = center(lw);
      const X = x => W / 2 + (x - cx0) * p, Y = y => H / 2 - (y - cy0) * p;
      const fade = (lo, hi) => clamp(Math.min((lw - lo) / 0.6, (hi - lw) / 0.6), 0, 1); // visible between log widths lo..hi
      const place = labeler(ctx);
      const label = (t, x, y, a = 1, c = 'rgba(230,236,248,') => { ctx.fillStyle = c + (0.9 * a) + ')'; ctx.font = `700 ${11 * dpr}px ${FONT}`; ctx.textAlign = 'center'; const tw = ctx.measureText(t).width; place(t, clamp(x, tw / 2 + 6 * dpr, W - tw / 2 - 6 * dpr), clamp(y, 54 * dpr, H - 8 * dpr)); };
      const e = A.helio('earth', j), E = [e.x * AU, e.y * AU];
      // Earth + Moon
      let a = fade(6.5, 12.5);
      if (a > 0) {
        ctx.globalAlpha = a; const er = 6.371e6 * p; drawWorld(ctx, 'earth', X(E[0]), Y(E[1]), Math.max(er, 1.2 * dpr)); ctx.globalAlpha = 1;
        const m = A.moon(j), md = m.distKm * 1000, mx = E[0] + md * Math.cos(m.lon * D2R), my = E[1] + md * Math.sin(m.lon * D2R);
        ctx.strokeStyle = `rgba(150,170,205,${0.4 * a})`; ctx.lineWidth = dpr; ctx.beginPath(); ctx.arc(X(E[0]), Y(E[1]), 3.844e8 * p, 0, TAU); ctx.stroke();
        drawWorld(ctx, 'moon', X(mx), Y(my), Math.max(1.737e6 * p, 1 * dpr)); if (lw > 8.4 && lw < 10.5) label('Moon', X(mx), Y(my) - Math.max(1.737e6 * p, 4 * dpr) - 8 * dpr, a);
        if (lw > 8.4 && lw < 11.5) label('Earth', X(E[0]), Y(E[1]) - Math.max(er, 4 * dpr) - 8 * dpr, a);
      }
      // Sun and planets
      a = fade(9.0, 17.0);
      if (a > 0) {
        const sr = Math.max(6.957e8 * p, 2.5 * dpr); ctx.globalAlpha = a; drawWorld(ctx, 'sun', X(0), Y(0), sr); ctx.globalAlpha = 1;
        if (lw > 9.3 && lw < 13.8) label('Sun', X(0), Y(0) + sr + 16 * dpr, a);
        WORLDS.forEach(wd => {
          if (wd.id === 'earth') return;
          const h = A.helio(wd.id, j), x = h.x * AU, y = h.y * AU, orbitR = A.elements(wd.id, j).a * AU;
          ctx.strokeStyle = `rgba(150,170,205,${0.3 * a})`; ctx.beginPath(); ctx.arc(X(0), Y(0), orbitR * p, 0, TAU); ctx.stroke();
          const pr = Math.max(wd.d * 500 * p, 1.6 * dpr); drawWorld(ctx, wd.id, X(x), Y(y), pr, { noRings: pr < 5 * dpr });
          const show = (['mercury', 'venus', 'mars'].includes(wd.id) && lw > 11 && lw < 12.6) || (!['mercury', 'venus', 'mars'].includes(wd.id) && lw > 12.4 && lw < 14);
          if (show) label(wd.name, X(x), Y(y) - pr - 8 * dpr, a);
        });
        ctx.strokeStyle = `rgba(150,170,205,${0.3 * a})`; ctx.beginPath(); ctx.arc(X(0), Y(0), AU * p, 0, TAU); ctx.stroke();
      }
      // Oort cloud (schematic)
      a = fade(14.5, 18.2);
      if (a > 0) { for (let i = 0; i < 900; i++) { const r = (2000 + 98000 * Math.pow(((i * 7919) % 1000) / 1000, 0.7)) * AU, t = i * 2.39996; ctx.fillStyle = `rgba(160,200,255,${0.35 * a})`; ctx.fillRect(X(r * Math.cos(t)), Y(r * Math.sin(t)), 1.2 * dpr, 1.2 * dpr); } if (lw > 15.6 && lw < 17.3) label('Oort cloud (schematic)', X(0), Y(60000 * AU), a); if (lw > 15 && lw < 17.2) label('The Sun and planets', X(0), Y(0) + 16 * dpr, a); }
      // nearest stars
      a = fade(16.4, 19.6);
      if (a > 0) { ctx.fillStyle = `rgba(255,242,214,${a})`; ctx.beginPath(); ctx.arc(X(0), Y(0), 3 * dpr, 0, TAU); ctx.fill(); if (lw > 17) label('Sun', X(0), Y(0) - 10 * dpr, a); NEAR.forEach(([n, x, y]) => { ctx.fillStyle = `rgba(235,240,255,${a})`; ctx.beginPath(); ctx.arc(X(x), Y(y), 2.4 * dpr, 0, TAU); ctx.fill(); if (lw > 17 && lw < 18.3) { ctx.fillStyle = `rgba(205,216,235,${0.85 * a})`; ctx.font = `${10 * dpr}px ${FONT}`; ctx.textAlign = 'center'; place(n, X(x), Y(y) - 7 * dpr); } }); ctx.strokeStyle = `rgba(150,170,205,${0.3 * a})`; [5, 10].forEach(d => { ctx.beginPath(); ctx.arc(X(0), Y(0), d * LY * p, 0, TAU); ctx.stroke(); }); if (lw > 17 && lw < 18.4) { ctx.fillStyle = `rgba(205,216,235,${0.7 * a})`; ctx.font = `${10 * dpr}px ${FONT}`; ctx.fillText('5 ly', X(0) + 5 * LY * p * 0.72, Y(0) - 5 * LY * p * 0.72); ctx.fillText('10 ly', X(0) + 10 * LY * p * 0.72, Y(0) - 10 * LY * p * 0.72); } }
      // Milky Way (schematic)
      a = fade(19.6, 23.6);
      if (a > 0) {
        const g = ctx.createRadialGradient(X(GC[0]), Y(GC[1]), 0, X(GC[0]), Y(GC[1]), 50000 * LY * p); g.addColorStop(0, `rgba(255,230,190,${0.55 * a})`); g.addColorStop(0.25, `rgba(200,190,230,${0.18 * a})`); g.addColorStop(1, 'rgba(120,140,220,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(X(GC[0]), Y(GC[1]), 50000 * LY * p, 0, TAU); ctx.fill();
        arms.forEach(([x, y, b]) => { ctx.fillStyle = `rgba(${b > 0.7 ? '170,200,255' : '230,225,255'},${(0.25 + 0.5 * b) * a})`; ctx.fillRect(X(x), Y(y), 1.4 * dpr, 1.4 * dpr); });
        if (lw < 22.4) { ctx.strokeStyle = `rgba(92,214,230,${a})`; ctx.lineWidth = 1.5 * dpr; ctx.beginPath(); ctx.arc(X(0), Y(0), 5 * dpr, 0, TAU); ctx.stroke(); label('You are here', X(0), Y(0) - 12 * dpr, a, 'rgba(92,214,230,'); }
      }
      // Local Group
      a = fade(21.8, 25.0);
      if (a > 0) LG.forEach(([n, x, y, s]) => { if (n === 'Milky Way' && lw < 22.3) return; const r = Math.max(s * 50000 * LY * p, (3 + 3 * s) * dpr); const g = ctx.createRadialGradient(X(x), Y(y), 0, X(x), Y(y), r); g.addColorStop(0, `rgba(255,236,210,${0.9 * a})`); g.addColorStop(1, 'rgba(160,170,240,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(X(x), Y(y), r, r * 0.5, 0.5, 0, TAU); ctx.fill(); if (lw > 22.4 && lw < 23.8 && (s > 0.3 || lw < 23)) label(n, X(x), Y(y) - r * 0.5 - 8 * dpr, a); });
      // cosmic web (illustrative)
      a = fade(23.8, 27.6);
      if (a > 0) {
        ctx.strokeStyle = `rgba(160,170,255,${0.22 * a})`; ctx.lineWidth = 1.2 * dpr;
        web.forEach(([x, y], i) => { const n2 = web[(i * 7 + 3) % web.length], n3 = web[(i * 13 + 5) % web.length]; [n2, n3].forEach(q => { if (Math.hypot(q[0] - x, q[1] - y) < 4e24) { ctx.beginPath(); ctx.moveTo(X(x), Y(y)); ctx.lineTo(X(q[0]), Y(q[1])); ctx.stroke(); } }); ctx.fillStyle = `rgba(255,236,210,${0.6 * a})`; ctx.fillRect(X(x), Y(y), 1.6 * dpr, 1.6 * dpr); });
        if (lw < 26) { ctx.strokeStyle = `rgba(92,214,230,${0.8 * a})`; ctx.setLineDash([4 * dpr, 4 * dpr]); ctx.beginPath(); ctx.arc(X(0), Y(0), 2.6e8 * LY * p, 0, TAU); ctx.stroke(); ctx.setLineDash([]); label('Laniakea supercluster', X(0), Y(0) - 2.6e8 * LY * p - 10 * dpr, a, 'rgba(92,214,230,'); }
      }
      // observable universe
      a = fade(25.6, 28);
      if (a > 0) { const r = 46.5e9 * LY * p; const g = ctx.createRadialGradient(X(0), Y(0), r * 0.92, X(0), Y(0), r * 1.03); g.addColorStop(0, 'rgba(255,140,90,0)'); g.addColorStop(0.7, `rgba(255,150,100,${0.45 * a})`); g.addColorStop(1, 'rgba(255,150,100,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(X(0), Y(0), r * 1.03, 0, TAU); ctx.fill(); label('Cosmic microwave background', X(0), Y(0) + r + 18 * dpr, a); label('Us', X(0), Y(0) - 8 * dpr, a); ctx.fillStyle = `rgba(92,214,230,${a})`; ctx.beginPath(); ctx.arc(X(0), Y(0), 3 * dpr, 0, TAU); ctx.fill(); }
    });
  }
  function goTo(lw) {
    if (reduceMotion) { S.lw = lw; draw(); return; }
    S.anim = { from: S.lw, to: lw, t: 0, dur: Math.min(2.2, 0.5 + Math.abs(lw - S.lw) * 0.12) };
  }
  $('#csZoom', root).addEventListener('input', e => { S.anim = null; S.lw = Number(e.target.value); draw(); });
  [$('#csStops', root), $('#csTour', root)].forEach(el => el.addEventListener('click', e => { const b = e.target.closest('button[data-id]'); if (b) goTo(STOPS.find(s => s.id === b.dataset.id).w); }));
  loop(dt => { if (!S.anim) return; S.anim.t += dt; const f = Math.min(1, S.anim.t / S.anim.dur), s = f < 0.5 ? 2 * f * f : 1 - Math.pow(-2 * f + 2, 2) / 2; S.lw = S.anim.from + (S.anim.to - S.anim.from) * s; draw(); if (f >= 1) S.anim = null; });
  draw(); watch($('#csView', root), draw);
}

/* =====================================================================
   LAB E — Stellar spectroscopy
   ===================================================================== */
function spectraLab(root) {
  const Sp = SPEC;
  const S = { T: 5772, v: 0, mode: 'abs', gas: 'H', compare: true, fraun: false, focus: 'all' };
  const PRESETS = [['Red dwarf', 3000], ['Betelgeuse', 3600], ['The Sun', 5772], ['Sirius A', 9940], ['Rigel', 12100], ['Hot O star', 40000]];
  const EXPS = [
    { id: 'hotter', title: 'Double the temperature', law: "Wien's law", setup: 'Start with the Sun at 5,772 K. Next, the star doubles in temperature.', q: 'What happens to the wavelength where it shines brightest?', options: ['It halves', 'It doubles', 'It stays the same'], answer: 0, explain: 'The peak wavelength is inversely proportional to temperature: λ_peak = 2.898 mm·K ÷ T. Twice as hot moves the peak to half the wavelength, from green-blue into the ultraviolet, and the star turns bluish-white.', before: { T: 5772, v: 0, mode: 'abs' }, after: { T: 11544 } },
    { id: 'away', title: 'A galaxy moving away', law: 'Doppler shift', setup: 'A Sun-like spectrum at rest. Next, the source moves away from us at 15,000 km/s, like a distant galaxy carried by cosmic expansion.', q: 'Where do the dark lines go?', options: ['Toward the red end', 'Toward the blue end', 'Nowhere'], answer: 0, explain: 'Motion away stretches every wavelength by the same factor. At 15,000 km/s, hydrogen-alpha moves from 656.3 to about 690 nm. The pattern of lines stays the same, which is how astronomers recognise it.', before: { T: 5772, v: 0, mode: 'abs' }, after: { v: 15000 } },
    { id: 'hydrogen', title: 'Where hydrogen lines are strongest', law: 'The spectral sequence', setup: 'All stars are mostly hydrogen. Compare a cool red dwarf, a 9,500 K star and a 30,000 K star.', q: 'Which shows the strongest hydrogen absorption lines?', options: ['The cool red dwarf, 3,500 K', 'The 9,500 K star', 'The hottest star, 30,000 K'], answer: 1, explain: 'Visible hydrogen lines need atoms whose electron sits in the second energy level. Cool stars have too few of those; very hot stars ionise most of their hydrogen. Around 9,500 K, type A, the balance is just right. Cecilia Payne showed in 1925 that line strength tracks temperature, not how much hydrogen a star has.', before: { T: 3500, v: 0, mode: 'abs' }, after: { T: 9500 } },
  ];
  const ui = shell(root, {
    title: 'Stellar spectroscopy',
    intro: 'A star\'s light, spread into a rainbow, records its temperature, what it is made of and how it moves. The smooth curve is exact physics; the strength of the dark lines is a <b>simplified teaching model</b>, labelled as such.',
    stage: `<div class="spec-top"><div class="spec-star"><canvas id="spStar" aria-hidden="true"></canvas></div><dl class="readouts" style="margin:0;flex:1"><div class="ro"><dt>Temperature</dt><dd id="spRoT"></dd></div><div class="ro"><dt>Brightest at</dt><dd id="spRoP"></dd></div><div class="ro"><dt>Star type</dt><dd id="spRoC"></dd></div><div class="ro"><dt>Motion</dt><dd id="spRoV"></dd></div></dl></div>
      <div class="chart-card"><h2>Brightness across wavelengths</h2><div class="chart-box" style="height:220px"><canvas id="spCurve" role="img" aria-label="Blackbody spectrum"></canvas></div><p class="chart-note" id="spCurveNote"></p></div>
      <div class="chart-card"><h2 id="spStripTitle">Visible spectrum</h2><div class="chart-box" style="height:120px"><canvas id="spStrip" role="img" aria-label="Visible spectrum with lines"></canvas></div></div>
      <div class="story"><h2>What this spectrum tells you</h2><p id="spStory"></p></div>`,
    tabs: [
      { id: 'exp', label: 'Experiments', html: `<h2>Predict first, then run</h2><p class="intro">Each experiment sets up a spectrum, asks for your prediction, then changes one thing.</p><ol class="exps" id="spExps"></ol>` },
      { id: 'ctl', label: 'Controls', html: `<div class="field"><div class="field-head"><label for="spT">Surface temperature</label><output id="spTOut"></output></div><input type="range" id="spT" min="3.398" max="4.602" step="0.001"><div class="row" id="spPresets">${PRESETS.map(([n, t]) => `<button class="btn btn-small" data-t="${t}">${n}</button>`).join('')}</div><p class="hint">Preset temperatures are approximate published values; Betelgeuse varies.</p></div>
        <div class="field"><div class="field-head"><label for="spV">Speed along our line of sight</label><output id="spVOut"></output></div><input type="range" id="spV" min="-30000" max="150000" step="100"><p class="hint">Positive is moving away (redshift); negative is toward us (blueshift).</p><div class="row"><button class="btn btn-small" id="spV0">At rest</button></div></div>
        <fieldset><legend>Light source</legend><div class="seg"><label><input type="radio" name="spMode" value="abs" checked><span>Star: dark lines</span></label><label><input type="radio" name="spMode" value="emi"><span>Glowing gas: bright lines</span></label></div></fieldset>
        <fieldset id="spGasBox" hidden><legend>Gas</legend><div class="seg"><label><input type="radio" name="spGas" value="H" checked><span>Hydrogen</span></label><label><input type="radio" name="spGas" value="He"><span>Helium</span></label><label><input type="radio" name="spGas" value="Na"><span>Sodium</span></label></div></fieldset>
        <fieldset id="spFocusBox"><legend>Highlight lines from</legend><div class="seg"><label><input type="radio" name="spFocus" value="all" checked><span>All</span></label>${['H', 'He', 'Ca', 'Na', 'Mg', 'Fe'].map(e => `<label><input type="radio" name="spFocus" value="${e}"><span>${{ H: 'Hydrogen', He: 'Helium', Ca: 'Calcium', Na: 'Sodium', Mg: 'Magnesium', Fe: 'Iron' }[e]}</span></label>`).join('')}</div></fieldset>
        <div class="toggles"><label><input type="checkbox" id="spCmp" checked> Compare with the Sun's curve</label><label><input type="checkbox" id="spFr"> Show Fraunhofer's lines, observed in sunlight</label></div>` },
      { id: 'model', label: 'Model', prose: true, html: `<h3>Model check</h3><ul class="checks" id="spChecks"></ul>
        <h3>What is exact and what is simplified</h3><ul><li><b>Exact:</b> the smooth curve is Planck's law for a perfect blackbody. Line positions are laboratory wavelengths. The Doppler shift uses the relativistic formula.</li><li><b>Simplified:</b> how deep each line is. A teaching model raises and lowers each element's lines with temperature to match the real trends (hydrogen peaks near 9,500 K, metals and calcium in cooler stars, molecules in the coolest). Real line depths need a full model of a star's atmosphere.</li><li>Real stars are not perfect blackbodies; the Sun's spectrum deviates noticeably in the ultraviolet.</li></ul>
        <h3>What a spectrum can tell you</h3><ul><li>Surface temperature, from colour and line patterns.</li><li>Composition, from which lines appear.</li><li>Motion toward or away from us, from the shift of the lines.</li></ul>
        <h3>What it can't tell you on its own</h3><ul><li>How far away the star is, so not its true brightness or size. That needs a distance, such as a parallax.</li><li>How much of an element there is, without an atmosphere model; that is the mistake Payne's work corrected.</li></ul>
        <h3>Equations used</h3><ul class="eqs"><li><span class="m"><var>B</var><sub>λ</sub> = (2<var>hc</var><sup>2</sup>/λ<sup>5</sup>) / (e<sup><var>hc</var>/λ<var>kT</var></sup> − 1)</span><small>Planck's law</small></li><li><span class="m">λ<sub>peak</sub> = 2.898 mm·K / <var>T</var></span><small>Wien's law</small></li><li><span class="m">λ<sub>obs</sub> = λ √((1+β)/(1−β))</span><small>Doppler, β = v/c</small></li></ul>
        <h3>Sources</h3><ul><li>Line wavelengths: NIST Atomic Spectra Database (air wavelengths).</li><li>Constants: SI 2019 exact values; CODATA 2018 for Wien's and Stefan–Boltzmann constants.</li><li>Colour: CIE 1931 observer, analytic fit by Wyman, Sloan and Shirley (2013).</li><li>C. Payne (1925), Stellar Atmospheres, Harvard Observatory Monographs 1.</li></ul>` },
    ],
  });
  const visible = (l) => l >= 380 && l <= 750;
  function lineDepth(L) { const st = (Sp.STRENGTH[L.el] || (() => 0))(S.T); return Math.min(0.92, st * L.f * 0.9); }
  function draw() {
    const D = Sp.dopplerFactor(S.v / 299792.458), Tobs = S.T / D;
    const [r, g, b] = Sp.starColor(Tobs), peak = Sp.wienNm(Tobs);
    $('#spRoT', root).textContent = `${num(S.T)} K`; $('#spTOut', root).textContent = `${num(S.T)} K`;
    $('#spRoP', root).textContent = `${num(peak)} nm, ${peak < 380 ? 'ultraviolet' : peak > 750 ? 'infrared' : 'visible'}`;
    $('#spRoC', root).textContent = `${Sp.spectralClass(S.T)}-type`;
    $('#spRoV', root).textContent = S.v === 0 ? 'At rest' : `${num(Math.abs(S.v))} km/s ${S.v > 0 ? 'away' : 'toward'}`;
    $('#spVOut', root).textContent = S.v === 0 ? '0 km/s' : `${S.v > 0 ? '+' : '−'}${num(Math.abs(S.v))} km/s`;
    $('#spT', root).value = Math.log10(S.T); $('#spV', root).value = S.v;
    canvasArt($('#spStar', root), (ctx, W, H, dpr) => { ctx.fillStyle = '#03060e'; ctx.fillRect(0, 0, W, H); const R0 = Math.min(W, H) * 0.3; const gg = ctx.createRadialGradient(W / 2, H / 2, R0 * 0.2, W / 2, H / 2, R0 * 1.6); gg.addColorStop(0, `rgb(${r},${g},${b})`); gg.addColorStop(0.55, `rgba(${r},${g},${b},.9)`); gg.addColorStop(1, `rgba(${r},${g},${b},0)`); ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(W / 2, H / 2, R0 * 1.6, 0, TAU); ctx.fill(); });
    // curve
    canvasArt($('#spCurve', root), (ctx, W, H, dpr) => {
      ctx.fillStyle = '#03060e'; ctx.fillRect(0, 0, W, H);
      const L0 = 100, L1 = 1600, Lp = 12 * dpr, Rp = 12 * dpr, Tp = 22 * dpr, Bp = 22 * dpr;
      const X = l => Lp + (W - Lp - Rp) * (l - L0) / (L1 - L0);
      const curve = T => { const out = []; for (let i = 0; i <= 400; i++) { const l = L0 + (L1 - L0) * i / 400; out.push([l, Sp.planck(l, T)]); } return out; };
      const c1 = curve(Tobs), c2 = S.compare ? curve(5772) : [];
      const max = Math.max(...c1.map(p => p[1]), ...(c2.length ? c2.map(p => p[1]) : [0]));
      const Y = v => H - Bp - (H - Tp - Bp) * v / max;
      for (let l = 380; l <= 750; l += 2) { const [rr, gg2, bb] = Sp.wavelengthRGB(l); ctx.fillStyle = `rgba(${rr},${gg2},${bb},.13)`; ctx.fillRect(X(l), Tp, Math.max(1, X(l + 2) - X(l)) + 0.5, H - Tp - Bp); }
      ctx.strokeStyle = 'rgba(150,170,205,.3)'; ctx.lineWidth = dpr; ctx.beginPath(); ctx.moveTo(Lp, H - Bp); ctx.lineTo(W - Rp, H - Bp); ctx.stroke();
      ctx.fillStyle = 'rgba(205,216,235,.75)'; ctx.font = `${10 * dpr}px ${FONT}`; ctx.textAlign = 'center';
      [200, 500, 1000, 1500].forEach(l => ctx.fillText(`${l} nm`, clamp(X(l), 22 * dpr, W - 22 * dpr), H - 6 * dpr));
      const narrow = W < 520 * dpr; ctx.fillText(narrow ? 'UV' : 'ultraviolet', X(240), Tp - 8 * dpr); ctx.fillText('visible', X(565), Tp - 8 * dpr); ctx.fillText(narrow ? 'IR' : 'infrared', X(1150), Tp - 8 * dpr);
      const line = (pts, col, w, dash) => { ctx.save(); if (dash) ctx.setLineDash(dash); ctx.strokeStyle = col; ctx.lineWidth = w * dpr; ctx.beginPath(); pts.forEach(([l, v], i) => i ? ctx.lineTo(X(l), Y(v)) : ctx.moveTo(X(l), Y(v))); ctx.stroke(); ctx.restore(); };
      if (c2.length) line(c2, 'rgba(242,184,91,.85)', 1.5, [5 * dpr, 4 * dpr]);
      line(c1, `rgb(${Math.max(r, 120)},${Math.max(g, 120)},${Math.max(b, 120)})`, 2.4);
      if (peak > L0 && peak < L1) { ctx.strokeStyle = 'rgba(230,236,248,.6)'; ctx.setLineDash([3 * dpr, 3 * dpr]); ctx.beginPath(); ctx.moveTo(X(peak), Y(Sp.planck(peak, Tobs))); ctx.lineTo(X(peak), H - Bp); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = '#e9eef7'; ctx.textAlign = 'left'; ctx.fillText('peak', X(peak) + 5 * dpr, Y(Sp.planck(peak, Tobs)) + 14 * dpr); ctx.textAlign = 'center'; }
    });
    // strip
    $('#spStripTitle', root).textContent = S.mode === 'abs' ? 'Visible spectrum: dark absorption lines' : 'Visible spectrum: bright emission lines';
    canvasArt($('#spStrip', root), (ctx, W, H, dpr) => {
      ctx.fillStyle = '#03060e'; ctx.fillRect(0, 0, W, H);
      const L0 = 380, L1 = 750, Lp = 10 * dpr, Rp = 10 * dpr, top = 22 * dpr, bot = H - 22 * dpr;
      const X = l => Lp + (W - Lp - Rp) * (l - L0) / (L1 - L0);
      const lines = Sp.LINES.map(L => ({ ...L, obs: L.nm * D }));
      if (S.mode === 'abs') {
        for (let px = 0; px < W - Lp - Rp; px++) { const l = L0 + (L1 - L0) * px / (W - Lp - Rp); const [rr, gg2, bb] = Sp.wavelengthRGB(l); ctx.fillStyle = `rgb(${rr},${gg2},${bb})`; ctx.fillRect(Lp + px, top, 1, bot - top); }
        const tio = Sp.STRENGTH.TiO(S.T);
        if (tio > 0) Sp.TIO.forEach(nm => { const o = nm * D, g2 = ctx.createLinearGradient(X(o), 0, X(o + 18 * D), 0); g2.addColorStop(0, `rgba(0,0,0,${0.75 * tio})`); g2.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g2; ctx.fillRect(X(o), top, X(o + 18 * D) - X(o), bot - top); });
        lines.forEach(L => { if (!visible(L.obs)) return; const d = lineDepth(L); if (d < 0.03) return; const dim = S.focus !== 'all' && S.focus !== L.el; ctx.fillStyle = `rgba(0,0,0,${dim ? d * 0.35 : d})`; const w = Math.max(1.5 * dpr, (L.el === 'H' ? 1.6 : 0.8) * (W / 370) * (0.5 + d)); ctx.fillRect(X(L.obs) - w / 2, top, w, bot - top); });
      } else {
        lines.filter(L => L.el === S.gas).forEach(L => { if (!visible(L.obs)) return; const [rr, gg2, bb] = Sp.wavelengthRGB(L.nm); const w = Math.max(2 * dpr, 2.2 * (W / 370)); const g2 = ctx.createLinearGradient(X(L.obs) - w * 2, 0, X(L.obs) + w * 2, 0); g2.addColorStop(0, 'rgba(0,0,0,0)'); g2.addColorStop(0.5, `rgba(${rr},${gg2},${bb},${0.5 + 0.5 * L.f})`); g2.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g2; ctx.fillRect(X(L.obs) - w * 2, top, w * 4, bot - top); });
      }
      ctx.fillStyle = 'rgba(205,216,235,.8)'; ctx.font = `${10 * dpr}px ${FONT}`; ctx.textAlign = 'center';
      [400, 450, 500, 550, 600, 650, 700].forEach(l => ctx.fillText(`${l}`, X(l), H - 6 * dpr));
      if (S.fraun) Sp.FRAUNHOFER.forEach(([lt, nm]) => { const o = nm; if (!visible(o)) return; ctx.fillStyle = '#f2b85b'; ctx.font = `700 ${11 * dpr}px ${FONT}`; ctx.fillText(lt, X(o), top - 7 * dpr); ctx.fillRect(X(o) - 0.5 * dpr, top - 4 * dpr, dpr, 4 * dpr); });
      else if (S.mode === 'abs') { const shown = lines.filter(L => visible(L.obs) && lineDepth(L) > 0.25 && (S.focus === 'all' || S.focus === L.el)).sort((a, b2) => lineDepth(b2) - lineDepth(a)).slice(0, 5); let last = -1e9; shown.sort((a, b2) => a.obs - b2.obs).forEach(L => { const x = X(L.obs); if (x - last < 38 * dpr) return; last = x; ctx.fillStyle = 'rgba(230,236,248,.85)'; ctx.font = `700 ${10 * dpr}px ${FONT}`; ctx.fillText(L.name, x, top - 7 * dpr); }); }
      else lines.filter(L => L.el === S.gas && visible(L.obs)).forEach(L => { ctx.fillStyle = 'rgba(230,236,248,.85)'; ctx.font = `700 ${10 * dpr}px ${FONT}`; ctx.fillText(L.name, X(L.obs), top - 7 * dpr); });
    });
    $('#spCurveNote', root).textContent = S.compare ? 'Solid: this star. Dashed: the Sun at 5,772 K, on the same vertical scale, so hotter stars tower over it.' : 'Brightness at each wavelength, scaled to fit.';
    story(D);
    $('#spGasBox', root).hidden = S.mode !== 'emi'; $('#spFocusBox', root).hidden = S.mode !== 'abs';
  }
  function story(D) {
    const T = S.T, cls = Sp.spectralClass(T), strongest = Object.entries({ H: 'hydrogen', He: 'helium', Ca: 'ionised calcium', Na: 'sodium', Fe: 'iron and other metals' }).map(([k, n]) => [n, Sp.STRENGTH[k](T)]).sort((a, b) => b[1] - a[1])[0][0];
    let t = S.mode === 'emi' ? `A thin, hot cloud of ${{ H: 'hydrogen', He: 'helium', Na: 'sodium' }[S.gas]} glows only at the wavelengths its atoms emit, giving bright lines on a dark background. The same atoms absorb at exactly those wavelengths when cooler gas sits in front of a hotter source, which is why stars show dark lines.`
      : `A ${cls}-type star at ${num(T)} K shines brightest at ${num(Sp.wienNm(T))} nm${Sp.wienNm(T) < 380 ? ', in the ultraviolet, so it looks blue-white' : Sp.wienNm(T) > 750 ? ', in the infrared, so it looks orange-red' : ''}. Its strongest lines come from ${strongest}${T < 3900 ? ', plus broad bands from titanium-oxide molecules' : ''}.`;
    if (S.v !== 0) t += ` Every line is shifted by ${((D - 1) * 100).toFixed(2)}% ${S.v > 0 ? 'toward the red' : 'toward the blue'}: Hα appears at ${(656.28 * D).toFixed(1)} nm instead of 656.3 nm.`;
    $('#spStory', root).textContent = t;
  }
  function checks() {
    const pk = Sp.peakNumeric(S.T), w = Sp.wienNm(S.T), M = Sp.radiantExitance(S.T), sb = Sp.SIGMA * Math.pow(S.T, 4);
    const d1 = Math.abs(pk - w) / w, d2 = Math.abs(M - sb) / sb;
    $('#spChecks', root).innerHTML = checkRow("Peak matches Wien's law", d1 < 1e-4 ? 'ok' : 'bad', d1 < 1e-4 ? 'Holds' : 'Broken', `Numerical peak of the plotted Planck curve: ${pk.toFixed(2)} nm. Wien's law: ${w.toFixed(2)} nm.`)
      + checkRow('Total output matches σT⁴', d2 < 1e-3 ? 'ok' : 'bad', d2 < 1e-3 ? 'Holds' : 'Broken', `Integrating the curve over all wavelengths gives ${sig(M, 4)} W/m²; the Stefan–Boltzmann law gives ${sig(sb, 4)} W/m². Difference ${(d2 * 100).toExponential(1)}%.`);
  }
  function set(p) { Object.assign(S, p); syncCtl(); draw(); checks(); }
  function syncCtl() { $$('input[name="spMode"]', root).forEach(i => i.checked = i.value === S.mode); $$('input[name="spGas"]', root).forEach(i => i.checked = i.value === S.gas); $$('input[name="spFocus"]', root).forEach(i => i.checked = i.value === S.focus); $('#spCmp', root).checked = S.compare; $('#spFr', root).checked = S.fraun; }
  $('#spT', root).addEventListener('input', e => set({ T: Math.round(Math.pow(10, Number(e.target.value)) / 10) * 10 }));
  $('#spPresets', root).addEventListener('click', e => { const b = e.target.closest('button'); if (b) set({ T: Number(b.dataset.t) }); });
  $('#spV', root).addEventListener('input', e => set({ v: Number(e.target.value) }));
  $('#spV0', root).addEventListener('click', () => set({ v: 0 }));
  $$('input[name="spMode"]', root).forEach(i => i.addEventListener('change', () => set({ mode: i.value })));
  $$('input[name="spGas"]', root).forEach(i => i.addEventListener('change', () => set({ gas: i.value })));
  $$('input[name="spFocus"]', root).forEach(i => i.addEventListener('change', () => set({ focus: i.value })));
  $('#spCmp', root).addEventListener('change', e => set({ compare: e.target.checked }));
  $('#spFr', root).addEventListener('change', e => set({ fraun: e.target.checked }));
  experiments($('#spExps', root), 'spectra', EXPS, {
    setup: e => set({ ...e.before, focus: 'all' }),
    run: e => {
      const before = { T: S.T, v: S.v }; set(e.after);
      if (e.id === 'hotter') return `<b>Measured:</b> peak ${num(Sp.wienNm(before.T))} nm → ${num(Sp.wienNm(S.T))} nm.`;
      if (e.id === 'away') return `<b>Measured:</b> Hα 656.3 nm → ${(656.28 * Sp.dopplerFactor(S.v / 299792.458)).toFixed(1)} nm.`;
      return `<b>Model line strength for hydrogen:</b> ${(Sp.STRENGTH.H(3500) * 100).toFixed(0)}% at 3,500 K, ${(Sp.STRENGTH.H(9500) * 100).toFixed(0)}% at 9,500 K, ${(Sp.STRENGTH.H(30000) * 100).toFixed(0)}% at 30,000 K. Try 30,000 K in Controls to compare.`;
    },
  });
  syncCtl(); draw(); checks();
  watch($('#spCurve', root), draw);
}

/* =====================================================================
   LAB F — Black holes
   ===================================================================== */
function blackholeLab(root) {
  const S = { view: 'orbit', r0: 30, f: 0.9, clock: 'far', orb: null, newt: null, prog: 0, playing: !reduceMotion, radial: null, lensX: 0.35, lensE: 0.32, mass: 6.63, lensBg: null };
  const EXPS = [
    { id: 'precess', title: 'An orbit far from the hole', law: 'Orbital precession', setup: 'A star orbits at up to 40 Schwarzschild radii, on a slightly oval path. The dashed line is what Newton\'s gravity predicts.', q: 'In general relativity, what does the oval orbit do?', options: ['Retraces the same oval forever', 'Slowly turns, tracing a rosette', 'Spirals straight in'], answer: 1, explain: 'Close to a strong mass, gravity pulls slightly harder than Newton\'s inverse square, so the closest point of the orbit creeps forward each lap. Mercury\'s orbit turns the same way by 43 arcseconds per century, one of the first tests of Einstein\'s theory.', before: { r0: 40, f: 0.9 }, after: { r0: 40, f: 0.9 } },
    { id: 'isco', title: 'Too close to circle', law: 'The innermost stable orbit', setup: 'Next, a nearly circular orbit at 2.5 Schwarzschild radii, inside the innermost stable circular orbit at 3.', q: 'What happens to it?', options: ['It stays circular', 'It drifts and plunges into the hole', 'It escapes'], answer: 1, explain: 'In Newton\'s gravity any circular orbit is stable. Around a black hole, circular orbits closer than three Schwarzschild radii are unstable: the slightest nudge sends the object spiralling in. This is why accretion disks have an inner edge.', before: { r0: 10, f: 1 }, after: { r0: 2.5, f: 0.995 } },
    { id: 'fall', title: 'Dropping into a black hole', law: 'Time near the horizon', setup: 'A probe is released from rest at 5 Schwarzschild radii and falls straight in. We watch with a clock far away.', q: 'How long does it take to reach the event horizon, by our faraway clock?', options: ['A few seconds', 'Forever: it seems to freeze just outside', 'It bounces off the horizon'], answer: 1, explain: 'Seen from far away, the probe slows down and its light reddens and fades as it nears the horizon; it never quite appears to cross. On the probe\'s own clock the fall takes a short, finite time, and nothing special happens at the horizon, which is not a surface.', before: { r0: 5, f: 0.0 }, after: { r0: 5, f: 0.0 } },
  ];
  shell(root, {
    title: 'Black holes',
    intro: 'Orbits and falls around a non-spinning black hole, calculated with Einstein\'s equations for its geometry, side by side with Newton\'s prediction. Lengths are in <b>Schwarzschild radii</b>: the size of the event horizon. The event horizon is <b>not a surface</b>, only a point of no return.',
    stage: `<div class="row" style="margin-bottom:10px"><div class="seg" role="radiogroup" aria-label="View"><label><input type="radio" name="bhView" value="orbit" checked><span>Orbits and falls</span></label><label><input type="radio" name="bhView" value="lens"><span>Bending light</span></label><label><input type="radio" name="bhView" value="art"><span>What it might look like</span></label></div></div>
      <div class="viewport" id="bhView"><canvas id="bhCv" role="img" aria-label="Black hole simulation"></canvas><div class="hud hud-tl"><span class="chip" id="bhTag"></span></div></div>
      <div class="caption" id="bhLegend"></div>
      <div class="transport" id="bhTransport"><button class="btn btn-primary" id="bhPlay">Pause</button><button class="btn" id="bhRestart">Restart</button>
        <label class="playback"><span class="pb-text">Clock</span><select id="bhClock"><option value="far">Faraway clock</option><option value="proper">Object's own clock</option></select></label></div>
      <dl class="readouts" id="bhRo"><div class="ro"><dt>Distance</dt><dd id="bhRo1">—</dd></div><div class="ro"><dt>Faraway clock</dt><dd id="bhRo2">—</dd></div><div class="ro"><dt>Object's clock</dt><dd id="bhRo3">—</dd></div><div class="ro"><dt>Status</dt><dd id="bhRo4">—</dd></div></dl>
      <div class="story"><h2>What's happening</h2><p id="bhStory"></p></div>`,
    tabs: [
      { id: 'exp', label: 'Experiments', html: `<h2>Predict first, then run</h2><p class="intro">Each experiment sets up an orbit or a fall and asks for your prediction.</p><ol class="exps" id="bhExps"></ol>` },
      { id: 'ctl', label: 'Controls', html: `<div class="field"><div class="field-head"><label for="bhR">Starting distance</label><output id="bhROut"></output></div><input type="range" id="bhR" min="2" max="40" step="0.1"><p class="hint">In Schwarzschild radii. The object starts at its farthest point.</p></div>
        <div class="field"><div class="field-head"><label for="bhF">Sideways speed</label><output id="bhFOut"></output></div><input type="range" id="bhF" min="0" max="1.2" step="0.005"><p class="hint">As a share of what a circular orbit needs at that distance (inside 1.5 Schwarzschild radii there are no circular orbits at all). 0% is a straight drop.</p></div>
        <div class="field"><div class="field-head"><label for="bhM">Black hole mass, for real units</label><output id="bhMOut"></output></div><input type="range" id="bhM" min="0" max="10" step="0.01"><p class="hint" id="bhMHint"></p></div>
        <div class="field" id="bhLensCtl"><div class="field-head"><label for="bhLx">Lens position</label><output id="bhLxOut"></output></div><input type="range" id="bhLx" min="-0.8" max="0.8" step="0.005"><p class="hint">In the Bending light view: slide the black hole across the background galaxy. When they line up exactly, the galaxy becomes an Einstein ring.</p></div>` },
      { id: 'evidence', label: 'Evidence', prose: true, html: `<h3>How we know black holes are real</h3><ul>
        <li><b>Stars orbiting nothing visible.</b> For three decades, astronomers tracked stars around the centre of the Milky Way. The star S2 completes an orbit every 16 years around an invisible object of about 4 million solar masses. This work earned Andrea Ghez and Reinhard Genzel the 2020 Nobel Prize in Physics.</li>
        <li><b>Gravitational waves.</b> On 14 September 2015, LIGO detected ripples in space from two black holes, about 36 and 29 times the Sun's mass, merging 1.3 billion light-years away.</li>
        <li><b>Images of the shadow.</b> The Event Horizon Telescope published images of the black hole in galaxy M87 (6.5 billion solar masses) in 2019, and of the Milky Way's own, Sagittarius A*, in 2022. They show a blurry bright ring around a dark centre.</li>
        <li><b>X-ray binaries.</b> In systems like Cygnus X-1, gas pulled off a companion star heats to millions of degrees and glows in X-rays, orbiting an object too heavy to be a neutron star.</li></ul>
        <h3>Observation versus illustration</h3><p>The "What it might look like" view is an illustration, not a photograph and not a simulation. Real images are far blurrier, limited by the size of Earth-wide telescope networks.</p>` },
      { id: 'model', label: 'Model', prose: true, html: `<h3>Model check</h3><ul class="checks" id="bhChecks"></ul>
        <h3>How it's calculated</h3><p>Orbits follow the exact equation for paths around a non-spinning, uncharged black hole (the Schwarzschild solution): u″ + u = M/h² + 3Mu², where u = 1/r and h is angular momentum. The extra 3Mu² term is general relativity's correction; drop it and you get Newton's orbits, shown dashed. Straight falls use the exact textbook solution (Misner, Thorne and Wheeler, eq. 31.10).</p>
        <p>The animation runs on either clock: a faraway observer's time t or the falling object's own time τ.</p>
        <h3>What it leaves out</h3><ul><li>Spin. Real black holes rotate, which changes the innermost orbit.</li><li>The object's own mass, gas pressure, and tidal stretching.</li><li>Light bending uses the weak-field lens equation, accurate far from the hole but not near the horizon. The dark disk in that view is not to scale.</li></ul>
        <h3>Sources</h3><ul><li>Misner, Thorne and Wheeler (1973), Gravitation, ch. 25 and 31.</li><li>GRAVITY Collaboration (2019, 2020) and Ghez et al. (2008) for Sagittarius A*.</li><li>LIGO Scientific and Virgo Collaborations (2016), Physical Review Letters 116, 061102.</li><li>Event Horizon Telescope Collaboration (2019, 2022), Astrophysical Journal Letters 875 and 930.</li></ul>` },
    ],
    onTab: () => {},
  });
  const rsKm = () => BH.RS_KM_PER_MSUN * Math.pow(10, S.mass);
  function compute() {
    const r0M = S.r0 * 2; // geometric units: r in M
    S.prog = 0; S.radial = null; S.orb = null; S.newt = null;
    if (S.f < 0.01) { S.radial = BH.radialFall(r0M); return; }
    const hc = r0M > 3.05 ? BH.hCirc(r0M) : BH.hNewton(r0M), h = hc * S.f;
    S.orb = BH.orbit(r0M, h, { maxPhi: 24 * Math.PI, rEscape: 120 });
    S.newt = BH.orbit(r0M, h, { gr: false, maxPhi: 24 * Math.PI, rEscape: 120 });
  }
  function current() {
    // returns {r (in M), phi, t, tau, done}
    if (S.radial) {
      const pts = S.radial.pts, key = S.clock === 'far' ? 2 : 1, tgt = S.prog;
      let i = pts.findIndex(p => p[key] >= tgt); if (i < 0) i = pts.length - 1;
      const p = pts[i], done = S.clock === 'proper' ? tgt >= S.radial.tauHorizon : false;
      return { r: p[0], phi: 0, t: p[2], tau: p[1], done, idx: i };
    }
    const pts = S.orb.pts, key = S.clock === 'far' ? 2 : 3;
    let lo = 0, hi = pts.length - 1;
    while (lo < hi) { const m = (lo + hi) >> 1; pts[m][key] < S.prog ? lo = m + 1 : hi = m; }
    const p = pts[lo]; return { r: p[0], phi: p[1], t: p[2], tau: p[3], done: lo >= pts.length - 1, idx: lo };
  }
  const fmtT = (tM) => { const s = tM * rsKm() / 2 / 299792.458; return s < 1 ? `${sig(s * 1000, 3)} ms` : s < 120 ? `${sig(s, 3)} s` : s < 7200 ? `${sig(s / 60, 3)} min` : s < 172800 ? `${sig(s / 3600, 3)} h` : `${sig(s / 86400, 3)} days`; };
  function drawOrbit(ctx, W, H, dpr) {
    spaceBg(ctx, W, H, 66, 0.6);
    const c = current(), cx = W / 2, cy = H / 2;
    const span = Math.max(S.r0 * 2 * 1.25, 14), k = Math.min(W, H) / 2 / span; // pixels per M
    const ring = (rM, col, dash, lab) => { ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = dpr; if (dash) ctx.setLineDash(dash); ctx.beginPath(); ctx.arc(cx, cy, rM * k, 0, TAU); ctx.stroke(); ctx.restore(); if (lab && rM * k > 18 * dpr) { ctx.fillStyle = col; ctx.font = `${10 * dpr}px ${FONT}`; ctx.textAlign = 'left'; ctx.fillText(lab, cx + rM * k * 0.71 + 4 * dpr, cy - rM * k * 0.71); } };
    ring(6, 'rgba(242,184,91,.6)', [4 * dpr, 4 * dpr], 'innermost stable orbit'); ring(3, 'rgba(169,147,255,.7)', [2 * dpr, 3 * dpr], 'photon sphere');
    const g = ctx.createRadialGradient(cx, cy, 2 * k, cx, cy, 3.2 * k); g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, 3.2 * k, 0, TAU); ctx.fill();
    ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(cx, cy, 2 * k, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(255,150,90,.55)'; ctx.lineWidth = dpr; ctx.stroke();
    const P = (r, ph) => [cx + r * k * Math.cos(ph), cy - r * k * Math.sin(ph)];
    if (S.newt) { const pts = S.newt.pts; ctx.save(); ctx.setLineDash([4 * dpr, 5 * dpr]); ctx.strokeStyle = 'rgba(205,216,235,.45)'; ctx.lineWidth = 1.2 * dpr; ctx.beginPath(); for (let i = 0; i < pts.length; i += 3) { const [x, y] = P(pts[i][0], pts[i][1]); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); if (pts[i][1] > 2.05 * Math.PI) break; } ctx.stroke(); ctx.restore(); }
    if (S.orb) { const pts = S.orb.pts; ctx.strokeStyle = '#5cd6e6'; ctx.lineWidth = 1.8 * dpr; ctx.beginPath(); for (let i = 0; i <= c.idx; i += 2) { const [x, y] = P(pts[i][0], pts[i][1]); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); } const [xe, ye] = P(c.r, c.phi); ctx.lineTo(xe, ye); ctx.stroke(); }
    if (S.radial) { ctx.strokeStyle = 'rgba(92,214,230,.6)'; ctx.lineWidth = 1.5 * dpr; ctx.beginPath(); ctx.moveTo(...P(S.r0 * 2, 0)); ctx.lineTo(...P(c.r, 0)); ctx.stroke(); }
    // object, reddened and dimmed near the horizon for the faraway observer
    const z = Math.sqrt(Math.max(1e-6, 1 - 2 / c.r)), [ox, oy] = P(c.r, c.phi);
    const fade = S.clock === 'far' ? z : 1;
    ctx.fillStyle = `rgba(${255},${Math.round(80 + 170 * fade)},${Math.round(60 + 190 * fade)},${0.25 + 0.75 * fade})`; ctx.beginPath(); ctx.arc(ox, oy, 4.5 * dpr, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(205,216,235,.8)'; ctx.font = `${10 * dpr}px ${FONT}`; ctx.textAlign = 'center'; ctx.fillText('event horizon', cx, cy + 2 * k + 14 * dpr);
    return c;
  }
  function lensBackground(N) {
    const cv = document.createElement('canvas'); cv.width = cv.height = N; const ctx = cv.getContext('2d');
    ctx.fillStyle = '#02040b'; ctx.fillRect(0, 0, N, N); const r = rng(77);
    for (let i = 0; i < 500; i++) { ctx.fillStyle = `rgba(235,240,255,${r() * 0.9})`; ctx.fillRect(r() * N, r() * N, 1.2, 1.2); }
    const gx = N * 0.5, gy = N * 0.5, g = ctx.createRadialGradient(gx, gy, 0, gx, gy, N * 0.16); g.addColorStop(0, 'rgba(255,236,200,1)'); g.addColorStop(0.4, 'rgba(200,180,255,.7)'); g.addColorStop(1, 'rgba(120,140,255,0)');
    ctx.save(); ctx.translate(gx, gy); ctx.scale(1, 0.55); ctx.rotate(0.5); ctx.translate(-gx, -gy); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(gx, gy, N * 0.16, 0, TAU); ctx.fill(); ctx.restore();
    for (let i = 0; i < 160; i++) { const t = i / 160 * 3 * Math.PI, rr = N * (0.02 + 0.12 * i / 160); ctx.fillStyle = 'rgba(190,210,255,.55)'; ctx.fillRect(gx + Math.cos(t + 0.5) * rr, gy + Math.sin(t + 0.5) * rr * 0.55, 1.6, 1.6); ctx.fillRect(gx - Math.cos(t + 0.5) * rr, gy - Math.sin(t + 0.5) * rr * 0.55, 1.6, 1.6); }
    return ctx.getImageData(0, 0, N, N);
  }
  function drawLens(ctx, W, H, dpr) {
    const N = 300; if (!S.lensBg) S.lensBg = lensBackground(N);
    const out = ctx.createImageData(N, N), src = S.lensBg.data, d = out.data, E2 = S.lensE * S.lensE, lx = S.lensX;
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      const tx = (x / N) * 2 - 1, ty = (y / N) * 2 - 1, rx = tx - lx, ry = ty, q = rx * rx + ry * ry + 1e-9;
      const bx = tx - E2 * rx / q, by = ty - E2 * ry / q;            // lens equation: β = θ − θ_E² θ/|θ|²
      const sx = Math.round((bx + 1) / 2 * N), sy = Math.round((by + 1) / 2 * N), o = (y * N + x) * 4;
      if (sx >= 0 && sx < N && sy >= 0 && sy < N) { const i = (sy * N + sx) * 4; d[o] = src[i]; d[o + 1] = src[i + 1]; d[o + 2] = src[i + 2]; } else { d[o] = 2; d[o + 1] = 4; d[o + 2] = 11; }
      d[o + 3] = 255;
    }
    const tmp = document.createElement('canvas'); tmp.width = tmp.height = N; tmp.getContext('2d').putImageData(out, 0, 0);
    ctx.fillStyle = '#02040b'; ctx.fillRect(0, 0, W, H);
    const s = Math.min(W, H), ox = (W - s) / 2, oy = (H - s) / 2; ctx.imageSmoothingEnabled = true; ctx.drawImage(tmp, ox, oy, s, s);
    const cxp = ox + (lx + 1) / 2 * s, cyp = oy + s / 2;
    ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(cxp, cyp, S.lensE * s * 0.18, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(242,184,91,.5)'; ctx.setLineDash([4 * dpr, 4 * dpr]); ctx.beginPath(); ctx.arc(cxp, cyp, S.lensE * s / 2, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(242,184,91,.85)'; ctx.font = `${10 * dpr}px ${FONT}`; ctx.textAlign = 'center'; ctx.fillText('Einstein radius', cxp, cyp - S.lensE * s / 2 - 6 * dpr);
  }
  function drawArt(ctx, W, H, dpr, tsec) {
    spaceBg(ctx, W, H, 31, 0.8);
    const cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.12, rot = reduceMotion ? 0 : tsec * 0.6;
    const disk = (front) => { for (let i = 0; i < 60; i++) { const rr = R * (1.6 + i * 0.045), a = 0.6 * (1 - i / 60); ctx.strokeStyle = `rgba(255,${Math.round(150 + 80 * (1 - i / 60))},${Math.round(70 + 60 * (1 - i / 60))},${a * 0.5})`; ctx.lineWidth = R * 0.05; ctx.beginPath(); ctx.ellipse(cx, cy, rr, rr * 0.22, 0, front ? 0 : Math.PI, front ? Math.PI : TAU); ctx.stroke(); } };
    disk(false);
    for (let i = 0; i < 40; i++) { const rr = R * (1.25 + i * 0.03), a = 0.55 * (1 - i / 40); ctx.strokeStyle = `rgba(255,200,130,${a * 0.45})`; ctx.lineWidth = R * 0.05; ctx.beginPath(); ctx.ellipse(cx, cy - R * 0.1, rr, rr * 0.95, 0, Math.PI * 1.05, Math.PI * 1.95); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(255,235,200,.9)'; ctx.lineWidth = 1.6 * dpr; ctx.beginPath(); ctx.arc(cx, cy, R * 1.04, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fill();
    disk(true);
    const hx = cx + Math.cos(rot) * R * 2.4, hy = cy + Math.sin(rot) * R * 2.4 * 0.22; if (Math.sin(rot) > 0) { ctx.fillStyle = 'rgba(255,240,210,.8)'; ctx.beginPath(); ctx.arc(hx, hy, 2.5 * dpr, 0, TAU); ctx.fill(); }
  }
  function draw(tsec = 0) {
    const view = S.view;
    $('#bhTransport', root).style.display = view === 'orbit' ? '' : 'none'; $('#bhRo', root).style.display = view === 'orbit' ? '' : 'none';
    $('#bhTag', root).textContent = view === 'orbit' ? 'Calculated with general relativity' : view === 'lens' ? 'Calculated, weak-field approximation' : 'Illustration, not a photograph';
    $('#bhLegend', root).innerHTML = view === 'orbit' ? '<div class="legend"><span><i class="sw"></i>General relativity</span><span><i class="sw pred"></i>Newton, same start</span></div><p class="scale-note">Distances to scale in Schwarzschild radii.</p>' : view === 'lens' ? '<p class="scale-note">A background galaxy seen past a black hole. Light passing nearby is bent, splitting and stretching the image.</p>' : '<p class="scale-note">Shadow, bright ring and a tilted disk whose far side is bent into view above and below the hole.</p>';
    let c = null;
    canvasArt($('#bhCv', root), (ctx, W, H, dpr) => { if (view === 'orbit') c = drawOrbit(ctx, W, H, dpr); else if (view === 'lens') drawLens(ctx, W, H, dpr); else drawArt(ctx, W, H, dpr, tsec); });
    if (view === 'orbit' && c) {
      $('#bhRo1', root).textContent = `${(c.r / 2).toFixed(2)} r_s`;
      $('#bhRo2', root).textContent = fmtT(c.t); $('#bhRo3', root).textContent = fmtT(c.tau);
      const status = S.radial ? (S.clock === 'proper' && c.done ? 'Crossed the horizon' : c.r < 2.02 ? 'Frozen at the horizon (as seen from afar)' : 'Falling') : S.orb.end === 'horizon' && c.done ? 'Fell in' : S.orb.end === 'escape' && c.done ? 'Escaped' : 'Orbiting';
      $('#bhRo4', root).textContent = status;
      story(c, status);
    } else story(null);
  }
  function story(c, status) {
    let t;
    if (S.view === 'lens') t = 'The black hole bends light from the galaxy behind it. Off-centre, you see two distorted images, one on each side. Slide the lens to the centre (position 0) and the images merge into an Einstein ring. Astronomers use the same effect, with galaxies as lenses, to weigh dark matter.';
    else if (S.view === 'art') t = 'The dark centre is the shadow, about 2.6 times wider than the event horizon. The thin bright ring is light that looped around the hole. The disk\'s far side appears above and below because its light is bent toward us. This is an illustration; the real Event Horizon Telescope images are much blurrier.';
    else if (S.radial) t = S.clock === 'far' ? `Released from rest at ${S.r0} r_s. Watched from far away, the probe slows as it nears the horizon and its light reddens and dims; it never seems to cross. Switch the clock to the object's own to see it cross in ${fmtT(S.radial.tauHorizon)}.` : `On its own clock, the probe crosses the horizon after ${fmtT(S.radial.tauHorizon)} and feels nothing special there. The horizon is not a surface, just the point after which no signal can get out.`;
    else {
      const prec = S.orb.apo.length > 1 ? (S.orb.apo[1] - S.orb.apo[0] - 2 * Math.PI) * 180 / Math.PI : null;
      t = S.orb.end === 'horizon' ? `This orbit cannot hold: it ${S.r0 < 3 ? 'starts inside the innermost stable orbit at 3 r_s, so' : 'dips too close and'} the object spirals in. Newton's gravity (dashed) would let it keep circling.` : S.orb.end === 'escape' ? 'With this much sideways speed the object escapes.' : `The orbit ${prec !== null ? `turns by ${prec.toFixed(1)}° each lap` : 'turns slightly each lap'}, tracing a rosette, while Newton's prediction (dashed) closes on itself.`;
    }
    $('#bhStory', root).textContent = t;
  }
  function checks() {
    const rows = [];
    if (S.orb) {
      rows.push(checkRow('Conserved energy stays fixed', S.orb.maxErr < 1e-8 ? 'ok' : 'warn', S.orb.maxErr < 1e-8 ? 'Holds' : 'Drifting', `The equation's built-in conserved quantity changed by at most ${S.orb.maxErr.toExponential(1)} (relative) along this orbit.`));
      const p = S.orb.apo.length > 1 ? (S.orb.apo[1] - S.orb.apo[0] - 2 * Math.PI) : null, wf = 6 * Math.PI / (S.orb.h * S.orb.h);
      if (p !== null && S.r0 >= 50) rows.push(checkRow('Precession matches the weak-field formula', Math.abs(p - wf) / wf < 0.05 ? 'ok' : 'warn', Math.abs(p - wf) / wf < 0.05 ? 'Holds' : 'Drifting', `Simulation ${(p * 180 / Math.PI).toFixed(3)}° per lap; formula 6πM/p gives ${(wf * 180 / Math.PI).toFixed(3)}°.`));
      else rows.push(checkRow('Precession against the weak-field formula', 'na', 'Not applicable', p !== null ? `This orbit is in strong gravity, where the simple formula (${(wf * 180 / Math.PI).toFixed(1)}°) underestimates the true turning (${(p * 180 / Math.PI).toFixed(1)}°). Set the distance to 50 r_s or more to test it.` : 'Needs a bound orbit that completes at least one lap.'));
    } else rows.push(checkRow('Fall time against the exact solution', 'ok', 'Holds', `The fall uses the exact solution. In automated tests, integrating the faraway clock step by step matched it to four decimal places.`));
    rows.push(checkRow('Innermost stable orbit at 3 r_s', 'ok', 'Holds', 'In automated tests, near-circular orbits at 4 r_s stayed bound and at 2.5 r_s plunged, as theory predicts.'));
    $('#bhChecks', root).innerHTML = rows.join('');
  }
  function syncCtl() {
    $('#bhR', root).value = S.r0; $('#bhROut', root).textContent = `${S.r0.toFixed(1)} r_s`;
    $('#bhF', root).value = S.f; $('#bhFOut', root).textContent = S.f < 0.01 ? 'None: straight drop' : `${Math.round(S.f * 100)}%`;
    $('#bhM', root).value = S.mass; const M = Math.pow(10, S.mass);
    $('#bhMOut', root).textContent = `${M < 1e4 ? sig(M, 3) : sig(M / 1e6, 3) + ' million'} M☉`;
    const rs = rsKm(); $('#bhMHint', root).textContent = `Event horizon radius: ${rs < 1e6 ? sig(rs, 3) + ' km' : sig(rs / 149597870.7, 3) + ' AU'}. Sagittarius A* is about 4 million M☉; M87* about 6.5 billion.`;
    $('#bhClock', root).value = S.clock; $('#bhLx', root).value = S.lensX; $('#bhLxOut', root).textContent = S.lensX.toFixed(2);
  }
  function restart() { compute(); syncCtl(); checks(); draw(); }
  $('#bhR', root).addEventListener('input', e => { S.r0 = Number(e.target.value); restart(); });
  $('#bhF', root).addEventListener('input', e => { S.f = Number(e.target.value); restart(); });
  $('#bhM', root).addEventListener('input', e => { S.mass = Number(e.target.value); syncCtl(); draw(); });
  $('#bhLx', root).addEventListener('input', e => { S.lensX = Number(e.target.value); syncCtl(); if (S.view !== 'lens') { S.view = 'lens'; $$('input[name="bhView"]', root).forEach(i => i.checked = i.value === 'lens'); } draw(); });
  $('#bhClock', root).addEventListener('change', e => { S.clock = e.target.value; S.prog = 0; draw(); });
  $('#bhPlay', root).addEventListener('click', () => { S.playing = !S.playing; $('#bhPlay', root).textContent = S.playing ? 'Pause' : 'Play'; });
  $('#bhRestart', root).addEventListener('click', () => { S.prog = 0; draw(); });
  $$('input[name="bhView"]', root).forEach(i => i.addEventListener('change', () => { S.view = i.value; draw(); }));
  experiments($('#bhExps', root), 'blackholes', EXPS, {
    setup: e => { S.view = 'orbit'; $$('input[name="bhView"]', root).forEach(i => i.checked = i.value === 'orbit'); S.clock = 'far'; Object.assign(S, { r0: e.before.r0, f: e.before.f }); S.playing = false; $('#bhPlay', root).textContent = 'Play'; restart(); },
    run: e => {
      Object.assign(S, { r0: e.after.r0, f: e.after.f }); S.playing = true; $('#bhPlay', root).textContent = 'Pause'; restart();
      if (e.id === 'precess') return S.orb.apo.length > 1 ? `<b>Measured:</b> the orbit turns ${((S.orb.apo[1] - S.orb.apo[0] - 2 * Math.PI) * 180 / Math.PI).toFixed(1)}° per lap.` : '';
      if (e.id === 'isco') return `<b>Result:</b> ${S.orb.end === 'horizon' ? 'it plunged across the horizon' : 'it is still orbiting'}.`;
      return `<b>Own clock:</b> the probe reaches the horizon after ${fmtT(S.radial.tauHorizon)}. Switch the clock below the view to see it.`;
    },
  });
  let tsec = 0;
  loop(dt => {
    tsec += dt;
    if (S.view === 'art') { draw(tsec); return; }
    if (S.view !== 'orbit' || !S.playing) return;
    const rate = S.radial ? (S.clock === 'far' ? 8 : S.radial.tauHorizon / 6) : 2 * Math.PI * Math.pow(S.r0 * 2, 1.5) / 4.5; // about 4.5 s per lap
    S.prog += dt * rate;
    const c = current(); draw(tsec);
    if (c.done && !S.radial) { S.playing = false; $('#bhPlay', root).textContent = 'Play'; }
  });
  restart(); watch($('#bhView', root), () => draw(tsec));
}

/* ======================= Hook ======================= */
const BUILDERS = { solar: solarLab, scale: scaleLab, spectra: spectraLab, blackholes: blackholeLab };
const TITLES = { solar: 'Solar System explorer', scale: 'Cosmic scale explorer', spectra: 'Stellar spectroscopy', blackholes: 'Black holes' };
APP.HOOKS.labx = {
  enter(id) {
    cleanup.forEach(f => f()); cleanup = [];
    const root = $('#labxRoot');
    if (!BUILDERS[id]) { root.innerHTML = `<div class="page-head"><h1>Lab not found</h1><p><a href="#/labs">See all labs</a>.</p></div>`; return; }
    APP.Progress.lab(id);
    BUILDERS[id](root);
  },
  leave() { cleanup.forEach(f => f()); cleanup = []; },
  title: id => TITLES[id] || 'Laboratories',
};
return { BUILDERS };
})();
