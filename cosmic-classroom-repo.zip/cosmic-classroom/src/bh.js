/* ---------- Black-hole physics (no DOM). Schwarzschild geometry, geometric units G = c = M = 1, so r_s = 2. ---------- */
const BH = (() => {
  const RS_KM_PER_MSUN = 2.95325;                       // 2GM☉/c² with IAU nominal GM☉
  const hCirc = r => Math.sqrt(r * r / (r - 3));        // angular momentum of a circular geodesic (r > 3)
  const hNewton = r => Math.sqrt(r);
  /* Orbit u(φ) = 1/r. GR: u'' = 1/h² − u + 3u². Newton: u'' = 1/h² − u. Starts at a turning point (dr = 0). */
  function orbit(r0, h, { gr = true, maxPhi = 40 * Math.PI, rEscape = 400 } = {}) {
    const E2 = (1 - 2 / r0) * (1 + h * h / (r0 * r0)), E = Math.sqrt(E2);
    const f = (u) => 1 / (h * h) - u + (gr ? 3 * u * u : 0);
    let u = 1 / r0, du = 0, phi = 0, t = 0, tau = 0, maxErr = 0;
    const pts = [[r0, 0, 0, 0]], peri = [];
    let prevDu = 0, end = 'running';
    const C0 = E2 / (h * h);
    while (phi < maxPhi) {
      const r = 1 / u, dphi = Math.min(0.01, Math.max(0.0004, 0.0025 * r / 2));
      // RK4 on (u, du)
      const k1u = du, k1v = f(u);
      const k2u = du + 0.5 * dphi * k1v, k2v = f(u + 0.5 * dphi * k1u);
      const k3u = du + 0.5 * dphi * k2v, k3v = f(u + 0.5 * dphi * k2u);
      const k4u = du + dphi * k3v, k4v = f(u + dphi * k3u);
      const un = u + dphi / 6 * (k1u + 2 * k2u + 2 * k3u + k4u), dn = du + dphi / 6 * (k1v + 2 * k2v + 2 * k3v + k4v);
      const rm = 2 / (u + un);
      if (gr) { t += E * rm * rm / (h * (1 - 2 / rm)) * dphi; tau += rm * rm / h * dphi; } else { t += rm * rm / h * dphi; tau = t; }
      u = un; prevDu = du; du = dn; phi += dphi;
      if (gr) { const C = du * du + (1 - 2 * u) * (1 / (h * h) + u * u); maxErr = Math.max(maxErr, Math.abs(C - C0) / C0); }
      if (prevDu < 0 && du >= 0 && 1 / u > 2.05) peri.push(phi - dphi + dphi * (-prevDu) / (du - prevDu)); // u at a minimum: apoapsis (interpolated)
      pts.push([1 / u, phi, t, tau]);
      if (gr && u >= 0.5) { end = 'horizon'; break; }
      if (!gr && u <= 0) { end = 'escape'; break; }
      if (1 / u > rEscape || u <= 0) { end = 'escape'; break; }
    }
    if (end === 'running') end = 'bound';
    return { pts, E, h, end, apo: peri, maxErr };
  }
  /* Radial fall from rest at R: exact cycloid solution (Misner, Thorne & Wheeler, eq. 31.10).
     r = (R/2)(1 + cos η), τ = √(R³/8)(η + sin η), t = 2 ln|(q + tan(η/2))/(q − tan(η/2))| + 2q[η + (R/4)(η + sin η)], q = √(R/2 − 1) */
  function radialFall(R) {
    const q = Math.sqrt(R / 2 - 1), etaH = Math.acos(4 / R - 1), pts = [];
    for (let i = 0; i <= 4000; i++) {
      const eta = etaH * (1 - Math.pow(1 - i / 4000, 3)) * 0.999999999;
      const r = R / 2 * (1 + Math.cos(eta)), tau = Math.sqrt(R * R * R / 8) * (eta + Math.sin(eta)), th = Math.tan(eta / 2);
      const t = 2 * Math.log(Math.abs((q + th) / (q - th))) + 2 * q * (eta + R / 4 * (eta + Math.sin(eta)));
      pts.push([r, tau, t]);
    }
    return { pts, tauHorizon: Math.sqrt(R * R * R / 8) * (etaH + Math.sin(etaH)) };
  }
  return { RS_KM_PER_MSUN, hCirc, hNewton, orbit, radialFall };
})();
if (typeof module !== 'undefined') module.exports = BH;
