/* ---------- Physics core (no DOM). Units: AU, Julian years, solar masses. ---------- */
const PHYS = (() => {
  const AU_M = 149597870700;              // IAU 2012 Resolution B2 (exact)
  const GM_SUN = 1.3271244e20;            // m^3 s^-2, IAU 2015 Resolution B3 nominal
  const R_SUN_M = 6.957e8;                // m, IAU 2015 Resolution B3 nominal
  const YEAR_S = 365.25 * 86400;          // Julian year
  const DAY_YR = 1 / 365.25;
  const MU_SUN = GM_SUN * YEAR_S * YEAR_S / (AU_M * AU_M * AU_M); // ≈ 39.4769 AU^3/yr^2
  const KMS_PER_AUYR = AU_M / 1000 / YEAR_S;                      // ≈ 4.74047
  const R_SUN_AU = R_SUN_M / AU_M;
  const MJKG_PER_AUYR2 = KMS_PER_AUYR * KMS_PER_AUYR;            // (km/s)^2 = MJ/kg
  const TAU = 2 * Math.PI;

  function elements(mu, x, y, vx, vy) {
    const r = Math.hypot(x, y);
    const v2 = vx * vx + vy * vy;
    const h = x * vy - y * vx;
    const E = v2 / 2 - mu / r;
    const rv = x * vx + y * vy;
    const ex = ((v2 - mu / r) * x - rv * vx) / mu;
    const ey = ((v2 - mu / r) * y - rv * vy) / mu;
    const e = Math.hypot(ex, ey);
    const p = h * h / mu;
    const a = Math.abs(E) > 1e-12 ? -mu / (2 * E) : Infinity;
    const rp = p / (1 + e);
    const bound = E < 0;
    const ra = bound ? a * (1 + e) : Infinity;
    const T = bound ? TAU * Math.sqrt(a * a * a / mu) : NaN;
    const omega = Math.atan2(ey, ex);
    return { r, h, E, e, ex, ey, p, a, rp, ra, T, omega, bound };
  }

  function circularSpeedKms(massSun, rAU) { return Math.sqrt(MU_SUN * massSun / rAU) * KMS_PER_AUYR; }
  function escapeSpeedKms(massSun, rAU) { return Math.sqrt(2 * MU_SUN * massSun / rAU) * KMS_PER_AUYR; }
  // Main-sequence approximation R ∝ M^0.8, used only to detect impacts.
  function starRadiusAU(massSun) { return R_SUN_AU * Math.pow(massSun, 0.8); }

  /* cfg: { mass (M☉), r0 (AU), v0 (km/s), angle (deg, 0 = sideways), integrator: 'verlet'|'euler', dtDays: 'auto'|number } */
  function createSim(cfg) {
    const mu = MU_SUN * cfg.mass;
    const v0 = cfg.v0 / KMS_PER_AUYR;
    const phi = cfg.angle * Math.PI / 180;
    const x = cfg.r0, y = 0;
    const vx = v0 * Math.sin(phi), vy = v0 * Math.cos(phi);
    const el = elements(mu, x, y, vx, vy);
    const rStar = starRadiusAU(cfg.mass);
    const tCirc0 = TAU * Math.sqrt(cfg.r0 ** 3 / mu);
    const usesPeriod = el.bound && el.T <= 3 * tCirc0;
    const tPlay = usesPeriod ? el.T : (el.bound ? Math.min(el.T, 3 * tCirc0) : tCirc0);
    const rpEff = Math.max(el.rp, rStar);
    const dtAuto = Math.min(TAU * Math.sqrt(rpEff ** 3 / mu), tPlay) / 1500;
    const dt = cfg.dtDays === 'auto' ? dtAuto : cfg.dtDays * DAY_YR;
    const wedgeDt = tPlay / 12;
    const r3 = cfg.r0 ** 3;

    const s = {
      cfg, mu, el, rStar, tCirc0, tPlay, dt, dtAuto, wedgeDt, usesPeriod,
      x, y, vx, vy, ax: -mu * x / r3, ay: -mu * y / r3,
      t: 0, steps: 0,
      E0: el.E, h0: el.h, Enorm: mu / cfg.r0,
      maxEerr: 0, maxHerr: 0,
      // period tracking
      theta: Math.atan2(y, x), thetaTotal: 0, crossings: [], periods: [],
      // equal-time wedges
      wedgeArea: 0, wedgeIndex: 0, wedges: [], wedgePts: [[x, y]],
      // samples for drawing
      trail: [[x, y]], lastTrailT: 0,
      energy: [], lastEnergyT: -Infinity,
      impacted: false, escaped: false, slowed: false, pending: 0,
    };
    sampleEnergy(s);
    return s;
  }

  function energyNow(s) {
    const r = Math.hypot(s.x, s.y);
    const ke = (s.vx * s.vx + s.vy * s.vy) / 2;
    const pe = -s.mu / r;
    return { r, ke, pe, E: ke + pe };
  }

  function sampleEnergy(s) {
    const en = energyNow(s);
    s.energy.push([s.t, en.ke, en.pe, en.E]);
    if (s.energy.length > 480) s.energy.shift();
    s.lastEnergyT = s.t;
  }

  function step(s) {
    if (s.impacted) return;
    const { mu, dt } = s;
    const xo = s.x, yo = s.y;
    if (s.cfg.integrator === 'euler') {
      const r = Math.hypot(xo, yo), r3 = r * r * r;
      const ax = -mu * xo / r3, ay = -mu * yo / r3;
      s.x = xo + dt * s.vx; s.y = yo + dt * s.vy;
      s.vx += dt * ax; s.vy += dt * ay;
    } else {
      // velocity Verlet (kick–drift–kick leapfrog): symplectic, time-reversible
      const vhx = s.vx + 0.5 * dt * s.ax, vhy = s.vy + 0.5 * dt * s.ay;
      s.x = xo + dt * vhx; s.y = yo + dt * vhy;
      const r = Math.hypot(s.x, s.y), r3 = r * r * r;
      s.ax = -mu * s.x / r3; s.ay = -mu * s.y / r3;
      s.vx = vhx + 0.5 * dt * s.ax; s.vy = vhy + 0.5 * dt * s.ay;
    }
    const tPrev = s.t;
    s.t += dt; s.steps++;

    // swept area (triangle with the star) — split linearly across wedge boundaries
    let dA = 0.5 * (xo * s.y - yo * s.x);
    let tCursor = tPrev;
    while (s.t >= (s.wedgeIndex + 1) * s.wedgeDt) {
      const tb = (s.wedgeIndex + 1) * s.wedgeDt;
      const f = (tb - tCursor) / (s.t - tCursor);
      s.wedgeArea += f * dA;
      dA *= (1 - f);
      const fx = xo + (s.x - xo) * ((tb - tPrev) / dt), fy = yo + (s.y - yo) * ((tb - tPrev) / dt);
      s.wedgePts.push([fx, fy]);
      s.wedges.push({ area: Math.abs(s.wedgeArea), pts: s.wedgePts, i: s.wedgeIndex });
      if (s.wedges.length > 12) s.wedges.shift();
      s.wedgeIndex++; s.wedgeArea = 0; s.wedgePts = [[fx, fy]];
      tCursor = tb;
    }
    s.wedgeArea += dA;

    // cumulative angle for period measurement
    const th = Math.atan2(s.y, s.x);
    let d = th - s.theta;
    if (d > Math.PI) d -= 2 * Math.PI; else if (d < -Math.PI) d += 2 * Math.PI;
    const totPrev = Math.abs(s.thetaTotal);
    s.thetaTotal += d; s.theta = th;
    const tot = Math.abs(s.thetaTotal);
    const k = Math.floor(tot / TAU);
    if (k > s.crossings.length && tot > totPrev) {
      const target = (s.crossings.length + 1) * TAU;
      const tc = tPrev + dt * (target - totPrev) / (tot - totPrev);
      const last = s.crossings.length ? s.crossings[s.crossings.length - 1] : 0;
      s.crossings.push(tc);
      s.periods.push(tc - last);
    }

    // conservation checks
    const r = Math.hypot(s.x, s.y);
    const E = (s.vx * s.vx + s.vy * s.vy) / 2 - mu / r;
    const eErr = Math.abs(E - s.E0) / s.Enorm;
    if (eErr > s.maxEerr) s.maxEerr = eErr;
    if (Math.abs(s.h0) > 1e-12) {
      const hErr = Math.abs((s.x * s.vy - s.y * s.vx) - s.h0) / Math.abs(s.h0);
      if (hErr > s.maxHerr) s.maxHerr = hErr;
    }

    // samples for drawing
    if (s.t - s.lastTrailT >= s.tPlay / 720) {
      s.trail.push([s.x, s.y]); s.lastTrailT = s.t;
      if (s.trail.length > 9000) s.trail.shift();
      if (s.wedgePts.length < 400) s.wedgePts.push([s.x, s.y]);
    }
    if (s.t - s.lastEnergyT >= s.tPlay / 240) sampleEnergy(s);

    if (r <= s.rStar) { s.impacted = true; s.trail.push([s.x, s.y]); }
    if (!s.el.bound && r > 40 * s.cfg.r0) s.escaped = true;
    if (s.el.bound && r > 40 * Math.max(s.cfg.r0, 1)) s.escaped = true; // numerical runaway (e.g. Euler)
  }

  // Advance by simulated time `simT`, capped to keep frames responsive.
  function advance(s, simT, maxSteps = 40000) {
    s.pending += simT;
    let n = 0;
    s.slowed = false;
    while (s.pending >= s.dt && !s.impacted && !s.escaped) {
      if (n >= maxSteps) { s.pending = 0; s.slowed = true; break; }
      step(s); s.pending -= s.dt; n++;
    }
    return n;
  }

  function wedgeSpread(s) {
    const w = s.wedges;
    if (w.length < 3) return null;
    const a = w.map(x => x.area);
    const mean = a.reduce((p, c) => p + c, 0) / a.length;
    return { min: Math.min(...a), max: Math.max(...a), mean, spread: (Math.max(...a) - Math.min(...a)) / mean, n: a.length };
  }

  return { AU_M, GM_SUN, MU_SUN, KMS_PER_AUYR, MJKG_PER_AUYR2, R_SUN_AU, DAY_YR, TAU,
    elements, circularSpeedKms, escapeSpeedKms, starRadiusAU, createSim, step, advance, energyNow, wedgeSpread };
})();
if (typeof module !== 'undefined') module.exports = PHYS;
