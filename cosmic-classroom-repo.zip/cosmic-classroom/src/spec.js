/* ---------- Spectroscopy physics (no DOM) ---------- */
const SPEC = (() => {
  const h = 6.62607015e-34, c = 299792458, k = 1.380649e-23;          // SI exact
  const WIEN_B = 2.897771955e-3, SIGMA = 5.670374419e-8;                // CODATA 2018
  const planck = (nm, T) => { const l = nm * 1e-9; return (2 * h * c * c / Math.pow(l, 5)) / Math.expm1(h * c / (l * k * T)); }; // W·sr⁻¹·m⁻³
  const wienNm = T => WIEN_B / T * 1e9;
  function peakNumeric(T) { // golden-section search for the maximum of B_λ
    let a = 10, b = 100000; const g = (Math.sqrt(5) - 1) / 2;
    let x1 = b - g * (b - a), x2 = a + g * (b - a);
    for (let i = 0; i < 200; i++) { if (planck(x1, T) > planck(x2, T)) { b = x2; x2 = x1; x1 = b - g * (b - a); } else { a = x1; x1 = x2; x2 = a + g * (b - a); } }
    return (a + b) / 2;
  }
  function radiantExitance(T) { // π ∫ B_λ dλ, log-spaced trapezoid from 1 nm to 1 mm
    let sum = 0, n = 6000, lo = Math.log(1), hi = Math.log(1e6);
    let prevL = Math.exp(lo), prevB = planck(prevL, T);
    for (let i = 1; i <= n; i++) { const L = Math.exp(lo + (hi - lo) * i / n), B = planck(L, T); sum += 0.5 * (B + prevB) * (L - prevL) * 1e-9; prevL = L; prevB = B; }
    return Math.PI * sum;
  }
  /* CIE 1931 colour matching functions, multi-lobe Gaussian fit (Wyman, Sloan & Shirley 2013) */
  const g = (x, mu, s1, s2) => { const t = (x - mu) / (x < mu ? s1 : s2); return Math.exp(-0.5 * t * t); };
  const cmf = l => [1.056 * g(l, 599.8, 37.9, 31.0) + 0.362 * g(l, 442.0, 16.0, 26.7) - 0.065 * g(l, 501.1, 20.4, 26.2),
                    0.821 * g(l, 568.8, 46.9, 40.5) + 0.286 * g(l, 530.9, 16.3, 31.1),
                    1.217 * g(l, 437.0, 11.8, 36.0) + 0.681 * g(l, 459.0, 26.0, 13.8)];
  const gamma = v => v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055;
  function xyzToRgb([X, Y, Z]) {
    let r = 3.2406 * X - 1.5372 * Y - 0.4986 * Z, gg = -0.9689 * X + 1.8758 * Y + 0.0415 * Z, b = 0.0557 * X - 0.2040 * Y + 1.0570 * Z;
    const m = Math.min(r, gg, b); if (m < 0) { r -= m; gg -= m; b -= m; }
    const M = Math.max(r, gg, b) || 1;
    return [r, gg, b].map(v => Math.round(255 * Math.min(1, gamma(v / M))));
  }
  function starColor(T) { let X = 0, Y = 0, Z = 0; for (let l = 380; l <= 780; l += 5) { const B = planck(l, T), [x, y, z] = cmf(l); X += B * x; Y += B * y; Z += B * z; } return xyzToRgb([X, Y, Z]); }
  function wavelengthRGB(l) { // display colour for a wavelength (Bruton's approximation; pure spectral colours lie outside sRGB)
    if (l < 380 || l > 750) return [40, 30, 50];
    let r = 0, gg = 0, b = 0;
    if (l < 440) { r = (440 - l) / 60; b = 1; } else if (l < 490) { gg = (l - 440) / 50; b = 1; } else if (l < 510) { gg = 1; b = (510 - l) / 20; }
    else if (l < 580) { r = (l - 510) / 70; gg = 1; } else if (l < 645) { r = 1; gg = (645 - l) / 65; } else r = 1;
    const f = l < 420 ? 0.3 + 0.7 * (l - 380) / 40 : l > 700 ? 0.3 + 0.7 * (750 - l) / 50 : 1;
    return [r, gg, b].map(v => Math.round(255 * Math.pow(v * f, 0.8)));
  }
  /* Laboratory (air) wavelengths in nm, NIST Atomic Spectra Database */
  const LINES = [
    { el: 'H', nm: 656.28, name: 'Hα', f: 1 }, { el: 'H', nm: 486.13, name: 'Hβ', f: 0.8 }, { el: 'H', nm: 434.05, name: 'Hγ', f: 0.65 }, { el: 'H', nm: 410.17, name: 'Hδ', f: 0.55 }, { el: 'H', nm: 397.01, name: 'Hε', f: 0.45 },
    { el: 'He', nm: 587.56, name: 'He I', f: 1 }, { el: 'He', nm: 447.15, name: 'He I', f: 0.8 }, { el: 'He', nm: 667.82, name: 'He I', f: 0.6 }, { el: 'He', nm: 501.57, name: 'He I', f: 0.6 },
    { el: 'Ca', nm: 393.37, name: 'Ca II K', f: 1 }, { el: 'Ca', nm: 396.85, name: 'Ca II H', f: 0.95 }, { el: 'Ca', nm: 422.67, name: 'Ca I', f: 0.5 },
    { el: 'Na', nm: 588.995, name: 'Na D2', f: 1 }, { el: 'Na', nm: 589.592, name: 'Na D1', f: 0.9 },
    { el: 'Mg', nm: 518.36, name: 'Mg b', f: 1 }, { el: 'Mg', nm: 517.27, name: 'Mg b', f: 0.9 }, { el: 'Mg', nm: 516.73, name: 'Mg b', f: 0.8 },
    { el: 'Fe', nm: 527.04, name: 'Fe I', f: 0.9 }, { el: 'Fe', nm: 438.35, name: 'Fe I', f: 0.8 }, { el: 'Fe', nm: 430.79, name: 'Fe I', f: 0.8 }, { el: 'Fe', nm: 495.76, name: 'Fe I', f: 0.6 }, { el: 'Fe', nm: 404.58, name: 'Fe I', f: 0.6 }, { el: 'Fe', nm: 532.80, name: 'Fe I', f: 0.5 },
  ];
  const TIO = [476.1, 495.4, 516.7, 544.8, 559.7, 615.9, 705.4]; // TiO band heads
  const FRAUNHOFER = [['A', 759.37, 'O₂ in Earth\'s air'], ['B', 686.72, 'O₂ in Earth\'s air'], ['C', 656.28, 'Hydrogen'], ['D', 589.29, 'Sodium'], ['E', 527.04, 'Iron'], ['b', 517.27, 'Magnesium'], ['F', 486.13, 'Hydrogen'], ['G', 430.78, 'Iron and CH'], ['H', 396.85, 'Calcium'], ['K', 393.37, 'Calcium']];
  /* Simplified teaching model of line strength vs temperature (reproduces the trends of the spectral sequence only) */
  const bump = (T, Tc, w) => { const x = (Math.log10(T) - Math.log10(Tc)) / w; return Math.exp(-x * x); };
  const STRENGTH = { H: T => bump(T, 9500, 0.16), He: T => bump(T, 23000, 0.11), Ca: T => bump(T, 4800, 0.19), Na: T => bump(T, 4000, 0.17), Mg: T => bump(T, 5000, 0.17), Fe: T => bump(T, 5000, 0.17), TiO: T => Math.max(0, Math.min(1, (3900 - T) / 900)) };
  const spectralClass = T => T >= 30000 ? 'O' : T >= 10000 ? 'B' : T >= 7500 ? 'A' : T >= 6000 ? 'F' : T >= 5200 ? 'G' : T >= 3700 ? 'K' : 'M';
  const dopplerFactor = beta => Math.sqrt((1 + beta) / (1 - beta)); // relativistic, radial motion
  return { h, c, k, WIEN_B, SIGMA, planck, wienNm, peakNumeric, radiantExitance, starColor, wavelengthRGB, LINES, TIO, FRAUNHOFER, STRENGTH, spectralClass, dopplerFactor };
})();
if (typeof module !== 'undefined') module.exports = SPEC;
