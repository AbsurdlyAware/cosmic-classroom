/* ---------- Ephemeris (no DOM). Low-precision methods, accurate to a fraction of a degree. ---------- */
const ASTRO = (() => {
  const D2R = Math.PI / 180, R2D = 180 / Math.PI;
  const norm = a => ((a % 360) + 360) % 360;
  const sind = a => Math.sin(a * D2R), cosd = a => Math.cos(a * D2R);
  const jd = date => date.getTime() / 86400000 + 2440587.5;
  const fromJd = j => new Date((j - 2440587.5) * 86400000);

  /* Sun: Astronomical Almanac low-precision formulae (≈0.01°) */
  function sun(j) {
    const d = j - 2451545.0;
    const L = norm(280.460 + 0.9856474 * d), g = norm(357.528 + 0.9856003 * d);
    return { lon: norm(L + 1.915 * sind(g) + 0.020 * sind(2 * g)), lat: 0, R: 1.00014 - 0.01671 * cosd(g) - 0.00014 * cosd(2 * g) };
  }
  const obliquity = j => 23.439 - 0.0000004 * (j - 2451545.0);

  /* Moon: Astronomical Almanac low-precision formulae (≈0.3°) */
  function moon(j) {
    const T = (j - 2451545.0) / 36525;
    const lon = norm(218.32 + 481267.881 * T + 6.29 * sind(135.0 + 477198.87 * T) - 1.27 * sind(259.3 - 413335.36 * T)
      + 0.66 * sind(235.7 + 890534.22 * T) + 0.21 * sind(269.9 + 954397.74 * T) - 0.19 * sind(357.5 + 35999.05 * T) - 0.11 * sind(186.5 + 966404.03 * T));
    const lat = 5.13 * sind(93.3 + 483202.02 * T) + 0.28 * sind(228.2 + 960400.89 * T) - 0.28 * sind(318.3 + 6003.15 * T) - 0.17 * sind(217.6 - 407332.21 * T);
    const hp = 0.9508 + 0.0518 * cosd(135.0 + 477198.87 * T) + 0.0095 * cosd(259.3 - 413335.36 * T) + 0.0078 * cosd(235.7 + 890534.22 * T) + 0.0028 * cosd(269.9 + 954397.74 * T);
    return { lon, lat, distKm: 6378.14 / sind(hp), hp };
  }
  /* Phase: Meeus, Astronomical Algorithms ch. 48 (phase angle from mean elements) */
  function moonPhase(j) {
    const T = (j - 2451545.0) / 36525;
    const D = norm(297.8501921 + 445267.1114034 * T), M = norm(357.5291092 + 35999.0502909 * T), Mp = norm(134.9633964 + 477198.8675055 * T);
    const i = 180 - D - 6.289 * sind(Mp) + 2.100 * sind(M) - 1.274 * sind(2 * D - Mp) - 0.658 * sind(2 * D) - 0.214 * sind(2 * Mp) - 0.110 * sind(D);
    const illum = (1 + cosd(i)) / 2;
    const elong = norm(moon(j).lon - sun(j).lon);
    return { illum, elong, waxing: elong < 180, age: elong / 360 * 29.530588, name: phaseName(elong) };
  }
  function phaseName(e) {
    const near = (x, c) => Math.abs(((x - c + 540) % 360) - 180) < 10;
    if (near(e, 0)) return 'New moon';
    if (near(e, 90)) return 'First quarter';
    if (near(e, 180)) return 'Full moon';
    if (near(e, 270)) return 'Last quarter';
    if (e < 90) return 'Waxing crescent';
    if (e < 180) return 'Waxing gibbous';
    if (e < 270) return 'Waning gibbous';
    return 'Waning crescent';
  }
  /* Next time the Sun–Moon elongation reaches `target` degrees (0 new, 90 first quarter, 180 full, 270 last quarter) */
  function nextPhase(j0, target) {
    const f = j => ((norm(moon(j).lon - sun(j).lon) - target + 540) % 360) - 180;
    let a = j0, fa = f(a);
    for (let k = 0; k < 80; k++) {
      const b = a + 0.5, fb = f(b);
      if (fa < 0 && fb >= 0 && fb - fa < 90) {
        let lo = a, hi = b;
        for (let n = 0; n < 40; n++) { const m = (lo + hi) / 2; f(m) < 0 ? lo = m : hi = m; }
        return (lo + hi) / 2;
      }
      a = b; fa = fb;
    }
    return NaN;
  }

  /* Planets: JPL "Approximate Positions of the Planets" (Standish), Table 1, valid 1800–2050 */
  const EL = {
    mercury: [0.38709927, 0.20563593, 7.00497902, 252.25032350, 77.45779628, 48.33076593, 0.00000037, 0.00001906, -0.00594749, 149472.67411175, 0.16047689, -0.12534081],
    venus:   [0.72333566, 0.00677672, 3.39467605, 181.97909950, 131.60246718, 76.67984255, 0.00000390, -0.00004107, -0.00078890, 58517.81538729, 0.00268329, -0.27769418],
    earth:   [1.00000261, 0.01671123, -0.00001531, 100.46457166, 102.93768193, 0.0, 0.00000562, -0.00004392, -0.01294668, 35999.37244981, 0.32327364, 0.0],
    mars:    [1.52371034, 0.09339410, 1.84969142, -4.55343205, -23.94362959, 49.55953891, 0.00001847, 0.00007882, -0.00813131, 19140.30268499, 0.44441088, -0.29257343],
    jupiter: [5.20288700, 0.04838624, 1.30439695, 34.39644051, 14.72847983, 100.47390909, -0.00011607, -0.00013253, -0.00183714, 3034.74612775, 0.21252668, 0.20469106],
    saturn:  [9.53667594, 0.05386179, 2.48599187, 49.95424423, 92.59887831, 113.66242448, -0.00125060, -0.00050991, 0.00193609, 1222.49362201, -0.41897216, -0.28867794],
    uranus:  [19.18916464, 0.04725744, 0.77263783, 313.23810451, 170.95427630, 74.01692503, -0.00196176, -0.00004397, -0.00242939, 428.48202785, 0.40805281, 0.04240589],
    neptune: [30.06992276, 0.00859048, 1.77004347, -55.12002969, 44.96476227, 131.78422574, 0.00026291, 0.00005105, 0.00035372, 218.45945325, -0.32241464, -0.00508664],
  };
  function helio(name, j) {
    const T = (j - 2451545.0) / 36525, e0 = EL[name];
    const a = e0[0] + e0[6] * T, e = e0[1] + e0[7] * T, I = e0[2] + e0[8] * T, L = e0[3] + e0[9] * T, wb = e0[4] + e0[10] * T, Om = e0[5] + e0[11] * T;
    const w = wb - Om, M = norm(L - wb) * D2R;
    let E = M + e * Math.sin(M);
    for (let n = 0; n < 12; n++) E -= (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
    const xp = a * (Math.cos(E) - e), yp = a * Math.sqrt(1 - e * e) * Math.sin(E);
    const cw = cosd(w), sw = sind(w), cO = cosd(Om), sO = sind(Om), cI = cosd(I), sI = sind(I);
    return {
      x: (cw * cO - sw * sO * cI) * xp + (-sw * cO - cw * sO * cI) * yp,
      y: (cw * sO + sw * cO * cI) * xp + (-sw * sO + cw * cO * cI) * yp,
      z: (sw * sI) * xp + (cw * sI) * yp,
    };
  }
  function geo(name, j) {
    const p = helio(name, j), e = helio('earth', j);
    const x = p.x - e.x, y = p.y - e.y, z = p.z - e.z, d = Math.hypot(x, y, z);
    return { lon: norm(Math.atan2(y, x) * R2D), lat: Math.asin(z / d) * R2D, dist: d, r: Math.hypot(p.x, p.y, p.z) };
  }

  /* Coordinates */
  function eclToEq(lon, lat, j) {
    const eps = obliquity(j);
    const ra = Math.atan2(sind(lon) * cosd(eps) - Math.tan(lat * D2R) * sind(eps), cosd(lon));
    const dec = Math.asin(sind(lat) * cosd(eps) + cosd(lat) * sind(eps) * sind(lon));
    return { ra: norm(ra * R2D), dec: dec * R2D };
  }
  const gmst = j => norm(280.46061837 + 360.98564736629 * (j - 2451545.0));
  function altAz(ra, dec, j, latDeg, lonDeg) {
    const H = norm(gmst(j) + lonDeg - ra);
    const alt = Math.asin(sind(latDeg) * sind(dec) + cosd(latDeg) * cosd(dec) * cosd(H)) * R2D;
    const A = Math.atan2(sind(H), cosd(H) * sind(latDeg) - Math.tan(dec * D2R) * cosd(latDeg)) * R2D;
    return { alt, az: norm(A + 180) };
  }
  function bodyAltAz(name, j, lat, lon) {
    let ecl, extra = {};
    if (name === 'sun') ecl = sun(j);
    else if (name === 'moon') { ecl = moon(j); extra.distKm = ecl.distKm; }
    else ecl = geo(name, j);
    const eq = eclToEq(ecl.lon, ecl.lat, j);
    const h = altAz(eq.ra, eq.dec, j, lat, lon);
    if (name === 'moon') h.alt -= Math.asin(6378.14 / ecl.distKm * Math.cos(h.alt * D2R)) * R2D; // topocentric parallax
    return { ...h, ...eq, lon: ecl.lon, ...extra };
  }
  const elongation = (name, j) => { const s = sun(j).lon, l = name === 'moon' ? moon(j).lon : geo(name, j).lon; return Math.abs(((l - s + 540) % 360) - 180); };
  const compass = az => ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round(norm(az) / 45) % 8];

  /* Galilean moons: Meeus ch. 44, lower-accuracy method. X in Jupiter radii, positive toward the west. */
  function galilean(j) {
    const d = j - 2451545.0;
    const V = 172.74 + 0.00111588 * d, M = 357.529 + 0.9856003 * d;
    const N = 20.020 + 0.0830853 * d + 0.329 * sind(V), J = 66.115 + 0.9025179 * d - 0.329 * sind(V);
    const A = 1.915 * sind(M) + 0.020 * sind(2 * M), B = 5.555 * sind(N) + 0.168 * sind(2 * N);
    const K = J + A - B;
    const R = 1.00014 - 0.01671 * cosd(M) - 0.00014 * cosd(2 * M);
    const r = 5.20872 - 0.25208 * cosd(N) - 0.00611 * cosd(2 * N);
    const Dl = Math.sqrt(r * r + R * R - 2 * r * R * cosd(K));
    const psi = Math.asin(R / Dl * sind(K)) * R2D;
    const t = d - Dl / 173;
    let u1 = 163.8069 + 203.4058646 * t + psi - B, u2 = 358.4140 + 101.2916335 * t + psi - B;
    let u3 = 5.7176 + 50.2345180 * t + psi - B, u4 = 224.8092 + 21.4879800 * t + psi - B;
    const G = 331.18 + 50.310482 * t, H = 87.45 + 21.569231 * t;
    const c1 = 0.473 * sind(2 * (u1 - u2)), c2 = 1.065 * sind(2 * (u2 - u3)), c3 = 0.165 * sind(G), c4 = 0.843 * sind(H);
    const r1 = 5.9057 - 0.0244 * cosd(2 * (u1 - u2)), r2 = 9.3966 - 0.0882 * cosd(2 * (u2 - u3)), r3 = 14.9883 - 0.0216 * cosd(G), r4 = 26.3627 - 0.1939 * cosd(H);
    u1 += c1; u2 += c2; u3 += c3; u4 += c4;
    const mk = (n, r_, u) => ({ name: n, x: r_ * sind(u), behind: cosd(u) < 0 });
    return [mk('Io', r1, u1), mk('Europa', r2, u2), mk('Ganymede', r3, u3), mk('Callisto', r4, u4)];
  }

  /* Sky-watching data */
  const ECLIPSES = [ // NASA GSFC eclipse catalogue (Espenak & Meeus), dates UT
    { date: '2026-02-17', kind: 'solar', type: 'annular', where: 'Antarctica only' },
    { date: '2026-03-03', kind: 'lunar', type: 'total', where: 'Night side of Earth: East Asia, Australia, the Pacific, the Americas' },
    { date: '2026-08-12', kind: 'solar', type: 'total', where: 'Greenland, Iceland, Spain' },
    { date: '2026-08-28', kind: 'lunar', type: 'partial', where: 'Night side of Earth: the Americas, Europe, Africa' },
    { date: '2027-02-06', kind: 'solar', type: 'annular', where: 'South Pacific, Chile, Argentina, Uruguay, South Atlantic' },
    { date: '2027-02-20', kind: 'lunar', type: 'penumbral', where: 'Wherever the Moon is up; a subtle dimming' },
    { date: '2027-07-18', kind: 'lunar', type: 'penumbral', where: 'Barely grazes the shadow; practically invisible' },
    { date: '2027-08-02', kind: 'solar', type: 'total', where: 'Spain, Morocco, Egypt, Saudi Arabia, Yemen' },
    { date: '2027-08-17', kind: 'lunar', type: 'penumbral', where: 'Wherever the Moon is up; a subtle dimming' },
    { date: '2028-01-12', kind: 'lunar', type: 'partial', where: 'Wherever the Moon is up' },
    { date: '2028-01-26', kind: 'solar', type: 'annular', where: 'Ecuador, Peru, Brazil, North Atlantic, Portugal, Spain' },
    { date: '2028-07-06', kind: 'lunar', type: 'partial', where: 'Wherever the Moon is up' },
    { date: '2028-07-22', kind: 'solar', type: 'total', where: 'Indian Ocean, Australia, New Zealand' },
    { date: '2028-12-31', kind: 'lunar', type: 'total', where: 'Wherever the Moon is up' },
  ];
  const SHOWERS = [ // International Meteor Organization shower calendar (typical dates; peaks shift by about a day year to year)
    { name: 'Quadrantids', peak: [1, 3], active: 'Dec 28 – Jan 12', zhr: 110, parent: 'asteroid 2003 EH1', radiant: 'Boötes', note: 'Sharp peak lasting only a few hours.' },
    { name: 'Lyrids', peak: [4, 22], active: 'Apr 14 – Apr 30', zhr: 18, parent: 'comet C/1861 G1 (Thatcher)', radiant: 'Lyra', note: 'One of the oldest recorded showers, seen for about 2,700 years.' },
    { name: 'Eta Aquariids', peak: [5, 6], active: 'Apr 19 – May 28', zhr: 50, parent: "Halley's Comet (1P/Halley)", radiant: 'Aquarius', note: 'Best from the Southern Hemisphere, before dawn.' },
    { name: 'Southern Delta Aquariids', peak: [7, 30], active: 'Jul 12 – Aug 23', zhr: 25, parent: 'probably comet 96P/Machholz', radiant: 'Aquarius', note: 'A long, steady shower; best from southern latitudes.' },
    { name: 'Perseids', peak: [8, 12], active: 'Jul 17 – Aug 24', zhr: 100, parent: 'comet 109P/Swift–Tuttle', radiant: 'Perseus', note: 'Bright, fast meteors on warm northern summer nights.' },
    { name: 'Draconids', peak: [10, 8], active: 'Oct 6 – Oct 10', zhr: 10, parent: 'comet 21P/Giacobini–Zinner', radiant: 'Draco', note: 'Usually weak, but has produced rare outbursts. Best in the evening.' },
    { name: 'Orionids', peak: [10, 21], active: 'Oct 2 – Nov 7', zhr: 20, parent: "Halley's Comet (1P/Halley)", radiant: 'Orion', note: 'Dust from Halley, crossed a second time each year.' },
    { name: 'Leonids', peak: [11, 17], active: 'Nov 6 – Nov 30', zhr: 15, parent: 'comet 55P/Tempel–Tuttle', radiant: 'Leo', note: 'Famous for meteor storms roughly every 33 years; none expected soon.' },
    { name: 'Geminids', peak: [12, 14], active: 'Dec 4 – Dec 20', zhr: 150, parent: 'asteroid 3200 Phaethon', radiant: 'Gemini', note: 'Usually the strongest shower of the year, visible most of the night.' },
    { name: 'Ursids', peak: [12, 22], active: 'Dec 17 – Dec 26', zhr: 10, parent: 'comet 8P/Tuttle', radiant: 'Ursa Minor', note: 'A modest shower near the December solstice; northern sky.' },
  ];
  const STARS = [ // brightest stars, J2000 RA/Dec in degrees, visual magnitude
    ['Sirius', 101.287, -16.716, -1.46], ['Canopus', 95.988, -52.696, -0.74], ['Rigil Kentaurus', 219.902, -60.834, -0.27], ['Arcturus', 213.915, 19.182, -0.05],
    ['Vega', 279.235, 38.784, 0.03], ['Capella', 79.172, 45.998, 0.08], ['Rigel', 78.634, -8.202, 0.13], ['Procyon', 114.825, 5.225, 0.34], ['Achernar', 24.429, -57.237, 0.46],
    ['Betelgeuse', 88.793, 7.407, 0.5], ['Hadar', 210.956, -60.373, 0.61], ['Altair', 297.696, 8.868, 0.76], ['Acrux', 186.650, -63.099, 0.76], ['Aldebaran', 68.980, 16.509, 0.86],
    ['Antares', 247.352, -26.432, 0.96], ['Spica', 201.298, -11.161, 0.97], ['Pollux', 116.329, 28.026, 1.14], ['Fomalhaut', 344.413, -29.622, 1.16], ['Deneb', 310.358, 45.280, 1.25],
    ['Regulus', 152.093, 11.967, 1.35], ['Polaris', 37.955, 89.264, 1.98],
  ];
  function orbitPoints(name, j, n = 180) {
    const T = (j - 2451545.0) / 36525, e0 = EL[name];
    const a = e0[0] + e0[6] * T, e = e0[1] + e0[7] * T, I = e0[2] + e0[8] * T, wb = e0[4] + e0[10] * T, Om = e0[5] + e0[11] * T, w = wb - Om;
    const cw = cosd(w), sw = sind(w), cO = cosd(Om), sO = sind(Om), cI = cosd(I), pts = [];
    for (let k = 0; k <= n; k++) {
      const E = 2 * Math.PI * k / n, xp = a * (Math.cos(E) - e), yp = a * Math.sqrt(1 - e * e) * Math.sin(E);
      pts.push([(cw * cO - sw * sO * cI) * xp + (-sw * cO - cw * sO * cI) * yp, (cw * sO + sw * cO * cI) * xp + (-sw * sO + cw * cO * cI) * yp, sw * sind(I) * xp + cw * sind(I) * yp]);
    }
    return pts;
  }
  function elements(name, j) {
    const T = (j - 2451545.0) / 36525, e0 = EL[name];
    return { a: e0[0] + e0[6] * T, e: e0[1] + e0[7] * T, I: e0[2] + e0[8] * T };
  }
  return { orbitPoints, elements, D2R, R2D, norm, sind, cosd, jd, fromJd, sun, moon, moonPhase, nextPhase, helio, geo, eclToEq, gmst, altAz, bodyAltAz, elongation, compass, galilean, ECLIPSES, SHOWERS, STARS };
})();
if (typeof module !== 'undefined') module.exports = ASTRO;
