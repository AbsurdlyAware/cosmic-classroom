/* ---------- AI Space Tutor ---------- */
const Tutor = (() => {
'use strict';
const ROOT = document.getElementById('view-tutor');
const $ = (s, el = ROOT) => el.querySelector(s);
const { esc, PRODUCT_NAME, byId } = APP;
const LEVELS = {
  beginner: 'a curious beginner with no science background: plain words, everyday comparisons, no equations',
  student: 'a school or early university student: clear explanations, simple numbers and at most one equation',
  advanced: 'an advanced learner: precise terminology, equations in plain text, and pointers to the relevant physics',
};
const LAB_IDS = { orbits: 'Gravity and orbits lab', transits: 'Exoplanet transit lab' };

function library() {
  const parts = CONTENT.LESSONS.map(l => [
    `LESSON ${l.id} (Level ${l.level}, ${l.category}): ${l.title}`,
    ...l.concepts.map(c => `- ${c.h}: ${c.p}`),
    ...l.misconceptions.map(m => `- Misconception: ${m.myth} Correction: ${m.fact}`),
    `- Sources: ${l.sources.join(', ')}`,
  ].join('\n'));
  const src = Object.entries(CONTENT.SOURCES).map(([id, s]) => `SOURCE ${id}: ${s.cite}`).join('\n');
  const labs = 'LAB orbits: Newtonian two-body orbit simulation with velocity Verlet, Kepler prediction overlay and conservation checks.\nLAB transits: uniform-disk transit model with depth, duration, noise and a measurement activity.';
  return parts.join('\n\n') + '\n\n' + src + '\n\n' + labs;
}
function rules(level, lessonId) {
  return `You are the AI Space Tutor inside ${PRODUCT_NAME}, a space-science learning site. Your job is accurate, evidence-based teaching.

The learner is ${LEVELS[level]}.${lessonId && byId[lessonId] ? `\nThey just studied lesson ${lessonId}, "${byId[lessonId].title}".` : ''}

Rules:
1. Be scientifically accurate. Separate established science from active research, and say plainly when something is uncertain or unknown.
2. When the LIBRARY below covers the question, base your answer on it and list the lesson and source IDs you used.
3. If you go beyond the library, you may use general astronomy knowledge, but never invent citations, papers, URLs, or precise numbers you are unsure of.
4. Astrology is not astronomy: explain the difference if asked, and never make astrological predictions.
5. Keep it short: two to four short paragraphs, or a brief list. Write equations in plain text, like v = sqrt(GM/r).
6. If the question is not about space or physics, say briefly that you only cover space science.
7. Do not use headings or tables.

End every answer with a line containing only three hyphens, then exactly these three lines:
Confidence: established, likely or uncertain
Library: comma-separated LESSON and SOURCE IDs you relied on, or none
Next: one lesson ID or lab ID (orbits or transits) worth trying next, or none

LIBRARY:
${library()}`;
}

/* tiny, safe markdown: paragraphs, lists, bold, italics, code */
function md(text) {
  const inline = s => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>');
  const blocks = text.trim().split(/\n\s*\n/);
  return blocks.map(b => {
    const lines = b.split('\n');
    if (lines.every(l => /^\s*[-*•]\s+/.test(l))) return '<ul>' + lines.map(l => `<li>${inline(l.replace(/^\s*[-*•]\s+/, ''))}</li>`).join('') + '</ul>';
    if (lines.every(l => /^\s*\d+[.)]\s+/.test(l))) return '<ol>' + lines.map(l => `<li>${inline(l.replace(/^\s*\d+[.)]\s+/, ''))}</li>`).join('') + '</ol>';
    return `<p>${lines.map(inline).join('<br>')}</p>`;
  }).join('');
}
function split(text) {
  const i = text.search(/\n\s*---\s*(\n|$)/);
  if (i < 0) return { body: text, meta: null };
  const body = text.slice(0, i), metaTxt = text.slice(i).replace(/^\s*---\s*/, '');
  const get = k => { const m = metaTxt.match(new RegExp('^\\s*' + k + '\\s*:\\s*(.+)$', 'im')); return m ? m[1].trim() : ''; };
  return { body, meta: { conf: get('Confidence').toLowerCase(), lib: get('Library'), next: get('Next') } };
}
function metaHtml(meta) {
  if (!meta) return '';
  const conf = ['established', 'likely', 'uncertain'].find(c => meta.conf.includes(c));
  const ids = meta.lib.split(/[,;\s]+/).map(s => s.replace(/^(LESSON|SOURCE)\s*/i, '').trim()).filter(Boolean);
  const lessons = ids.filter(id => byId[id]), sources = ids.filter(id => CONTENT.SOURCES[id]);
  const dropped = ids.filter(id => !byId[id] && !CONTENT.SOURCES[id] && !/^none$/i.test(id));
  const nextId = (meta.next.match(/[A-Z0-9]+-[A-Z]+-\d+|orbits|transits/) || [])[0];
  const nextLink = nextId && byId[nextId] ? `<a href="#/learn/${nextId}">${esc(byId[nextId].title)}</a>` : nextId && LAB_IDS[nextId] ? `<a href="#/labs/${nextId}">${LAB_IDS[nextId]}</a>` : '';
  let h = '<div class="msg-meta">';
  if (conf) h += `<div>Confidence: <span class="conf" data-c="${conf}">${conf[0].toUpperCase() + conf.slice(1)}</span></div>`;
  if (lessons.length || sources.length) {
    h += `<div><b>From this site:</b> ${[...lessons.map(id => `<a href="#/learn/${id}">${esc(byId[id].title)}</a>`), ...sources.map(id => esc(CONTENT.SOURCES[id].cite.split(':')[0]))].join('; ')}</div>`;
  } else h += '<div>Not drawn from this site\'s lessons. Treat it as a general explanation and check a textbook for details.</div>';
  if (dropped.length) h += `<div>Removed ${dropped.length} reference${dropped.length > 1 ? 's' : ''} that ${dropped.length > 1 ? "aren't" : "isn't"} in the site's library.</div>`;
  if (nextLink) h += `<div><b>Try next:</b> ${nextLink}</div>`;
  return h + '</div>';
}

const turns = [];
let sample = null, ctl = null, busy = false, level = 'beginner', lessonCtx = null, ready = false;
function addMsg(role, html) {
  const li = document.createElement('li'); li.className = 'msg ' + (role === 'user' ? 'me' : 'ai'); li.innerHTML = html;
  $('#tu-chat').appendChild(li); li.scrollIntoView({ block: 'nearest', behavior: 'auto' }); return li;
}
function setBusy(on) {
  busy = on; $('#tu-send').hidden = on; $('#tu-stop').hidden = !on; $('#tu-input').disabled = on;
}
const ERR = {
  not_granted: 'The tutor needs your permission to use Claude. You can allow it from this page\'s permissions.',
  sampling_disabled: 'Claude isn\'t available for this account, so the tutor is off. Lessons and labs still work.',
  rate_limited: 'Too many questions in a short time. Wait a minute, then ask again.',
  session_expired: 'Your session expired. Sign in again to use the tutor.',
  refused: 'The tutor can\'t answer that one. Try asking it a different way.',
  prompt_too_large: 'This conversation is too long. Start a new one.',
};
async function ask(q) {
  if (!sample || busy || !q.trim()) return;
  $('#tu-starters').hidden = true;
  addMsg('user', esc(q));
  turns.push({ role: 'user', content: q });
  while (turns.length > 12) turns.splice(0, 2);
  const bubble = addMsg('ai', '<p class="thinking">Thinking…</p>');
  setBusy(true); ctl = new AbortController();
  try {
    const { text } = await sample([{ role: 'user', content: rules(level, lessonCtx) }, ...turns], {
      cache: false, signal: ctl.signal,
      onText: ({ text }) => { bubble.innerHTML = md(split(text).body); },
    });
    const { body, meta } = split(text);
    bubble.innerHTML = md(body) + metaHtml(meta);
    turns.push({ role: 'assistant', content: text });
  } catch (e) {
    const code = e && e.code;
    if (code === 'cancelled') { bubble.innerHTML = (e.text ? md(split(e.text).body) : '') + '<p class="thinking">Stopped.</p>'; if (e.text) turns.push({ role: 'assistant', content: e.text }); else turns.pop(); }
    else {
      bubble.innerHTML = (e && e.text && code !== 'refused' ? md(split(e.text).body) : '') + `<p class="thinking">${esc(ERR[code] || 'Something went wrong reaching Claude. Try again in a moment.')}</p>`;
      turns.pop();
      if (code === 'not_granted' || code === 'sampling_disabled') disable(ERR[code]);
    }
  } finally { setBusy(false); $('#tu-input').focus({ preventScroll: true }); }
}
function disable(msg) { ready = false; $('#tu-input').disabled = true; $('#tu-send').disabled = true; $('#tu-status').textContent = msg; $$starters().forEach(b => b.disabled = true); }
const $$starters = () => Array.from(ROOT.querySelectorAll('.starter'));

function init() {
  $('#tu-form').addEventListener('submit', e => { e.preventDefault(); const v = $('#tu-input').value; $('#tu-input').value = ''; ask(v); });
  $('#tu-input').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('#tu-form').requestSubmit(); } });
  $('#tu-stop').addEventListener('click', () => ctl && ctl.abort());
  $('#tu-starters').addEventListener('click', e => { const b = e.target.closest('.starter'); if (b && ready) ask(b.textContent); });
  ROOT.querySelectorAll('input[name="tu-level"]').forEach(i => i.addEventListener('change', () => { level = i.value; }));
  $('#tu-new').addEventListener('click', () => { if (busy && ctl) ctl.abort(); turns.length = 0; $('#tu-chat').innerHTML = ''; $('#tu-starters').hidden = false; });
  $('#tu-input').disabled = true; $('#tu-send').disabled = true;
  $('#tu-status').textContent = 'Connecting to Claude…';
  const use = window.claude && typeof window.claude.use === 'function' ? window.claude.use('sample') : Promise.resolve(null);
  use.then(fn => {
    if (!fn) { disable(document.documentElement.classList.contains('public') ? 'The AI tutor is not part of the public version of this site yet. It needs a server that can keep an API key secret. Lessons, labs and Explore all work.' : 'The tutor works when this page is opened in claude.ai or the Claude app. Lessons and labs work everywhere.'); return; }
    sample = fn; ready = true;
    $('#tu-input').disabled = false; $('#tu-send').disabled = false; $$starters().forEach(b => b.disabled = false);
    $('#tu-status').textContent = 'Answers use your own Claude usage. The first question asks your permission.';
  }).catch(() => disable('The tutor could not connect. Lessons and labs still work.'));
}
init();
return {
  enter() {
    const m = location.hash.match(/lesson=([A-Z0-9-]+)/);
    lessonCtx = m && byId[m[1]] ? m[1] : null;
    $('#tu-context').textContent = lessonCtx ? `Context: you just studied "${byId[lessonCtx].title}". The tutor knows that.` : '';
    $('#tu-context').hidden = !lessonCtx;
  },
};
})();
APP.HOOKS.tutor = Tutor;
