const OrbitLab = (() => {
'use strict';
const P = PHYS;
const ROOT = document.getElementById('view-orbits');
const $ = (s, el = ROOT) => el.querySelector(s);
const $$ = (s, el = ROOT) => Array.from(el.querySelectorAll(s));
let active = false, startedOnce = false;
const TAU = Math.PI * 2;
const reduceMotion = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);


const DEFAULTS = () => ({ mass: 1, r0: 1, v0: P.circularSpeedKms(1, 1), angle: 0, integrator: 'verlet', dtDays: 'auto', viewR: null });

const EXPERIMENTS = [
  { id: 'distance', title: 'Move Earth twice as far out', law: "Kepler's third law",
    setup: 'Earth circles the Sun at 1 AU once a year. This puts it at 2 AU, moving at the circular speed for that distance.',
    q: 'How long will one orbit take?', options: ['2 years', 'About 2.8 years', '4 years'], answer: 1,
    explain: 'Period grows with distance to the 3/2 power, so 2<sup>1.5</sup> ≈ 2.83 years. The path is twice as long and the planet moves more slowly: 21.1 km/s instead of 29.8. After one orbit, the Data tab shows the measured period next to Kepler\'s prediction.',
    cfg: { mass: 1, r0: 2, v0: 'circ', angle: 0 }, show: { wedges: false } },
  { id: 'fastest', title: 'Where does an orbit go fastest?', law: "Kepler's second law",
    setup: 'Launch from 1 AU at 22 km/s, slower than the 29.8 km/s a circle needs. Each shaded wedge covers the same stretch of time.',
    q: 'Where will the planet move fastest?', options: ['Farthest from the star', 'Closest to the star', 'Same speed all the way round'], answer: 1,
    explain: 'It speeds up as it falls toward the star, reaching nearly 59 km/s at closest approach, and slows as it climbs away. Because each wedge covers the same time, the short, wide wedges near the star have the same area as the long, thin ones far out. That is Kepler\'s second law, and it follows from conservation of angular momentum.',
    cfg: { mass: 1, r0: 1, v0: 22, angle: 0 }, show: { wedges: true } },
  { id: 'escape', title: 'Launch 41% faster than a circle', law: 'Escape speed',
    setup: 'At 1 AU, circular speed is 29.8 km/s. This launches at √2 times that: 42.1 km/s.',
    q: 'What happens?', options: ['A slightly bigger ellipse', 'A huge ellipse that eventually comes back', 'It leaves and never comes back'], answer: 2,
    explain: 'At √2 times circular speed, the planet\'s kinetic energy exactly cancels its gravitational binding energy, so total energy is zero. It keeps slowing down but never turns around. The Data tab shows total energy at zero and no farthest point.',
    cfg: { mass: 1, r0: 1, v0: 'esc', angle: 0 }, show: { wedges: false } },
  { id: 'heavier', title: 'Same speed, heavier star', law: "Gravity depends on the star's mass",
    setup: 'Keep Earth at 1 AU and 29.8 km/s, but make the star four times as massive.',
    q: 'What happens to the orbit?', options: ['It stays the same circle', 'It falls inward into an ellipse', 'It gets flung outward'], answer: 1,
    explain: 'Circular speed grows with the square root of the star\'s mass, so a circle at 1 AU around 4 M☉ needs 59.6 km/s. At 29.8 km/s the planet is too slow: it falls inward, and its starting point becomes the farthest point of an ellipse that dips to 0.14 AU. The planet\'s own mass never enters the calculation.',
    cfg: { mass: 4, r0: 1, v0: 29.78, angle: 0 }, show: { wedges: false } },
  { id: 'euler', title: 'Does the calculation method matter?', law: 'Numerical methods',
    setup: "Same circular Earth orbit, but calculated with Euler's method, the simplest possible approach, using 1-day steps.",
    q: 'Over the next few orbits, what will the simulated planet do?', options: ['Stay on the dashed orbit', 'Spiral slowly outward', 'Spiral slowly inward'], answer: 1,
    explain: 'Each Euler step moves the planet in a straight line using the velocity it had at the start of the step, which always lands slightly outside the true curve. That adds a little energy every step, so the orbit grows. In the Data tab, energy, period and equal areas all fail their checks.',
    cfg: { mass: 1, r0: 1, v0: 'circ', angle: 0, integrator: 'euler', dtDays: 1, viewR: 2.1 }, show: { wedges: false }, playback: 2, compare: true },
];

const S = {
  cfg: DEFAULTS(), sim: null, running: false, playback: 1,
  show: { pred: true, wedges: false, arrows: true },
  view: { zoom: 1, cx: 0, cy: 0, baseR: 1.12 },
  dirty: true, tab: 'exp', activeExp: null, ended: false,
};

/* ---------- formatting ---------- */
const SUP = { '0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹','-':'⁻' };
function fmtSci(x) {
  if (!isFinite(x)) return '—';
  if (x === 0) return '0';
  if (x >= 0.01) return String(Number(x.toPrecision(2)));
  const e = Math.floor(Math.log10(x)); let m = x / Math.pow(10, e);
  if (m >= 9.95) { m = 1; }
  return `${m.toFixed(1)} × 10${String(e).split('').map(c => SUP[c] || c).join('')}`;
}
const trimNum = x => String(Number(x.toPrecision(6)));
function fmtAU(x) { if (!isFinite(x)) return '—'; return (x >= 10 ? x.toFixed(1) : x >= 0.1 ? x.toFixed(2) : x.toPrecision(2)) + ' AU'; }
function fmtTime(t) { return t < 2 ? `${(t * 365.25).toFixed(1)} days` : `${t.toFixed(2)} years`; }
function fmtPeriod(T, precise) {
  if (!isFinite(T)) return '—';
  if (T < 2) return `${(T * 365.25).toFixed(precise ? 2 : 1)} days`;
  return `${T.toPrecision(precise ? 6 : 4)} years`;
}
const kms = v => `${v.toFixed(1)} km/s`;
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));

/* ---------- orbit description ---------- */
function orbitType(s) {
  const { el } = s;
  if (s.cfg.v0 < 1e-6) return { key: 'radial', label: 'Straight fall' };
  if (Math.abs(el.E) / s.Enorm < 0.0025) return { key: 'parabola', label: 'Parabola (escape speed)' };
  if (el.E > 0) return { key: 'hyperbola', label: 'Hyperbola (escapes)' };
  if (el.e < 0.005) return { key: 'circle', label: 'Circle' };
  return { key: 'ellipse', label: 'Ellipse' };
}

function storyText(s) {
  const c = s.cfg, el = s.el;
  const vc = P.circularSpeedKms(c.mass, c.r0), ve = P.escapeSpeedKms(c.mass, c.r0);
  const q = c.v0 / vc, tilted = Math.abs(c.angle) >= 1;
  const type = orbitType(s).key;
  let t = '';
  if (s.impacted) {
    t = `The planet hit the star after ${fmtTime(s.t)}. Its closest approach (${fmtAU(Math.max(el.rp, 0))}) was inside the star's surface.`;
  } else if (type === 'radial') {
    t = 'With no sideways speed, nothing stops the fall. The planet drops straight into the star, speeding up all the way.';
  } else if (type === 'circle' && c.integrator === 'euler') {
    t = `${kms(c.v0)} is the circular speed here, so the exact solution (dashed) is a circle whose distance never changes. Euler's method gets this wrong: watch the solid trail spiral outward, gaining energy every step.`;
  } else if (type === 'circle') {
    t = `At ${kms(c.v0)}, the planet's sideways motion exactly keeps pace with its fall toward the star, so its distance never changes. That is the circular speed at ${trimNum(c.r0)} AU from a ${trimNum(c.mass)} M☉ star.`;
  } else if (type === 'ellipse') {
    if (q < 1) t = `You launched at ${Math.round(q * 100)}% of circular speed (${kms(vc)}), so gravity wins at first. The planet falls inward, speeds up near the star, swings around and climbs back out, slowing as it goes.`;
    else t = `You launched faster than circular speed (${kms(vc)}) but below escape speed (${kms(ve)}). The planet climbs outward, slows, and falls back.`;
    if (!tilted) t += q < 1 ? ' Your starting point is the farthest point of the orbit.' : ' Your starting point is the closest point of the orbit.';
    else t += ' Because the launch is tilted, the starting point is neither the closest nor the farthest point.';
  } else if (type === 'parabola') {
    t = `${kms(c.v0)} is escape speed here, √2 times circular speed. Total energy is zero: the planet keeps slowing but never turns back.`;
  } else {
    t = `Above escape speed (${kms(ve)}), total energy is positive. The star bends the path but can't hold on, so the planet leaves on a hyperbola.`;
  }
  if (!s.impacted && type !== 'radial' && el.rp <= s.rStar) t += ` This path dips to ${fmtAU(el.rp)}, inside the star, so it will hit.`;
  if (c.integrator === 'euler' && type !== 'circle') t += " You're using Euler's method, so watch the solid trail drift away from the dashed prediction.";
  else if (el.bound && el.T / s.dt < 200) t += ` The time step is large: only ${Math.round(el.T / s.dt)} steps per orbit, so expect the trail to wander from the prediction.`;
  if (s.outOfView && !s.impacted) t += el.bound ? ' The planet has left the view.' : ' The planet has left the view and will not return.';
  return t;
}

/* ---------- simulation lifecycle ---------- */
// Region the orbit needs: centre (cx, cy) and radius R, in AU
function frameOf(s) {
  const el = s.el, r0 = s.cfg.r0, cap = 8 * Math.max(r0, el.rp);
  if (s.cfg.viewR) return { cx: 0, cy: 0, R: s.cfg.viewR };
  if (el.bound && el.ra <= cap && el.p > 1e-10) {
    const c = el.a * el.e;   // ellipse centre sits a·e from the star, opposite closest approach
    return { cx: -c * Math.cos(el.omega), cy: -c * Math.sin(el.omega), R: el.a };
  }
  return { cx: 0, cy: 0, R: el.bound ? Math.min(Math.max(el.ra, r0), cap) : 3 * r0 };
}
const PAD = 1.22;
function fitView() {
  const f = frameOf(S.sim);
  S.view.baseR = f.R * PAD; S.view.zoom = 1; S.view.cx = f.cx; S.view.cy = f.cy; S.dirty = true;
}
function maybeFit() {
  const f = frameOf(S.sim), R = S.view.baseR / S.view.zoom;
  const off = Math.hypot(f.cx - S.view.cx, f.cy - S.view.cy);
  if (off + f.R * 1.05 > R || f.R * PAD < 0.35 * R) fitView();
}

function restart({ fit = false, keepRunning = true } = {}) {
  const wasRunning = S.running && keepRunning;
  S.sim = P.createSim(S.cfg);
  S.sim.outOfView = false;
  S.ended = false;
  if (fit) fitView(); else maybeFit();
  setRunning(wasRunning);
  updateStatic();
  updateLive(true);
  S.dirty = true;
}

function setRunning(on) {
  if (on && S.ended) { S.sim = P.createSim(S.cfg); S.sim.outOfView = false; S.ended = false; updateStatic(); }
  S.running = on;
  $('#playLabel').textContent = on ? 'Pause' : 'Play';
  $('#playIcon').innerHTML = on ? '<path d="M4 2.5h3v11H4zM9 2.5h3v11H9z" fill="currentColor"/>' : '<path d="M4 2.5v11l9-5.5z" fill="currentColor"/>';
  updateStatus();
}

function updateStatus() {
  const s = S.sim, chip = $('#status');
  let txt, st;
  if (s.impacted) { txt = 'Hit the star'; st = 'ended'; }
  else if (s.outOfView) { txt = 'Left the view'; st = 'ended'; }
  else if (S.running) { txt = s.slowed ? 'Running, slowed for accuracy' : 'Running'; st = 'running'; }
  else { txt = s.t === 0 ? 'Ready' : 'Paused'; st = 'idle'; }
  if ($('#statusText').textContent !== txt) $('#statusText').textContent = txt;
  chip.dataset.state = st;
}

function endRun() {
  S.ended = true; setRunning(false);
  $('#story').textContent = storyText(S.sim);
  updateLive(true);
}

/* ---------- static UI (depends on starting state only) ---------- */
function updateStatic() {
  const s = S.sim, c = s.cfg, el = s.el;
  $('#story').textContent = storyText(s);
  const type = orbitType(s);
  $('#orbit').setAttribute('aria-label', `Orbit view. ${type.label}. The planet starts ${trimNum(c.r0)} AU from a ${trimNum(c.mass)} solar-mass star at ${kms(c.v0)}.`);

  // controls
  const vc = P.circularSpeedKms(c.mass, c.r0), ve = P.escapeSpeedKms(c.mass, c.r0);
  const vmax = Math.ceil(Math.max(1.6 * ve, c.v0));
  const v0el = $('#v0'); v0el.max = vmax; v0el.value = c.v0;
  $('#mass').value = c.mass; $('#r0').value = c.r0; $('#angle').value = c.angle;
  $('#massOut').textContent = `${c.mass.toFixed(1)} M☉`;
  $('#r0Out').textContent = `${c.r0.toFixed(2)} AU`;
  $('#v0Out').textContent = kms(c.v0);
  $('#angleOut').textContent = c.angle === 0 ? '0° (sideways)' : `${c.angle > 0 ? '+' : '−'}${Math.abs(c.angle)}°`;
  $('#v0Hint').textContent = `Here, circular speed is ${kms(vc)} and escape speed is ${kms(ve)}.`;
  $$('input[name="integrator"]').forEach(i => i.checked = i.value === c.integrator);
  $$('input[name="dt"]').forEach(i => i.checked = String(i.value) === String(c.dtDays));
  const dtH = $('#dtHint');
  const spo = el.bound ? el.T / s.dt : NaN;
  let h = `Auto uses ${trimNum(Number((s.dtAuto * 365.25).toPrecision(2)))} days per step for this orbit.`;
  if (isFinite(spo)) h += ` The current step gives ${spo >= 1e4 ? Math.round(spo).toLocaleString() : Math.round(spo)} steps per orbit.`;
  dtH.textContent = h;
  dtH.classList.toggle('warn', isFinite(spo) && spo < 200);
  $('#showPred').checked = S.show.pred; $('#showWedges').checked = S.show.wedges; $('#showArrows').checked = S.show.arrows;
  $('#playback').value = String(S.playback);

  // predicted values
  const conv = P.MJKG_PER_AUYR2;
  const rows = [
    ['Orbit shape', type.label],
    ['Eccentricity', type.key === 'radial' ? '1 (straight line)' : el.e.toFixed(3)],
    ['Semi-major axis', el.bound ? fmtAU(el.a) : 'Not defined, open orbit'],
    ['Closest approach', type.key === 'radial' ? 'Centre of the star' : (el.rp <= s.rStar ? `${fmtAU(el.rp)}, inside the star` : fmtAU(el.rp))],
    ['Farthest point', el.bound ? fmtAU(el.ra) : 'None, never returns'],
    ['Period', el.bound ? fmtPeriod(el.T) : 'None'],
    ['Total energy', `${(el.E * conv).toFixed(Math.abs(el.E * conv) < 10 ? 1 : 0)} MJ per kg`],
    ['Circular speed here', kms(vc)],
    ['Escape speed here', kms(ve)],
  ];
  $('#predicted').innerHTML = rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('');
}

/* ---------- live UI ---------- */
function badge(state) {
  const map = { ok: 'Holds', warn: 'Drifting', bad: 'Broken', wait: 'Waiting', na: 'Not applicable' };
  return `<span class="badge" data-s="${state}">${map[state]}</span>`;
}
function updateChecks() {
  const s = S.sim, el = s.el;
  const items = [];
  // energy
  const eS = s.maxEerr < 1e-4 ? 'ok' : s.maxEerr < 1e-2 ? 'warn' : 'bad';
  items.push(['Energy is conserved', s.steps ? eS : 'wait', s.steps ? `Largest error so far: ${fmtSci(s.maxEerr * 100)}% of the starting gravitational energy.` : 'Press Play to start measuring.']);
  // angular momentum
  if (Math.abs(s.h0) < 1e-9) items.push(['Angular momentum is conserved', 'na', 'No sideways motion, so there is no angular momentum to track.']);
  else {
    const hS = s.maxHerr < 1e-6 ? 'ok' : s.maxHerr < 1e-3 ? 'warn' : 'bad';
    items.push(['Angular momentum is conserved', s.steps ? hS : 'wait', s.steps ? `Largest error so far: ${fmtSci(s.maxHerr * 100)}%.` : 'Press Play to start measuring.']);
  }
  // period
  if (!el.bound) items.push(["Period matches Kepler's third law", 'na', 'An open orbit has no period.']);
  else if (!s.periods.length) items.push(["Period matches Kepler's third law", 'wait', `Waiting for the first full orbit. Predicted: ${fmtPeriod(el.T, true)}.`]);
  else {
    const last = s.periods[s.periods.length - 1], d = (last - el.T) / el.T, ad = Math.abs(d);
    const pS = ad < 1e-3 ? 'ok' : ad < 2e-2 ? 'warn' : 'bad';
    items.push(["Period matches Kepler's third law", pS, `Measured ${fmtPeriod(last, true)} on orbit ${s.periods.length}, predicted ${fmtPeriod(el.T, true)}. Difference: ${fmtSci(ad * 100)}%.`]);
  }
  // areas
  const ws = P.wedgeSpread(s);
  if (Math.abs(s.h0) < 1e-9) items.push(['Equal areas in equal times', 'na', 'A straight fall sweeps no area.']);
  else if (!ws) items.push(['Equal areas in equal times', 'wait', `Recording wedges of ${fmtTime(s.wedgeDt)} each.`]);
  else {
    const aS = ws.spread < 1e-3 ? 'ok' : ws.spread < 2e-2 ? 'warn' : 'bad';
    items.push(['Equal areas in equal times', aS, `Last ${ws.n} wedges of ${fmtTime(s.wedgeDt)}: areas differ by ${fmtSci(ws.spread * 100)}%.`]);
  }
  $('#checks').innerHTML = items.map(([name, st, txt]) => `<li class="check"><div class="check-head"><span>${name}</span>${badge(st)}</div><p>${txt}</p></li>`).join('');
}

function updateLive(force) {
  const s = S.sim, en = P.energyNow(s);
  const t = fmtTime(s.t);
  $('#roTime').textContent = t; $('#hudTime').textContent = t;
  $('#roDist').textContent = fmtAU(en.r);
  $('#roSpeed').textContent = kms(Math.hypot(s.vx, s.vy) * P.KMS_PER_AUYR);
  $('#roErr').textContent = `${fmtSci(s.maxEerr * 100)}%`;
  updateStatus();
  if (S.tab === 'data') { updateChecks(); drawChart(); }
}

/* ---------- drawing ---------- */
let cssCache = null;
function colors() {
  const cs = getComputedStyle(document.documentElement);
  const g = n => cs.getPropertyValue(n).trim();
  cssCache = { space: g('--space'), ring: g('--space-ring'), label: g('--space-label'), trail: g('--trail'), pred: g('--pred'),
    vel: g('--vel'), grav: g('--grav'), wa: g('--wedge-a'), wb: g('--wedge-b'), planet: g('--planet'),
    accent: g('--accent'), violet: g('--violet'), text: g('--text'), muted: g('--muted'), line: g('--line') };
  return cssCache;
}
const FONT = '"Atkinson Hyperlegible", system-ui, sans-serif';

function sizeCanvas(cv) {
  const r = cv.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  const w = Math.max(1, Math.round(r.width * dpr)), h = Math.max(1, Math.round(r.height * dpr));
  if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
  return dpr;
}
function niceStep(x) {
  const p = Math.pow(10, Math.floor(Math.log10(x))), f = x / p;
  return (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10) * p;
}
function starColor(m) {
  // rough main-sequence appearance: red dwarf → Sun-like → blue-white
  const stops = [[0.1, [255, 170, 110]], [1, [255, 242, 214]], [10, [188, 212, 255]]];
  const lm = Math.log10(clamp(m, 0.1, 10));
  const [a, b] = lm <= 0 ? [stops[0], stops[1]] : [stops[1], stops[2]];
  const t = (lm - Math.log10(a[0])) / (Math.log10(b[0]) - Math.log10(a[0]));
  return a[1].map((c, i) => Math.round(c + (b[1][i] - c) * t));
}
function arrow(ctx, x1, y1, x2, y2, color, dpr, label) {
  const ang = Math.atan2(y2 - y1, x2 - x1), hl = 7 * dpr;
  ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = 1.8 * dpr;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(ang) * hl * 0.6, y2 - Math.sin(ang) * hl * 0.6); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - hl * Math.cos(ang - 0.42), y2 - hl * Math.sin(ang - 0.42));
  ctx.lineTo(x2 - hl * Math.cos(ang + 0.42), y2 - hl * Math.sin(ang + 0.42)); ctx.closePath(); ctx.fill();
  if (label) { ctx.font = `italic 700 ${12 * dpr}px "STIX Two Text", serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(label, x2 + Math.cos(ang) * 9 * dpr, y2 + Math.sin(ang) * 9 * dpr); }
}

const cv = $('#orbit'), ctx = cv.getContext('2d');
function draw() {
  const s = S.sim; if (!s || !ctx) return;
  const C = colors(), dpr = sizeCanvas(cv), W = cv.width, H = cv.height;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = C.space; ctx.fillRect(0, 0, W, H);
  const R = S.view.baseR / S.view.zoom, k = (Math.min(W, H) / 2) / R;
  const sx = x => W / 2 + (x - S.view.cx) * k, sy = y => H / 2 - (y - S.view.cy) * k;
  const ox = sx(0), oy = sy(0);
  const far = Math.hypot(Math.max(ox, W - ox), Math.max(oy, H - oy)) / k;

  // distance rings
  const step = niceStep(R / 2.2);
  ctx.lineWidth = dpr; ctx.strokeStyle = C.ring; ctx.fillStyle = C.label;
  ctx.font = `${11 * dpr}px ${FONT}`; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
  for (let i = 1, rr = step; rr <= far && i < 60; i++, rr = i * step) {
    ctx.beginPath(); ctx.arc(ox, oy, rr * k, 0, TAU); ctx.stroke();
    const lx = ox + rr * k * Math.SQRT1_2, ly = oy - rr * k * Math.SQRT1_2;
    if (lx > 0 && lx < W - 50 * dpr && ly > 60 * dpr && ly < H - 50 * dpr) ctx.fillText(`${trimNum(rr)} AU`, lx + 4 * dpr, ly - 2 * dpr);
  }

  const el = s.el;
  // equal-time wedges
  if (S.show.wedges && Math.abs(s.h0) > 1e-9) {
    const list = s.wedges.map(w => [w.pts, w.i]);
    list.push([s.wedgePts.concat([[s.x, s.y]]), s.wedgeIndex]);
    for (const [pts, i] of list) {
      ctx.beginPath(); ctx.moveTo(ox, oy);
      for (const p of pts) ctx.lineTo(sx(p[0]), sy(p[1]));
      ctx.closePath(); ctx.fillStyle = i % 2 ? C.wb : C.wa; ctx.fill();
    }
  }

  // Kepler prediction (exact conic from the starting state)
  if (S.show.pred && el.p > 1e-10) {
    ctx.save(); ctx.setLineDash([5 * dpr, 6 * dpr]); ctx.strokeStyle = C.pred; ctx.lineWidth = 1.4 * dpr;
    ctx.beginPath();
    const N = 900, nuMax = el.e < 1 ? Math.PI : Math.acos(-1 / el.e) * 0.9995;
    let pen = false;
    for (let i = 0; i <= N; i++) {
      const nu = el.e < 1 ? (i / N) * TAU : -nuMax + (2 * nuMax * i) / N;
      const r = el.p / (1 + el.e * Math.cos(nu));
      if (!(r > 0) || r > far * 3) { pen = false; continue; }
      const a = el.omega + nu, X = sx(r * Math.cos(a)), Y = sy(r * Math.sin(a));
      if (!pen) { ctx.moveTo(X, Y); pen = true; } else ctx.lineTo(X, Y);
    }
    ctx.stroke(); ctx.restore();
    if (el.bound && el.e > 0.03) {
      ctx.font = `${11 * dpr}px ${FONT}`; ctx.textBaseline = 'middle';
      for (const [r, a, lab] of [[el.rp, el.omega, 'closest'], [el.ra, el.omega + Math.PI, 'farthest']]) {
        const X = sx(r * Math.cos(a)), Y = sy(r * Math.sin(a));
        ctx.beginPath(); ctx.arc(X, Y, 3 * dpr, 0, TAU); ctx.fillStyle = C.space; ctx.fill(); ctx.strokeStyle = C.pred; ctx.lineWidth = 1.3 * dpr; ctx.stroke();
        const dx = Math.cos(a), dy = -Math.sin(a), tw = ctx.measureText(lab).width, gap = 9 * dpr;
        const right = dx >= 0;
        const fits = right ? X + gap + tw < W - 6 * dpr : X - gap - tw > 6 * dpr;
        ctx.fillStyle = C.label;
        if (fits) {
          ctx.textAlign = right ? 'left' : 'right';
          ctx.fillText(lab, X + (right ? gap : -gap), clamp(Y + dy * gap, 10 * dpr, H - 10 * dpr));
        } else {   // no room outward: centre the label below (or above) the marker
          ctx.textAlign = 'center';
          const below = Y + 15 * dpr < H - 8 * dpr;
          ctx.fillText(lab, clamp(X, tw / 2 + 6 * dpr, W - tw / 2 - 6 * dpr), Y + (below ? 15 : -15) * dpr);
        }
      }
    }
  }

  // start marker
  { const X = sx(s.cfg.r0), Y = sy(0), m = 4 * dpr; ctx.strokeStyle = C.label; ctx.lineWidth = 1.2 * dpr;
    ctx.beginPath(); ctx.moveTo(X - m, Y); ctx.lineTo(X + m, Y); ctx.moveTo(X, Y - m); ctx.lineTo(X, Y + m); ctx.stroke(); }

  // simulated trail (older parts fade)
  const tr = s.trail;
  if (tr.length > 1) {
    ctx.lineWidth = 2 * dpr; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.strokeStyle = C.trail;
    const chunks = 10, n = tr.length;
    for (let c = 0; c < chunks; c++) {
      const a = Math.floor((n - 1) * c / chunks), b = Math.floor((n - 1) * (c + 1) / chunks);
      if (b <= a) continue;
      ctx.globalAlpha = 0.22 + 0.78 * ((c + 1) / chunks);
      ctx.beginPath(); ctx.moveTo(sx(tr[a][0]), sy(tr[a][1]));
      for (let i = a + 1; i <= b; i++) ctx.lineTo(sx(tr[i][0]), sy(tr[i][1]));
      if (c === chunks - 1) ctx.lineTo(sx(s.x), sy(s.y));
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  // star (enlarged; drawn to scale only when zoomed in enough)
  const [r_, g_, b_] = starColor(s.cfg.mass);
  const core = Math.max((5 + 2.2 * Math.log10(s.cfg.mass * 10 + 1)) * dpr, s.rStar * k);
  const glow = ctx.createRadialGradient(ox, oy, 0, ox, oy, core * 3.4);
  glow.addColorStop(0, `rgba(${r_},${g_},${b_},0.55)`); glow.addColorStop(1, `rgba(${r_},${g_},${b_},0)`);
  ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(ox, oy, core * 3.4, 0, TAU); ctx.fill();
  ctx.fillStyle = `rgb(${r_},${g_},${b_})`; ctx.beginPath(); ctx.arc(ox, oy, core, 0, TAU); ctx.fill();

  // planet + arrows
  const px = sx(s.x), py = sy(s.y);
  if (S.show.arrows && !s.impacted) {
    const v = Math.hypot(s.vx, s.vy), vc0 = Math.sqrt(s.mu / s.cfg.r0);
    if (v > 1e-9) { const L = clamp(48 * v / vc0, 10, 130) * dpr; arrow(ctx, px, py, px + s.vx / v * L, py - s.vy / v * L, C.vel, dpr, 'v'); }
    const r = Math.hypot(s.x, s.y), acc = s.mu / (r * r), a0 = s.mu / (s.cfg.r0 * s.cfg.r0);
    const Lg = Math.min(clamp(34 * Math.sqrt(acc / a0), 8, 110) * dpr, Math.max(0, r * k - core - 4 * dpr));
    if (Lg > 6 * dpr) arrow(ctx, px, py, px - s.x / r * Lg, py + s.y / r * Lg, C.grav, dpr, 'g');
  }
  if (!s.impacted) {
    ctx.fillStyle = C.planet; ctx.beginPath(); ctx.arc(px, py, 4.6 * dpr, 0, TAU); ctx.fill();
    ctx.strokeStyle = C.space; ctx.lineWidth = 1.5 * dpr; ctx.stroke();
  } else {
    ctx.strokeStyle = C.grav; ctx.lineWidth = 1.5 * dpr; ctx.beginPath(); ctx.arc(ox, oy, core + 6 * dpr, 0, TAU); ctx.stroke();
  }
}

const ch = $('#energyChart'), cctx = ch.getContext('2d');
function drawChart() {
  if (S.tab !== 'data' || !cctx) return;
  const s = S.sim, C = cssCache || colors(), dpr = sizeCanvas(ch), W = ch.width, H = ch.height;
  cctx.setTransform(1, 0, 0, 1, 0, 0); cctx.clearRect(0, 0, W, H);
  const conv = P.MJKG_PER_AUYR2;
  const en = P.energyNow(s);
  const data = s.energy.concat([[s.t, en.ke, en.pe, en.E]]);
  cctx.font = `${11 * dpr}px ${FONT}`; cctx.fillStyle = C.muted;
  if (data.length < 3 || s.t === 0) { cctx.textAlign = 'center'; cctx.textBaseline = 'middle'; cctx.fillText('Press Play to record energy over time.', W / 2, H / 2); return; }
  let lo = 0, hi = 0;
  for (const d of data) for (let j = 1; j < 4; j++) { const v = d[j] * conv; if (v < lo) lo = v; if (v > hi) hi = v; }
  const pad = (hi - lo) * 0.08 || 1; lo -= pad; hi += pad;
  const L = 52 * dpr, Rm = 8 * dpr, T = 8 * dpr, B = 20 * dpr;
  const t0 = data[0][0], t1 = data[data.length - 1][0];
  const X = t => L + (W - L - Rm) * ((t - t0) / ((t1 - t0) || 1));
  const Y = v => T + (H - T - B) * (1 - (v - lo) / (hi - lo));
  cctx.strokeStyle = C.line; cctx.lineWidth = dpr;
  cctx.beginPath(); cctx.moveTo(L, Y(0)); cctx.lineTo(W - Rm, Y(0)); cctx.stroke();
  cctx.textAlign = 'right'; cctx.textBaseline = 'middle';
  const lab = v => String(Math.round(v));
  cctx.fillText(lab(hi - pad), L - 6 * dpr, Y(hi - pad)); cctx.fillText('0', L - 6 * dpr, Y(0)); cctx.fillText(lab(lo + pad), L - 6 * dpr, Y(lo + pad));
  cctx.textAlign = 'left'; cctx.textBaseline = 'bottom';
  cctx.fillText(fmtTime(t0), L, H - 2 * dpr); cctx.textAlign = 'right'; cctx.fillText(fmtTime(t1), W - Rm, H - 2 * dpr);
  const series = [[1, C.accent, 1.6], [2, C.violet, 1.6], [3, C.text, 2.2]];
  for (const [j, col, lw] of series) {
    cctx.strokeStyle = col; cctx.lineWidth = lw * dpr; cctx.beginPath();
    data.forEach((d, i) => { const x = X(d[0]), y = Y(d[j] * conv); i ? cctx.lineTo(x, y) : cctx.moveTo(x, y); });
    cctx.stroke();
  }
}

/* ---------- experiments ---------- */
function renderExperiments() {
  $('#expList').innerHTML = EXPERIMENTS.map(e => `
    <li class="exp" id="exp-${e.id}">
      <h3>${e.title}</h3>
      <p class="law">${e.law}</p>
      <p>${e.setup}</p>
      <button class="btn btn-small" data-act="setup" data-id="${e.id}">Set up this experiment</button>
      <div class="qa" hidden>
        <p class="q" id="q-${e.id}">${e.q}</p>
        <div class="opts" role="group" aria-labelledby="q-${e.id}">
          ${e.options.map((o, i) => `<button class="opt" data-act="answer" data-id="${e.id}" data-i="${i}"><span>${o}</span><span class="mark"></span></button>`).join('')}
        </div>
        <div class="result" aria-live="polite" hidden></div>
      </div>
    </li>`).join('');
}
function resolveCfg(e) {
  const c = Object.assign(DEFAULTS(), e.cfg);
  if (c.v0 === 'circ') c.v0 = P.circularSpeedKms(c.mass, c.r0);
  if (c.v0 === 'esc') c.v0 = P.escapeSpeedKms(c.mass, c.r0);
  return c;
}
function setupExperiment(id) {
  const e = EXPERIMENTS.find(x => x.id === id); if (!e) return;
  $$('.exp').forEach(n => n.classList.remove('is-active'));
  const card = $(`#exp-${id}`); card.classList.add('is-active');
  S.activeExp = id;
  S.cfg = resolveCfg(e);
  S.show.wedges = !!(e.show && e.show.wedges);
  S.show.pred = true;
  S.playback = e.playback || 1;
  S.running = false;
  restart({ fit: true, keepRunning: false });
  const qa = $('.qa', card); qa.hidden = false;
  $$('.opt', card).forEach(b => { b.disabled = false; b.classList.remove('is-correct', 'is-wrong'); $('.mark', b).textContent = ''; });
  const res = $('.result', card); res.hidden = true; res.innerHTML = '';
  $('[data-act="setup"]', card).textContent = 'Start over';
  const first = $('.opt', card); if (first) first.focus({ preventScroll: true });
}
function answerExperiment(id, i) {
  const e = EXPERIMENTS.find(x => x.id === id), card = $(`#exp-${id}`);
  if (S.activeExp !== id) setupExperiment(id);
  const opts = $$('.opt', card);
  opts.forEach((b, j) => {
    b.disabled = true;
    if (j === e.answer) { b.classList.add('is-correct'); $('.mark', b).textContent = j === i ? 'Your answer, correct' : 'Answer'; }
    else if (j === i) { b.classList.add('is-wrong'); $('.mark', b).textContent = 'Your answer'; }
  });
  const right = i === e.answer;
  APP.Progress.prediction('orbit:' + id, right);
  const res = $('.result', card);
  res.innerHTML = `<p><span class="verdict">${right ? 'Correct.' : `Not quite. The answer is “${e.options[e.answer]}”.`}</span> ${e.explain}</p>
    <div class="row"><button class="btn btn-small btn-primary" data-act="run" data-id="${id}">Run it</button>${e.compare ? `<button class="btn btn-small" data-act="compare" data-id="${id}">Run with Velocity Verlet</button>` : ''}</div>`;
  res.hidden = false;
}
function runVisible() {
  setRunning(true);
  const vp = $('#viewport').getBoundingClientRect();
  if (vp.top < 0 || vp.bottom > window.innerHeight) $('#viewport').scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
}
$('#expList').addEventListener('click', ev => {
  const b = ev.target.closest('button[data-act]'); if (!b) return;
  const { act, id } = b.dataset;
  if (act === 'setup') setupExperiment(id);
  else if (act === 'answer') answerExperiment(id, Number(b.dataset.i));
  else if (act === 'run') { if (S.ended || S.sim.t > 0) restart({ keepRunning: false }); runVisible(); }
  else if (act === 'compare') { S.cfg.integrator = 'verlet'; S.cfg.dtDays = 'auto'; restart({ keepRunning: false }); runVisible(); }
});

/* ---------- tabs ---------- */
const tabs = $$('.tab');
function selectTab(tab) {
  tabs.forEach(t => { const on = t === tab; t.setAttribute('aria-selected', on); t.tabIndex = on ? 0 : -1; $('#' + t.getAttribute('aria-controls')).hidden = !on; });
  S.tab = tab.id.replace('tab-', '');
  if (S.tab === 'data') { updateChecks(); requestAnimationFrame(drawChart); }
}
tabs.forEach((t, i) => {
  t.addEventListener('click', () => selectTab(t));
  t.addEventListener('keydown', e => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length]; n.focus(); selectTab(n);
  });
});

/* ---------- controls ---------- */
function fromControls() { S.cfg.viewR = null; restart(); }
$('#mass').addEventListener('input', e => { S.cfg.mass = Number(e.target.value); fromControls(); });
$('#r0').addEventListener('input', e => { S.cfg.r0 = Number(e.target.value); fromControls(); });
$('#v0').addEventListener('input', e => { S.cfg.v0 = Number(e.target.value); fromControls(); });
$('#angle').addEventListener('input', e => { S.cfg.angle = Number(e.target.value); fromControls(); });
$('#setCirc').addEventListener('click', () => { S.cfg.v0 = P.circularSpeedKms(S.cfg.mass, S.cfg.r0); fromControls(); });
$('#setEsc').addEventListener('click', () => { S.cfg.v0 = P.escapeSpeedKms(S.cfg.mass, S.cfg.r0); fromControls(); });
$$('input[name="integrator"]').forEach(i => i.addEventListener('change', () => { S.cfg.integrator = i.value; fromControls(); }));
$$('input[name="dt"]').forEach(i => i.addEventListener('change', () => { S.cfg.dtDays = i.value === 'auto' ? 'auto' : Number(i.value); fromControls(); }));
$('#showPred').addEventListener('change', e => { S.show.pred = e.target.checked; S.dirty = true; });
$('#showWedges').addEventListener('change', e => { S.show.wedges = e.target.checked; S.dirty = true; });
$('#showArrows').addEventListener('change', e => { S.show.arrows = e.target.checked; S.dirty = true; });
$('#defaults').addEventListener('click', () => { S.cfg = DEFAULTS(); S.show = { pred: true, wedges: false, arrows: true }; S.playback = 1; restart({ fit: true }); });
$('#playback').addEventListener('change', e => { S.playback = Number(e.target.value); });

$('#play').addEventListener('click', () => setRunning(!S.running));
$('#resetBtn').addEventListener('click', () => restart({ keepRunning: false }));
$('#stepBtn').addEventListener('click', () => {
  if (S.ended) restart({ keepRunning: false });
  setRunning(false);
  P.advance(S.sim, S.sim.tPlay / 48);
  afterAdvance(); updateLive(true); S.dirty = true;
});

/* ---------- zoom & pan ---------- */
function zoomBy(f) { S.view.zoom = clamp(S.view.zoom * f, 0.05, 400); S.dirty = true; }
$('#zoomIn').addEventListener('click', () => zoomBy(1.6));
$('#zoomOut').addEventListener('click', () => zoomBy(1 / 1.6));
$('#zoomFit').addEventListener('click', fitView);
let drag = null;
cv.addEventListener('pointerdown', e => {
  if (e.pointerType !== 'mouse') return;
  drag = { x: e.clientX, y: e.clientY, cx: S.view.cx, cy: S.view.cy };
  cv.setPointerCapture(e.pointerId); cv.classList.add('is-dragging');
});
cv.addEventListener('pointermove', e => {
  if (!drag) return;
  const r = cv.getBoundingClientRect(), k = (Math.min(r.width, r.height) / 2) / (S.view.baseR / S.view.zoom);
  S.view.cx = drag.cx - (e.clientX - drag.x) / k; S.view.cy = drag.cy + (e.clientY - drag.y) / k; S.dirty = true;
});
const endDrag = () => { drag = null; cv.classList.remove('is-dragging'); };
cv.addEventListener('pointerup', endDrag); cv.addEventListener('pointercancel', endDrag);
cv.addEventListener('wheel', e => { if (!e.ctrlKey && !e.metaKey) return; e.preventDefault(); zoomBy(Math.exp(-e.deltaY * 0.01)); }, { passive: false });
cv.addEventListener('dblclick', fitView);

/* ---------- loop ---------- */
function afterAdvance() {
  const s = S.sim;
  if (!s.el.bound || s.cfg.integrator === 'euler') {
    const r = Math.hypot(s.x, s.y);
    if (r > 40 * Math.max(s.cfg.r0, 1)) s.outOfView = true;
  }
  if (s.escaped) s.outOfView = true;
  if ((s.impacted || s.outOfView) && !S.ended) endRun();
}
let last = performance.now(), lastUi = 0;
function frame(now) {
  const dtReal = Math.min(0.05, (now - last) / 1000); last = now;
  if (!active) { requestAnimationFrame(frame); return; }
  if (S.running && S.sim && !S.ended) {
    P.advance(S.sim, dtReal * (S.sim.tPlay / 8) * S.playback);
    afterAdvance();
    S.dirty = true;
    if (now - lastUi > 120) { updateLive(); lastUi = now; }
  }
  if (S.dirty) { draw(); S.dirty = false; }
  requestAnimationFrame(frame);
}
new ResizeObserver(() => { S.dirty = true; if (S.tab === 'data') drawChart(); }).observe($('#viewport'));
if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => { S.dirty = true; drawChart(); });

renderExperiments();
restart({ fit: true, keepRunning: false });
requestAnimationFrame(frame);
window.__lab = S;
function applyPreset(name) {
  const e = EXPERIMENTS.find(x => x.id === name);
  if (e) { selectTab($('#tab-exp')); setupExperiment(name); }
}
return {
  enter(arg) {
    active = true; APP.Progress.lab('orbits');
    S.dirty = true;
    if (arg) applyPreset(arg);
    else if (!startedOnce && !reduceMotion) setRunning(true);
    startedOnce = true;
  },
  leave() { active = false; if (S.running) setRunning(false); },
};
})();
APP.HOOKS.orbits = OrbitLab;