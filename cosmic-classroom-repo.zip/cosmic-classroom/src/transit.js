/* ---------- Transit physics (no DOM). Uniform-brightness star, circular orbit. ---------- */
const TRANSIT = (() => {
  const R_EARTH_KM = 6371.0;     // mean radius (NASA Earth Fact Sheet)
  const R_SUN_KM = 695700;       // IAU 2015 nominal solar radius
  const AU_KM = 149597870.7;     // IAU 2012
  const TAU = 2 * Math.PI;
  const clamp = (x, a, b) => Math.min(b, Math.max(a, x));

  // Area of the overlap between the star (radius 1) and a planet disk (radius k) whose centres are z apart.
  function overlap(z, k) {
    if (z >= 1 + k) return 0;
    if (z <= 1 - k) return Math.PI * k * k;          // planet fully on the disk
    if (z <= k - 1) return Math.PI;                  // planet covers the whole star
    const k2 = k * k, z2 = z * z;
    const a1 = Math.acos(clamp((z2 + 1 - k2) / (2 * z), -1, 1));
    const a2 = Math.acos(clamp((z2 + k2 - 1) / (2 * z * k), -1, 1));
    const tri = 0.5 * Math.sqrt(Math.max(0, (-z + k + 1) * (z + k - 1) * (z - k + 1) * (z + k + 1)));
    return a1 + k2 * a2 - tri;
  }
  const fluxAtZ = (z, k) => 1 - overlap(z, k) / Math.PI;

  /* p: { Ms (M☉), Rs (R☉), Rp (R⊕), P (days), b (impact parameter, stellar radii) } */
  function system(p) {
    const k = p.Rp * R_EARTH_KM / (p.Rs * R_SUN_KM);
    const Pyr = p.P / 365.25;
    const aAU = Math.cbrt(PHYS.MU_SUN * p.Ms * Pyr * Pyr / (TAU * TAU));
    const aRs = aAU * AU_KM / (p.Rs * R_SUN_KM);
    const b = Math.min(p.b, aRs * 0.999);
    const cosi = b / aRs, sini = Math.sqrt(1 - cosi * cosi);
    const transits = b < 1 + k;
    const T14 = transits ? (p.P / Math.PI) * Math.asin(Math.min(1, Math.sqrt((1 + k) ** 2 - b * b) / (aRs * sini))) : 0;
    const full = b <= 1 - k;
    const T23 = full ? (p.P / Math.PI) * Math.asin(Math.min(1, Math.sqrt((1 - k) ** 2 - b * b) / (aRs * sini))) : 0;
    const depthMax = transits ? 1 - fluxAtZ(b, k) : 0;   // deepest point (mid-transit)
    return { ...p, b, k, aAU, aRs, cosi, sini, transits, full, T14, T23,
      depthK2: k * k, depthMax, prob: (1 + k) / aRs, inclDeg: Math.acos(cosi) * 180 / Math.PI };
  }

  // Sky-plane position of the planet (in stellar radii) t days after mid-transit.
  function position(sys, t) {
    const ph = TAU * t / sys.P;
    const x = sys.aRs * Math.sin(ph), y = sys.b * Math.cos(ph);
    return { x, y, z: Math.hypot(x, y), front: Math.cos(ph) > 0 };
  }
  function flux(sys, t) { const q = position(sys, t); return q.front ? fluxAtZ(q.z, sys.k) : 1; }

  // Deterministic noise so the "observation" stays put while the animation runs
  function rng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function observe(sys, { halfWindow, cadence, sigma, seed }) {
    const r = rng(seed), pts = [];
    for (let t = -halfWindow; t <= halfWindow + 1e-12; t += cadence) {
      let n = 0;
      if (sigma > 0) { const u = Math.max(r(), 1e-12), v = r(); n = sigma * Math.sqrt(-2 * Math.log(u)) * Math.cos(TAU * v); }
      pts.push([t, flux(sys, t) + n]);
    }
    return pts;
  }

  // Independent numerical checks used by the "Model check" panel
  function measure(sys) {
    if (!sys.transits) return { depth: 0, T14: 0 };
    const half = sys.T14 * 0.75 + 1e-6, N = 20000;
    let minF = 1, first = null, last = null;
    for (let i = 0; i <= N; i++) {
      const t = -half + (2 * half * i) / N, f = flux(sys, t);
      if (f < minF) minF = f;
      if (f < 1) { if (first === null) first = t; last = t; }
    }
    // refine contacts by bisection
    const edge = (lo, hi) => { for (let j = 0; j < 60; j++) { const m = (lo + hi) / 2; (flux(sys, m) < 1) === (flux(sys, hi) < 1) ? hi = m : lo = m; } return (lo + hi) / 2; };
    const step = 2 * half / N;
    const t1 = edge(first - step, first), t4 = edge(last + step, last);
    return { depth: 1 - minF, T14: t4 - t1 };
  }

  return { R_EARTH_KM, R_SUN_KM, AU_KM, overlap, fluxAtZ, system, position, flux, observe, measure };
})();
if (typeof module !== 'undefined') module.exports = TRANSIT;
