/* ---------- Exoplanet transit lab ---------- */
const TransitLab = (() => {
'use strict';
const ROOT = document.getElementById('view-transits');
const $ = (s, el = ROOT) => el.querySelector(s);
const $$ = (s, el = ROOT) => Array.from(el.querySelectorAll(s));
const { esc, clamp, fmtDepth, TransitDraw, reduceMotion } = APP;
const T = TRANSIT;

const STARS = {
  sun: { name: 'Sun-like star', Ms: 1, Rs: 1, color: [255, 242, 214], note: '1 M☉, 1 R☉' },
  red: { name: 'Red dwarf', Ms: 0.3, Rs: 0.3, color: [255, 176, 120], note: 'an example red dwarf: 0.3 M☉, 0.3 R☉' },
  trappist: { name: 'TRAPPIST-1', Ms: 0.0898, Rs: 0.1192, color: [255, 150, 100], note: '0.0898 M☉, 0.1192 R☉ (Agol et al. 2021)' },
};
const PLANETS = [
  { id: 'earth', label: 'Earth', Rp: 1, P: 365.25, star: 'sun' },
  { id: 'neptune', label: 'Neptune-size', Rp: 3.865, P: 60 },
  { id: 'hotjup', label: 'Hot Jupiter', Rp: 10.97, P: 3.5, star: 'sun' },
  { id: 'trappist-e', label: 'TRAPPIST-1e', Rp: 0.920, P: 6.101, star: 'trappist' },
];
const DEFAULT = () => ({ star: 'sun', Rp: 3.865, P: 60, b: 0.2, noise: 100 });

const EXPERIMENTS = [
  { id: 'wider', title: 'Make the planet twice as wide', law: 'Depth ≈ (planet radius ÷ star radius)²',
    setup: 'A Neptune-size planet crosses a Sun-like star. Next, its radius doubles.',
    q: 'How much deeper will the dip be?', options: ['Twice as deep', 'Four times as deep', 'Eight times as deep'], answer: 1,
    before: { star: 'sun', Rp: 3.865, P: 60, b: 0.2, noise: 0 }, after: { Rp: 7.73 },
    explain: 'The planet blocks light with its disk, and a disk\'s area grows with the square of its radius: double the width, four times the area, four times the dip.' },
  { id: 'smaller-star', title: 'Move Earth to a smaller star', law: 'The same planet, a different star',
    setup: 'An Earth-size planet crosses a Sun-like star. Next, the same planet crosses a red dwarf with 0.3 times the Sun\'s radius.',
    q: 'What happens to the dip?', options: ['It gets shallower', 'It stays the same', 'It gets about 11 times deeper'], answer: 2,
    before: { star: 'sun', Rp: 1, P: 20, b: 0.2, noise: 0 }, after: { star: 'red' },
    explain: 'The planet now covers a larger fraction of a smaller star: (1 ÷ 0.3)² ≈ 11 times deeper. Small stars are good places to look for small planets, which is how the TRAPPIST-1 worlds were found.' },
  { id: 'graze', title: 'Clip the edge of the star', law: 'Grazing transits',
    setup: 'A hot Jupiter crosses the middle of a Sun-like star. Next, its orbit tilts so it only clips the edge (impact parameter 1).',
    q: 'What will the dip look like?', options: ['Just as deep, but shorter', 'Shallower, shorter and V-shaped', 'Deeper and longer'], answer: 1,
    before: { star: 'sun', Rp: 10.97, P: 3.5, b: 0, noise: 0 }, after: { b: 1.0 },
    explain: 'Only part of the planet ever covers the star, so less light is blocked, the crossing is shorter, and there is no flat bottom. Measuring the depth of a grazing transit underestimates the planet\'s size, which is why astronomers fit the shape of the whole curve, not just the depth.' },
];

const S = { cfg: DEFAULT(), sys: null, obs: [], half: 0.5, cadence: 0.02, t: 0, running: false, playback: 1, est: null, checked: false, exp: null, expPhase: 0, started: false, active: false };

function seedOf(c) { let h = 2166136261; for (const ch of JSON.stringify(c)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
function rebuild({ keepT = false } = {}) {
  const st = STARS[S.cfg.star];
  S.sys = T.system({ Ms: st.Ms, Rs: st.Rs, Rp: S.cfg.Rp, P: S.cfg.P, b: S.cfg.b });
  const tr = S.sys.transits;
  S.half = tr ? Math.max(0.8 * S.sys.T14, 3 / 24) : 6 / 24;
  S.cadence = tr ? clamp(S.sys.T14 / 24, 2 / 1440, 30 / 1440) : 30 / 1440;
  S.obs = T.observe(S.sys, { halfWindow: S.half, cadence: S.cadence, sigma: S.cfg.noise * 1e-6, seed: seedOf(S.cfg) });
  if (!keepT) S.t = -S.half;
  S.est = null; S.checked = false;
  syncControls(); updateText(); updateMeasure(); updateChecks();
  draw();
}

/* ---------- text ---------- */
function fmtHours(d) { const h = d * 24; return h < 1 ? `${Math.round(h * 60)} minutes` : `${h.toFixed(1)} hours`; }
function story() {
  const s = S.sys, st = STARS[S.cfg.star];
  const size = `${trimR(S.cfg.Rp)} times Earth's radius`;
  if (!s.transits) return `With an impact parameter of ${S.cfg.b.toFixed(2)}, the planet's path passes above the star as seen from Earth, so nothing is blocked and the light curve stays flat. Most planetary systems look like this from where we sit.`;
  let t = `A planet ${size} crossing ${st.name === 'TRAPPIST-1' ? 'TRAPPIST-1' : 'a ' + st.name.toLowerCase()} dims it by ${fmtDepth(s.depthMax)}. The crossing takes ${fmtHours(s.T14)}.`;
  if (!s.full) t += ' Only part of the planet covers the star at any moment, so the dip has no flat bottom.';
  const sig = S.cfg.noise * 1e-6;
  if (sig > s.depthMax) t += ` The noise in each measurement (${S.cfg.noise} ppm) is larger than the dip, so a single transit is hard to see. Real surveys average many transits together.`;
  else if (sig > s.depthMax / 4) t += ' The dip is visible, but noise makes its exact depth uncertain.';
  return t;
}
const trimR = x => String(Number(x.toPrecision(3)));
function updateText() {
  const s = S.sys;
  $('#t-story').textContent = story();
  $('#t-roDepth').textContent = fmtDepth(s.depthMax);
  $('#t-roDur').textContent = s.transits ? fmtHours(s.T14) : 'No transit';
  $('#t-roOrbit').textContent = `${s.aAU < 0.1 ? s.aAU.toFixed(3) : s.aAU.toFixed(2)} AU`;
  $('#t-roProb').textContent = `${(s.prob * 100).toPrecision(2)}%`;
  $('#t-cadence').textContent = `Simulated observations, one every ${Math.round(S.cadence * 1440)} minutes, with ${S.cfg.noise} ppm noise each.`;
}

/* ---------- controls ---------- */
const P_MIN = Math.log10(0.5), P_MAX = Math.log10(5000);
function syncControls() {
  const c = S.cfg;
  $$('input[name="t-star"]').forEach(i => i.checked = i.value === c.star);
  $$('input[name="t-noise"]').forEach(i => i.checked = Number(i.value) === c.noise);
  $('#t-rp').value = c.Rp; $('#t-rpOut').textContent = `${trimR(c.Rp)} R⊕`;
  $('#t-p').value = Math.log10(c.P); $('#t-pOut').textContent = c.P < 2 ? `${(c.P * 24).toFixed(1)} hours` : `${c.P < 100 ? c.P.toFixed(1) : Math.round(c.P)} days`;
  $('#t-b').value = c.b; $('#t-bOut').textContent = c.b.toFixed(2);
  const k = S.sys.k;
  $('#t-bHint').textContent = `0 crosses the middle. A transit happens below ${(1 + k).toFixed(2)}; between ${(1 - k).toFixed(2)} and ${(1 + k).toFixed(2)} it only grazes the edge.`;
  $('#t-starNote').textContent = `${STARS[c.star].name}: ${STARS[c.star].note}. Brightness is treated as even across the disk.`;
  $('#t-playback').value = String(S.playback);
}
function bindControls() {
  $$('input[name="t-star"]').forEach(i => i.addEventListener('change', () => { S.cfg.star = i.value; rebuild({ keepT: true }); }));
  $$('input[name="t-noise"]').forEach(i => i.addEventListener('change', () => { S.cfg.noise = Number(i.value); rebuild({ keepT: true }); }));
  $('#t-rp').addEventListener('input', e => { S.cfg.Rp = Number(e.target.value); rebuild({ keepT: true }); });
  $('#t-p').addEventListener('input', e => { S.cfg.P = Number(Math.pow(10, Number(e.target.value)).toPrecision(4)); rebuild({ keepT: true }); });
  $('#t-b').addEventListener('input', e => { S.cfg.b = Number(e.target.value); rebuild({ keepT: true }); });
  $('#t-presets').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const p = PLANETS.find(x => x.id === b.dataset.id);
    S.cfg = { ...S.cfg, Rp: p.Rp, P: p.P, b: p.id === 'earth' || p.id === 'trappist-e' ? 0.1 : S.cfg.b, ...(p.star ? { star: p.star } : {}) };
    rebuild();
  });
  $('#t-play').addEventListener('click', () => setRunning(!S.running));
  $('#t-reset').addEventListener('click', () => { S.t = -S.half; draw(); });
  $('#t-playback').addEventListener('change', e => { S.playback = Number(e.target.value); });
  $('#t-defaults').addEventListener('click', () => { S.cfg = DEFAULT(); rebuild(); });
  // measure
  $('#t-est').addEventListener('input', e => { S.est = Number(e.target.value) * 1e-6; S.checked = false; updateMeasure(); draw(); });
  $('#t-check').addEventListener('click', () => { if (S.est == null) return; S.checked = true; updateMeasure(); });
  // tabs
  const tabs = $$('.tab');
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => selectTab(t));
    t.addEventListener('keydown', e => { if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return; const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length]; n.focus(); selectTab(n); });
  });
  $('#t-exps').addEventListener('click', onExpClick);
  new ResizeObserver(draw).observe($('#t-starView'));
}
function selectTab(tab) {
  $$('.tab').forEach(t => { const on = t === tab; t.setAttribute('aria-selected', on); t.tabIndex = on ? 0 : -1; $('#' + t.getAttribute('aria-controls')).hidden = !on; });
  draw();
}
function setRunning(on) {
  S.running = on;
  $('#t-playLabel').textContent = on ? 'Pause' : 'Play';
  $('#t-playIcon').innerHTML = on ? '<path d="M4 2.5h3v11H4zM9 2.5h3v11H9z" fill="currentColor"/>' : '<path d="M4 2.5v11l9-5.5z" fill="currentColor"/>';
}

/* ---------- measurement activity ---------- */
function updateMeasure() {
  const s = S.sys, sig = S.cfg.noise * 1e-6;
  const maxPpm = Math.ceil(Math.max(s.depthMax * 2, 5 * sig, 100e-6) * 1e6);
  const est = $('#t-est'); est.max = maxPpm; est.step = maxPpm > 5000 ? 10 : 1;
  if (S.est == null) { est.value = 0; $('#t-estOut').textContent = 'Not set'; $('#t-estRes').innerHTML = '<p>Move the slider until the orange line sits along the bottom of the dots in the dip.</p>'; $('#t-check').disabled = true; return; }
  $('#t-check').disabled = false;
  const st = STARS[S.cfg.star];
  const rEst = Math.sqrt(Math.max(S.est, 0)) * st.Rs * T.R_SUN_KM / T.R_EARTH_KM;
  $('#t-estOut').textContent = `${Math.round(S.est * 1e6)} ppm`;
  let h = `<p>Your depth: <b>${Math.round(S.est * 1e6)} ppm</b>, so the planet's radius is about <b>${trimR(rEst)} R⊕</b> (√depth × star radius).</p>`;
  if (S.checked) {
    const err = (rEst - S.cfg.Rp) / S.cfg.Rp;
    const good = Math.abs(err) < 0.15;
    h += `<p>True radius: <b>${trimR(S.cfg.Rp)} R⊕</b>, true depth ${Math.round(s.depthMax * 1e6)} ppm. Your estimate is ${Math.abs(err * 100).toFixed(0)}% ${err >= 0 ? 'too large' : 'too small'}.</p>`;
    h += `<p>${good ? 'Within 15%: a solid measurement.' : 'More than 15% off.'} ${!s.full ? 'This transit grazes the star, so depth alone underestimates the radius.' : sig > s.depthMax / 4 ? 'The noise is large compared with the dip. Averaging many transits would tighten this.' : ''}</p>`;
    APP.Progress.prediction('transit:measure', good);
  }
  $('#t-estRes').innerHTML = h;
}

/* ---------- model checks ---------- */
function updateChecks() {
  const s = S.sys, m = T.measure(s);
  const rows = [];
  if (!s.transits) rows.push(['Depth equals (Rp/R★)²', 'na', 'No transit with these settings.']);
  else if (s.full) { const d = Math.abs(m.depth - s.depthK2) / s.depthK2; rows.push(['Depth equals (Rp/R★)²', d < 1e-6 ? 'ok' : 'bad', `Simulated ${Math.round(m.depth * 1e6)} ppm against (Rp/R★)² = ${Math.round(s.depthK2 * 1e6)} ppm. Difference ${d.toExponential(1)}.`]); }
  else rows.push(['Depth equals (Rp/R★)²', 'na', `Grazing transit: the planet never fully covers the star, so the deepest point (${Math.round(m.depth * 1e6)} ppm) is less than (Rp/R★)² = ${Math.round(s.depthK2 * 1e6)} ppm, as expected.`]);
  if (s.transits) { const d = Math.abs(m.T14 - s.T14) / s.T14; rows.push(['Duration matches the formula', d < 1e-5 ? 'ok' : 'bad', `First to last contact in the simulation: ${fmtHours(m.T14)}. Formula (Winn 2010): ${fmtHours(s.T14)}.`]); }
  else rows.push(['Duration matches the formula', 'na', 'No transit with these settings.']);
  const map = { ok: 'Holds', bad: 'Broken', na: 'Not applicable' };
  $('#t-checks').innerHTML = rows.map(([n, st, txt]) => `<li class="check"><div class="check-head"><span>${n}</span><span class="badge" data-s="${st}">${map[st]}</span></div><p>${txt}</p></li>`).join('');
}

/* ---------- experiments ---------- */
function renderExperiments() {
  $('#t-exps').innerHTML = EXPERIMENTS.map(e => `<li class="exp" id="t-exp-${e.id}"><h3>${esc(e.title)}</h3><p class="law">${esc(e.law)}</p><p>${esc(e.setup)}</p>
    <button class="btn btn-small" data-act="setup" data-id="${e.id}">Set up this experiment</button>
    <div class="qa" hidden><p class="q">${esc(e.q)}</p><div class="opts">${e.options.map((o, i) => `<button class="opt" data-act="answer" data-id="${e.id}" data-i="${i}"><span>${esc(o)}</span><span class="mark"></span></button>`).join('')}</div>
    <div class="result" aria-live="polite" hidden></div></div></li>`).join('');
}
function onExpClick(ev) {
  const b = ev.target.closest('button[data-act]'); if (!b) return;
  const e = EXPERIMENTS.find(x => x.id === b.dataset.id), card = $('#t-exp-' + e.id);
  if (b.dataset.act === 'setup') {
    $$('.exp').forEach(n => n.classList.remove('is-active')); card.classList.add('is-active');
    S.exp = e.id; S.cfg = { ...e.before }; rebuild(); setRunning(!reduceMotion);
    $('.qa', card).hidden = false; $('.result', card).hidden = true;
    $$('.opt', card).forEach(o => { o.disabled = false; o.classList.remove('is-correct', 'is-wrong'); $('.mark', o).textContent = ''; });
    b.textContent = 'Start over';
  } else if (b.dataset.act === 'answer') {
    if (S.exp !== e.id) return;
    const i = Number(b.dataset.i), right = i === e.answer;
    $$('.opt', card).forEach((o, j) => { o.disabled = true; if (j === e.answer) { o.classList.add('is-correct'); $('.mark', o).textContent = j === i ? 'Your answer, correct' : 'Answer'; } else if (j === i) { o.classList.add('is-wrong'); $('.mark', o).textContent = 'Your answer'; } });
    APP.Progress.prediction('transit:' + e.id, right);
    const res = $('.result', card); res.hidden = false;
    res.innerHTML = `<p><span class="verdict">${right ? 'Correct.' : `Not quite. The answer is “${esc(e.options[e.answer])}”.`}</span> ${esc(e.explain)}</p><div class="row"><button class="btn btn-small btn-primary" data-act="run" data-id="${e.id}">Run it</button></div>`;
  } else if (b.dataset.act === 'run') {
    const d0 = S.sys.depthMax, t0 = S.sys.T14;
    S.cfg = { ...S.cfg, ...e.after }; rebuild(); setRunning(!reduceMotion);
    const d1 = S.sys.depthMax;
    const res = $('.result', card), p = document.createElement('p');
    p.innerHTML = `<b>Measured:</b> depth ${Math.round(d0 * 1e6)} → ${Math.round(d1 * 1e6)} ppm (${(d1 / d0).toFixed(2)}×); duration ${fmtHours(t0)} → ${fmtHours(S.sys.T14)}.`;
    res.insertBefore(p, res.lastElementChild);
    b.disabled = true;
    const vp = $('#t-starView').getBoundingClientRect();
    if (vp.top < 0 || vp.bottom > window.innerHeight) $('#t-starView').scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
  }
}

/* ---------- drawing + loop ---------- */
function draw() {
  if (!S.active || !S.sys) return;
  TransitDraw.star($('#t-star'), S.sys, S.t, { color: STARS[S.cfg.star].color });
  TransitDraw.curve($('#t-curve'), S.sys, { half: S.half, t: S.t, points: S.obs, sigma: S.cfg.noise * 1e-6, estimate: S.est });
  $('#t-time').textContent = `${S.t >= 0 ? '+' : '−'}${Math.abs(S.t * 24).toFixed(1)} h`;
}
let last = performance.now();
function frame(now) {
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (S.active && S.running) { S.t += dt * (2 * S.half / 7) * S.playback; if (S.t > S.half) S.t = -S.half; draw(); }
  requestAnimationFrame(frame);
}

function init() {
  renderExperiments(); bindControls();
  $('#t-presets').innerHTML = PLANETS.map(p => `<button class="btn btn-small" data-id="${p.id}">${esc(p.label)}</button>`).join('');
  S.active = true; rebuild(); S.active = false;
  requestAnimationFrame(frame);
}
init();
return {
  enter(arg) {
    S.active = true; APP.Progress.lab('transits');
    if (arg === 'trappist') { S.cfg = { star: 'trappist', Rp: 0.92, P: 6.101, b: 0.1, noise: 1000 }; rebuild(); selectTab($('#t-tab-measure')); }
    else rebuild({ keepT: true });
    if (!S.started && !reduceMotion) setRunning(true);
    S.started = true; draw();
  },
  leave() { S.active = false; },
};
})();
APP.HOOKS.transits = TransitLab;
