/* ---------- Curriculum content (structured, editable without touching app code) ---------- */
const CONTENT = (() => {
  const REVIEWED = '2026-10-15';

  const SOURCES = {
    'iau-2012-b2': { cite: 'IAU 2012 Resolution B2: re-definition of the astronomical unit (149,597,870,700 m exactly).', tier: 1, kind: 'Standard' },
    'iau-2015-b3': { cite: 'IAU 2015 Resolution B3: nominal solar and planetary conversion constants (R☉ = 695,700 km, GM☉ = 1.3271244 × 10²⁰ m³ s⁻²).', tier: 1, kind: 'Standard' },
    'si-c': { cite: 'BIPM, The International System of Units (SI), 9th edition: speed of light in vacuum, 299,792,458 m/s (exact).', tier: 1, kind: 'Standard' },
    'nasa-moon': { cite: 'NASA NSSDCA Moon Fact Sheet: mean Earth–Moon distance 384,400 km.', url: 'https://nssdc.gsfc.nasa.gov/planetary/factsheet/moonfact.html', tier: 3, kind: 'Curated reference data' },
    'nasa-earth': { cite: 'NASA NSSDCA Earth Fact Sheet: mean radius 6,371 km, GM = 398,600 km³ s⁻², mean orbital speed 29.78 km/s.', url: 'https://nssdc.gsfc.nasa.gov/planetary/factsheet/earthfact.html', tier: 3, kind: 'Curated reference data' },
    'nasa-neptune': { cite: 'NASA NSSDCA Neptune Fact Sheet: semi-major axis 30.07 AU, mean radius 24,622 km.', url: 'https://nssdc.gsfc.nasa.gov/planetary/factsheet/neptunefact.html', tier: 3, kind: 'Curated reference data' },
    'nasa-jupiter': { cite: 'NASA NSSDCA Jupiter Fact Sheet: mean radius 69,911 km, orbital period 4,332.6 days.', url: 'https://nssdc.gsfc.nasa.gov/planetary/factsheet/jupiterfact.html', tier: 3, kind: 'Curated reference data' },
    'gaia-dr3': { cite: 'Gaia Collaboration (2023), Gaia Data Release 3, A&A 674, A1. Parallax of Proxima Centauri gives ≈ 4.25 light-years.', tier: 3, kind: 'Catalogue' },
    'hipparcos-2007': { cite: 'van Leeuwen (2007), A&A 474, 653: new reduction of Hipparcos data. Parallax of Sirius gives ≈ 8.6 light-years.', tier: 3, kind: 'Catalogue' },
    'gravity-2019': { cite: 'GRAVITY Collaboration (2019), A&A 625, L10: distance to the Galactic Centre, 8.178 kpc (≈ 26,700 light-years).', tier: 2, kind: 'Peer-reviewed paper' },
    'mcconnachie-2005': { cite: 'McConnachie et al. (2005), MNRAS 356, 979: distances to Andromeda (M31) and its companions, ≈ 785 kpc; later studies give ≈ 765 kpc. Both round to about 2.5 million light-years.', tier: 2, kind: 'Peer-reviewed paper' },
    'openstax-astro': { cite: 'Fraknoi, Morrison & Wolff, Astronomy 2e (OpenStax, 2022). Chapters 1 (scale), 3 (orbits and gravity) and 21 (exoplanets).', url: 'https://openstax.org/details/books/astronomy-2e', tier: 5, kind: 'Open textbook' },
    'newton-principia': { cite: 'Newton (1687/1728), A Treatise of the System of the World: the "cannonball" thought experiment.', tier: 4, kind: 'Historical primary source' },
    'winn-2010': { cite: 'Winn (2010), "Transits and Occultations", in Exoplanets (ed. Seager), arXiv:1001.2010. Transit depth and duration formulas.', url: 'https://arxiv.org/abs/1001.2010', tier: 4, kind: 'Review chapter' },
    'nasa-exo-archive': { cite: 'NASA Exoplanet Archive, discovery statistics (checked October 2026): more than 6,000 confirmed planets, about three in four found by the transit method.', url: 'https://exoplanetarchive.ipac.caltech.edu/', tier: 3, kind: 'Curated archive' },
    'agol-2021': { cite: 'Agol et al. (2021), Planetary Science Journal 2, 1: TRAPPIST-1 star 0.0898 M☉ and 0.1192 R☉; planet e radius 0.920 R⊕, period 6.10 days.', tier: 2, kind: 'Peer-reviewed paper' },
    'gillon-2017': { cite: 'Gillon et al. (2017), Nature 542, 456: seven temperate, Earth-sized planets transiting the nearby star TRAPPIST-1.', tier: 2, kind: 'Peer-reviewed paper' },
  };

  const LEVELS = [
    { n: 0, name: 'Discovering space', who: 'No maths or prior knowledge needed.',
      planned: ['The universe and what is in it', 'The Solar System', 'Day, night and seasons', 'Eclipses', 'Astronomy versus astrology', 'What telescopes reveal'] },
    { n: 1, name: 'Foundations of astronomy', who: 'Simple ratios and guided calculations.',
      planned: ['Mass and weight', "Kepler's laws", 'The Sun and solar activity', 'Light and the electromagnetic spectrum', 'Lunar phases and tides', 'Spacecraft and missions'] },
    { n: 2, name: 'Intermediate astronomy', who: 'Graphs, data and evidence.',
      planned: ['Stellar life cycles', 'The Hertzsprung–Russell diagram', 'Spectroscopy', 'Other exoplanet discovery methods', 'Neutron stars and black holes', 'Galaxies and dark matter', 'Cosmic expansion'] },
    { n: 3, name: 'University astrophysics', who: 'Equations, derivations and problem sets.',
      planned: ['Orbital mechanics and transfers', 'Blackbody radiation', 'Stellar structure', 'Relativity', 'Friedmann equations', 'Statistical inference'] },
    { n: 4, name: 'Research and computation', who: 'Real datasets, Python and papers.',
      planned: ['Catalogues and data formats', 'Astropy and Astroquery', 'Light-curve analysis', 'Bayesian parameter estimation', 'N-body simulation', 'Reading a paper critically'] },
  ];

  const LESSONS = [
    {
      id: 'L0-SCALE-01', level: 0, category: 'Scale and distance', title: 'How far away is the sky?',
      duration: 10, prerequisites: [],
      objectives: [
        'Describe distances in space by how long light takes to cross them.',
        'Explain why a light-year measures distance, not time.',
        'Compare the jump from planets to stars to galaxies.',
      ],
      hook: { question: 'When you look at the Moon, the Sun and a star, are you seeing them as they are right now?',
        text: 'Light is the fastest thing there is, but it still takes time to travel. Everything you see in the sky is a message that left its source a while ago — sometimes a very long while.' },
      why: 'Astronomers cannot visit stars or galaxies. Almost everything we know about them comes from light that has crossed enormous distances, so knowing how far away things are is the first step to knowing what they are.',
      concepts: [
        { h: 'Light has a speed limit', p: 'Light travels at 299,792 kilometres every second. That is fast enough to circle Earth seven and a half times in one second, but space is so big that even light takes noticeable time to cross it.' },
        { h: 'A light-year is a distance', p: 'A light-year is how far light travels in one year: about 9.46 trillion kilometres. Saying a star is 4 light-years away means its light has been travelling for 4 years to reach you.' },
        { h: 'Looking out is looking back', p: 'Because light takes time to arrive, you see the Moon as it was a little over a second ago and the Sun as it was about eight minutes ago. Distant galaxies appear as they were millions of years ago.' },
      ],
      terms: [
        { t: 'Light-year', d: 'The distance light travels in one year, about 9.46 trillion km.' },
        { t: 'Astronomical unit (AU)', d: 'The average Earth–Sun distance, about 150 million km.' },
        { t: 'Light-travel time', d: 'How long light takes to get from an object to us.' },
      ],
      formulas: [{ html: 'distance = speed × time', label: '1 light-year ≈ 9.46 × 10<sup>12</sup> km' }],
      interactive: 'lightTravel',
      predict: { q: 'How long does sunlight take to reach Earth?', options: ['About 8 seconds', 'About 8 minutes', 'About 8 hours'], answer: 1,
        reveal: 'About 8 minutes and 19 seconds. The Sun is 150 million km away, and light covers that in 499 seconds. If the Sun vanished, you would not know for over eight minutes.', select: 'sun' },
      misconceptions: [
        { myth: 'A light-year is a length of time.', fact: 'It is a distance. The word "year" says how long light takes to cover it.' },
        { myth: 'The nearest stars are just a little farther than the planets.', fact: 'Neptune is about 4 light-hours away; the nearest star is about 4 light-years away, roughly 9,000 times farther.' },
      ],
      checks: [
        { q: 'A star is 100 light-years away. What does that tell you?', options: ['It is 100 years old', 'Its light left it 100 years ago', 'It will take 100 years to burn out'], answer: 1,
          why: 'A light-year is a distance. The light you see left the star 100 years ago, so you see it as it was then.' },
        { q: 'Which is farthest from us?', options: ['Neptune', 'Proxima Centauri', 'The centre of the Milky Way'], answer: 2,
          why: 'Neptune is about 4 light-hours away, Proxima Centauri about 4.2 light-years, and the centre of our galaxy about 26,700 light-years.' },
        { q: 'You look at the Andromeda galaxy, about 2.5 million light-years away. What are you seeing?', options: ['Andromeda as it is tonight', 'Andromeda as it was 2.5 million years ago', 'A reflection of the Milky Way'], answer: 1,
          why: 'That light set out about 2.5 million years ago, long before modern humans existed.' },
      ],
      assessment: 'Complete when you have answered all three questions. Two or more correct on the first try counts toward mastery.',
      sources: ['si-c', 'iau-2012-b2', 'nasa-moon', 'nasa-neptune', 'gaia-dr3', 'hipparcos-2007', 'gravity-2019', 'mcconnachie-2005', 'openstax-astro'],
      next: [{ label: 'Next lesson: why planets stay in orbit', href: '#/learn/L1-ORB-01' }],
    },
    {
      id: 'L1-ORB-01', level: 1, category: 'Gravity and orbits', title: "Why don't planets fall into the Sun?",
      duration: 15, prerequisites: ['L0-SCALE-01'],
      objectives: [
        'Explain an orbit as falling while moving sideways.',
        'Predict what happens below, at and above circular speed.',
        'Use the circular-speed formula for a given distance.',
      ],
      hook: { question: 'The Sun pulls on Earth all the time. Why hasn\'t Earth fallen into it?',
        text: 'Astronauts on the International Space Station float, yet gravity up there is still about 90% as strong as on the ground. Something other than "no gravity" is going on.' },
      why: 'Every satellite, space station and planet obeys the same idea. Understanding it explains why the Moon stays with us, how spacecraft reach other worlds, and how astronomers weigh stars.',
      concepts: [
        { h: 'Gravity always pulls', p: 'Gravity pulls every object toward every other object. The pull is stronger for more massive objects and weaker with distance: double the distance and the pull drops to a quarter.' },
        { h: 'Falling while moving sideways', p: 'Imagine firing a cannonball from a very tall mountain. It falls as it flies. Fire it faster and it lands farther away. Fire it fast enough and the ground curves away beneath it as quickly as it falls: it keeps falling but never lands. That is an orbit.' },
        { h: 'The right speed for a circle', p: 'At each distance there is one speed that gives a circle, called the circular speed. Slower and the orbit dips closer; faster and it swings wider. At about 1.41 times circular speed (escape speed), the object never comes back.' },
      ],
      terms: [
        { t: 'Orbit', d: 'The path of an object that keeps falling around another without hitting it.' },
        { t: 'Circular speed', d: 'The speed that keeps an object at a constant distance.' },
        { t: 'Escape speed', d: 'The speed needed to leave and never return, √2 times circular speed.' },
      ],
      formulas: [{ html: '<var>v</var><sub>circ</sub> = √(<var>GM</var> / <var>r</var>)', label: 'G: gravitational constant, M: mass being orbited, r: distance from its centre' }],
      interactive: 'newtonCannon',
      predict: { q: 'The cannon fires at 7.7 km/s, the circular speed 300 km above Earth. What happens?', options: ['It falls to the ground far away', 'It circles Earth and comes back around', 'It flies off into space'], answer: 1,
        reveal: 'It circles the whole planet in about 90 minutes and returns to the cannon. Real satellites at this height, like the International Space Station, move at about the same speed.', fire: 'circ' },
      misconceptions: [
        { myth: 'Astronauts float because there is no gravity in space.', fact: 'Gravity at the Space Station\'s height is about 90% of surface gravity. Astronauts float because they and the station are falling together.' },
        { myth: 'Satellites need engines running to stay up.', fact: 'Once at the right speed, an orbit needs no thrust. Engines are only used to change orbits or make up for thin air drag.' },
      ],
      checks: [
        { q: 'Why does the Space Station stay in orbit?', options: ['There is no gravity up there', 'It falls toward Earth but moves sideways fast enough to keep missing it', 'Its engines push it upward'], answer: 1,
          why: 'Gravity is still strong at that height. The station is in free fall, moving sideways at about 7.7 km/s.' },
        { q: 'A cannonball is fired slower than circular speed. What happens?', options: ['It falls inward and may hit the ground', 'It escapes', 'It orbits higher'], answer: 0,
          why: 'Too slow, and the fall wins: the path curves down. From a mountain on Earth it lands; in empty space it would swing in close and back out on an ellipse.' },
        { q: 'Circular speed depends on…', options: ['The mass of the orbiting object', 'The mass being orbited and the distance', 'Only the distance'], answer: 1,
          why: 'v = √(GM/r): M is the mass being orbited. The orbiting object\'s own mass cancels out, so a feather and a cannonball orbit the same way.' },
      ],
      assessment: 'Complete when you have answered all three questions. Two or more correct on the first try counts toward mastery.',
      sources: ['newton-principia', 'nasa-earth', 'iau-2015-b3', 'openstax-astro'],
      next: [{ label: 'Go deeper in the Gravity and orbits lab', href: '#/labs/orbits' }, { label: 'Next lesson: finding planets by their shadows', href: '#/learn/L2-EXO-01' }],
    },
    {
      id: 'L2-EXO-01', level: 2, category: 'Exoplanets', title: 'Finding planets by the shadows they cast',
      duration: 15, prerequisites: ['L1-ORB-01'],
      objectives: [
        'Explain how a transiting planet dims its star.',
        'Use transit depth to estimate a planet\'s size.',
        'Explain why most planetary systems are never seen to transit.',
      ],
      hook: { question: 'How can you discover a planet you can never see?',
        text: 'Planets around other stars are far too faint and close to their stars to photograph in most cases. Yet astronomers have confirmed more than 6,000 of them, and about three in four were found by watching for a tiny, regular dip in starlight.' },
      why: 'Transits tell us a planet\'s size and orbit, and when starlight filters through a transiting planet\'s atmosphere, telescopes can read what that atmosphere is made of.',
      concepts: [
        { h: 'A tiny eclipse', p: 'When a planet passes between its star and us, it blocks a small patch of the star\'s disk. The star looks slightly dimmer for a few hours, then recovers. If the dip repeats on a regular schedule, that schedule is the planet\'s orbital period.' },
        { h: 'Depth reveals size', p: 'The fraction of light blocked equals the planet\'s disk area divided by the star\'s: depth ≈ (planet radius ÷ star radius)². A Jupiter-size planet blocks about 1% of a Sun-like star; an Earth-size planet only about 0.008%.' },
        { h: 'Only some orbits line up', p: 'We only see a transit if the orbit is almost exactly edge-on from our viewpoint. For a planet like Earth around a star like the Sun, the chance is about 1 in 200, which is why surveys watch hundreds of thousands of stars.' },
      ],
      terms: [
        { t: 'Exoplanet', d: 'A planet orbiting a star other than the Sun.' },
        { t: 'Transit', d: 'A planet passing in front of its star as seen from Earth.' },
        { t: 'Light curve', d: 'A graph of a star\'s brightness over time.' },
        { t: 'Transit depth', d: 'How much the star dims during a transit, as a fraction of its normal brightness.' },
      ],
      formulas: [{ html: '<var>δ</var> ≈ (<var>R</var><sub>p</sub> / <var>R</var><sub>★</sub>)<sup>2</sup>', label: 'δ: transit depth, Rp: planet radius, R★: star radius' }],
      interactive: 'transitMini',
      predict: { q: 'A Jupiter-size planet crosses a Sun-like star. By how much does the star dim?', options: ['About 0.01%', 'About 1%', 'About 10%'], answer: 1,
        reveal: 'About 1%. Jupiter\'s radius is about one tenth of the Sun\'s, and one tenth squared is one hundredth. An Earth-size planet, about 1/109 of the Sun\'s radius, dims it by less than 0.01%.', select: 'jupiter' },
      misconceptions: [
        { myth: 'A transit gives us a picture of the planet.', fact: 'We only see the star dim. The planet itself is not resolved; its size is worked out from how much light it blocks.' },
        { myth: 'Every planet transits if we wait long enough.', fact: 'Only orbits that are nearly edge-on from Earth ever transit. Most planetary systems are tilted the wrong way.' },
      ],
      checks: [
        { q: 'A planet dims its star by 1%. Another dims the same star by 4%. How do their sizes compare?', options: ['The second is 4 times wider', 'The second is 2 times wider', 'They are the same size'], answer: 1,
          why: 'Depth goes with radius squared. Four times the depth means √4 = 2 times the radius.' },
        { q: 'The same Earth-size planet transits a small red dwarf instead of a Sun-like star. The dip is…', options: ['Deeper', 'Shallower', 'The same'], answer: 0,
          why: 'The planet covers a bigger fraction of a smaller star. That is why small stars are good places to look for small planets.' },
        { q: 'Why do surveys watch so many stars at once?', options: ['Most stars have no planets', 'Only a small fraction of planetary orbits line up to transit', 'Transits only happen once'], answer: 1,
          why: 'Many stars have planets, but only nearly edge-on orbits transit, about 1 in 200 for an Earth-like orbit around a Sun-like star.' },
      ],
      assessment: 'Complete when you have answered all three questions. Two or more correct on the first try counts toward mastery.',
      sources: ['winn-2010', 'nasa-exo-archive', 'nasa-jupiter', 'nasa-earth', 'iau-2015-b3', 'openstax-astro'],
      next: [{ label: 'Measure a planet yourself in the Transit lab', href: '#/labs/transits' }],
    },
  ];

  const LABS = [
    { id: 'orbits', title: 'Gravity and orbits', blurb: 'Launch planets around a star and check every orbit against Kepler\'s laws.', levels: '1–3', status: 'ready' },
    { id: 'transits', title: 'Exoplanet transits', blurb: 'Make a planet cross its star, read the light curve and measure the planet\'s size from noisy data.', levels: '2–4', status: 'ready' },
    { id: 'solar', title: 'Solar System explorer', blurb: 'All eight planets at today\'s positions in a view you can tilt and turn, with time controls and side-by-side comparisons.', levels: '0–2', status: 'ready' },
    { id: 'scale', title: 'Cosmic scale explorer', blurb: 'Zoom by powers of ten from Earth to the observable universe, with every view marked as to scale or schematic.', levels: '0–2', status: 'ready' },
    { id: 'spectra', title: 'Stellar spectroscopy', blurb: 'Blackbody curves, absorption and emission lines, and redshift. Read a star\'s temperature, make-up and motion.', levels: '2–3', status: 'ready' },
    { id: 'blackholes', title: 'Black holes', blurb: 'Orbits and falls calculated with general relativity, light bending, and the evidence kept separate from illustration.', levels: '2–3', status: 'ready' },
  ];

  return { REVIEWED, SOURCES, LEVELS, LESSONS, LABS };
})();
