#!/usr/bin/env node
/* Builds the single-file site from src/.
   node build.js            -> index.html (public build for GitHub Pages)
   node build.js --claude   -> dist/claude.html (build for claude.ai, with the AI tutor and account sync) */
const fs = require('fs'), path = require('path');
const claude = process.argv.includes('--claude');
const read = f => fs.readFileSync(path.join(__dirname, 'src', f), 'utf8');
const ORDER = ['physics.js', 'transit.js', 'astro.js', 'content.js', 'app.js', 'explore.js', 'spec.js', 'bh.js', 'labs2.js', 'orbitlab.js', 'transitlab.js', 'tutor.js'];
const REVIEWED = '15 October 2026';
// Function replacements: the code contains "$$" and "$'" sequences that string replacements would mangle.
let html = read('index.html')
  .replace('/*__CSS__*/', () => read('styles.css'))
  .replace('<!--__ORBIT_MARKUP__-->', () => read('orbit_markup.html'))
  .replace('/*__JS__*/', () => ORDER.map(read).join('\n') + '\nAPP.boot();\n')
  .replace('${REVIEWED}', () => REVIEWED);
if (!claude) html = html.replace('<html lang="en">', () => '<html lang="en" class="public">');
const out = claude ? path.join(__dirname, 'dist', 'claude.html') : path.join(__dirname, 'index.html');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, html);
console.log(`Built ${path.relative(__dirname, out)} (${(html.length / 1024).toFixed(0)} KB)`);
