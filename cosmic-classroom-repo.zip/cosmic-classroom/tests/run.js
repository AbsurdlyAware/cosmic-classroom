#!/usr/bin/env node
/* Physics and astronomy validation. Every lab's claims in the UI rest on these checks. Exits non-zero on failure. */
const path = require('path');
const src = f => require(path.join(__dirname, '..', 'src', f));
global.PHYS = src('physics.js');
const P = PHYS, T = src('transit.js'), A = src('astro.js'), S = src('spec.js'), B = src('bh.js');
let failed = 0, passed = 0;
function check(name, ok, detail) { if (ok) { passed++; console.log(`  ✓ ${name}  ${detail}`); } else { failed++; console.log(`  ✗ ${name}  ${detail}`); } }
const J = s => A.jd(new Date(s));

console.log('Orbit lab (velocity Verlet)');
{
  const vc = P.circularSpeedKms(1, 1), s = P.createSim({ mass: 1, r0: 1, v0: vc, angle: 0, integrator: 'verlet', dtDays: 'auto' });
  while (s.t < 100.01) P.step(s);
  const dT = Math.abs(s.periods[s.periods.length - 1] - s.el.T) / s.el.T;
  check('energy over 100 circular orbits', s.maxEerr < 1e-9, `max error ${s.maxEerr.toExponential(1)}`);
  check('period matches Kepler III', dT < 2e-5, `difference ${dT.toExponential(1)}`);
  check('angular momentum conserved', s.maxHerr < 1e-12, `max error ${s.maxHerr.toExponential(1)}`);
  const e = P.createSim({ mass: 1, r0: 1, v0: 22, angle: 0, integrator: 'verlet', dtDays: 'auto' });
  while (e.t < 20 * e.el.T) P.step(e);
  const w = P.wedgeSpread(e);
  check("equal areas (Kepler II) on an ellipse", w.spread < 1e-6, `spread ${w.spread.toExponential(1)}`);
  const u = P.createSim({ mass: 1, r0: 1, v0: vc, angle: 0, integrator: 'euler', dtDays: 1 });
  while (u.t < 5) P.step(u);
  check('Euler method visibly drifts (teaching demo)', u.maxEerr > 0.05, `energy error ${(u.maxEerr * 100).toFixed(1)}%`);
}
console.log('Transit lab');
{
  const s = T.system({ Ms: 1, Rs: 1, Rp: 1, P: 365.25, b: 0 }), m = T.measure(s);
  check('Earth transit depth ≈ 84 ppm', Math.abs(s.depthMax * 1e6 - 83.9) < 0.2, `${(s.depthMax * 1e6).toFixed(1)} ppm`);
  check('Earth transit duration ≈ 13.1 h', Math.abs(s.T14 * 24 - 13.1) < 0.1, `${(s.T14 * 24).toFixed(2)} h`);
  check('simulated duration matches formula', Math.abs(m.T14 - s.T14) / s.T14 < 1e-6, `${((m.T14 - s.T14) / s.T14).toExponential(1)}`);
  const t1 = T.system({ Ms: 0.0898, Rs: 0.1192, Rp: 0.92, P: 6.101, b: 0 });
  check('TRAPPIST-1e orbit ≈ 0.029 AU (Agol et al. 2021)', Math.abs(t1.aAU - 0.0293) < 0.0005, `${t1.aAU.toFixed(4)} AU`);
}
console.log('Ephemeris');
{
  for (const [k, t] of [['new', '2026-08-12T17:37Z'], ['full', '2026-03-03T11:38Z'], ['full', '2026-08-28T04:18Z'], ['new', '2027-08-02T10:05Z'], ['full', '2028-12-31T16:48Z']]) {
    const j = A.nextPhase(J(t) - 3, k === 'new' ? 0 : 180), d = Math.abs(j - J(t)) * 1440;
    check(`${k} moon ${t.slice(0, 10)}`, d < 20, `${d.toFixed(0)} min from published time`);
  }
  for (const [p, d] of [['mars', '2025-01-16'], ['mars', '2027-02-19'], ['jupiter', '2026-01-10'], ['saturn', '2026-10-04']]) {
    let best = { e: 0, j: 0 };
    for (let j = J(d) - 10; j < J(d) + 10; j += 0.01) { const e = A.elongation(p, j); if (e > best.e) best = { e, j }; }
    check(`${p} opposition ${d}`, Math.abs(best.j - J(d) - 0.5) < 1.2, `${(best.j - J(d)).toFixed(2)} days`);
  }
  const g = A.galilean(J('1992-12-16T00:00Z')), ex = [-3.44, 7.44, 1.24, 7.08];
  check("Galilean moons vs Meeus example 44.a", g.every((m, i) => Math.abs(m.x - ex[i]) < 0.05), g.map(m => m.x.toFixed(2)).join(', '));
  const years = { mercury: 88.0, venus: 224.7, earth: 365.2, mars: 687.0, jupiter: 4331, saturn: 10747, uranus: 30685, neptune: 60190 };
  const worst = Math.max(...Object.entries(years).map(([n, y]) => Math.abs(Math.pow(A.elements(n, J('2026-10-15')).a, 1.5) * 365.25 - y) / y));
  check("Kepler III vs NASA sidereal periods", worst < 0.002, `worst ${(worst * 100).toFixed(3)}%`);
}
console.log('Spectroscopy lab');
for (const t of [3000, 5772, 40000]) {
  const pk = (S.peakNumeric(t) - S.wienNm(t)) / S.wienNm(t), sb = (S.radiantExitance(t) - S.SIGMA * t ** 4) / (S.SIGMA * t ** 4);
  check(`Wien and Stefan–Boltzmann at ${t} K`, Math.abs(pk) < 1e-5 && Math.abs(sb) < 1e-5, `peak ${pk.toExponential(1)}, total ${sb.toExponential(1)}`);
}
console.log('Black hole lab');
{
  const o = B.orbit(400, B.hCirc(400) * 0.97, { maxPhi: 12 * Math.PI });
  check('conserved quantity along a GR orbit', o.maxErr < 1e-10, `${o.maxErr.toExponential(1)}`);
  const prec = o.apo[1] - o.apo[0] - 2 * Math.PI, wf = 6 * Math.PI / (o.h * o.h);
  check('weak-field precession', Math.abs(prec - wf) / wf < 0.05, `${(prec * 180 / Math.PI).toFixed(3)}° vs ${(wf * 180 / Math.PI).toFixed(3)}°`);
  check('stable circular orbit outside 6M', B.orbit(8, B.hCirc(8) * 0.999, { maxPhi: 30 * Math.PI }).end === 'bound', '8M');
  check('unstable orbit inside 6M plunges', B.orbit(5, B.hCirc(5) * 0.995, { maxPhi: 30 * Math.PI }).end === 'horizon', '5M');
  const rf = B.radialFall(10); let tn = 0; const E = Math.sqrt(0.8);
  for (let i = 1; i < 2000; i++) { const [r0, a0] = rf.pts[i - 1], [r1, a1] = rf.pts[i]; tn += E / (1 - 2 / ((r0 + r1) / 2)) * (a1 - a0); }
  check('radial fall: exact solution vs numeric integral', Math.abs(tn - rf.pts[1999][2]) / rf.pts[1999][2] < 1e-3, `${tn.toFixed(4)} vs ${rf.pts[1999][2].toFixed(4)}`);
}
console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
